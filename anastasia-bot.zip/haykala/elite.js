const fs = require('fs');
const path = require('path');

let config = {};
try {

    config = require('../config');
} catch (e) {
    config = {};
}

const filePath = path.join(__dirname, 'elite.json');
const addedOwnersFilePath = path.join(__dirname, 'addedOwners.json');

function extractPureNumber(jid) {
    if (!jid) return '';
    return String(jid)
        .split('@')[0]
        .split(':')[0]
        .replace(/\D/g, '');
}

function loadEliteNumbers() {
    try {
        if (fs.existsSync(filePath)) {
            const data = fs.readFileSync(filePath, 'utf8');
            const parsed = JSON.parse(data);
            return Array.isArray(parsed) ? parsed.map(extractPureNumber).filter(Boolean) : [];
        }
    } catch (e) {
        console.error('❌ خطأ في قراءة ملف elite.json:', e);
    }
    return [];
}

function saveEliteNumbers(numbers) {
    try {
        const unique = [...new Set(numbers.map(extractPureNumber))].filter(Boolean);
        fs.writeFileSync(filePath, JSON.stringify(unique, null, 2), 'utf8');
        return true;
    } catch (e) {
        console.error('❌ خطأ في حفظ ملف elite.json:', e);
        return false;
    }
}

let eliteNumbers = loadEliteNumbers();

function replaceEliteNumbers(newList) {
    const unique = [...new Set(newList.map(extractPureNumber))].filter(Boolean);
    eliteNumbers.length = 0;
    eliteNumbers.push(...unique);
}

function loadAddedOwners() {
    try {
        if (fs.existsSync(addedOwnersFilePath)) {
            const data = fs.readFileSync(addedOwnersFilePath, 'utf8');
            const parsed = JSON.parse(data);
            return Array.isArray(parsed) ? parsed.map(extractPureNumber).filter(Boolean) : [];
        }
    } catch (e) {
        console.error('❌ خطأ في قراءة ملف addedOwners.json:', e);
    }
    return [];
}

function saveAddedOwners(numbers) {
    try {
        const unique = [...new Set(numbers.map(extractPureNumber))].filter(Boolean);
        fs.writeFileSync(addedOwnersFilePath, JSON.stringify(unique, null, 2), 'utf8');
        return true;
    } catch (e) {
        console.error('❌ خطأ في حفظ ملف addedOwners.json:', e);
        return false;
    }
}

let addedOwners = loadAddedOwners();

function replaceAddedOwners(newList) {
    const unique = [...new Set(newList.map(extractPureNumber))].filter(Boolean);
    addedOwners.length = 0;
    addedOwners.push(...unique);
}

function configOwnerNumbers() {
    const list = [];
    if (config.owner) list.push(extractPureNumber(config.owner));
    if (Array.isArray(config.owners)) {
        for (const o of config.owners) list.push(extractPureNumber(o));
    }
    return list.filter(Boolean);
}

let sessionNumber = '';
let sessionLid = '';

function setSessionInfo(number, lid = '') {
    sessionNumber = extractPureNumber(number);
    sessionLid = extractPureNumber(lid);
}

function setSessionOwner(sock) {
    setSessionInfo(sock?.user?.id, sock?.user?.lid);

    if (sessionNumber && !eliteNumbers.includes(sessionNumber)) {
        addEliteNumber(sessionNumber);
        console.log(`👑 تم تثبيت رقم مالك الجلسة تلقائياً: ${sessionNumber}`);
    }
    if (sessionLid && !eliteNumbers.includes(sessionLid)) {
        addEliteNumber(sessionLid);
    }
}

function isRealOwner(number) {
    const pure = extractPureNumber(number);
    if (!pure) return false;

    if (configOwnerNumbers().includes(pure)) return true;
    if (sessionNumber && pure === sessionNumber) return true;
    if (sessionLid && pure === sessionLid) return true;

    return false;
}

function isAddedOwner(number) {
    const pure = extractPureNumber(number);
    return pure ? addedOwners.includes(pure) : false;
}

function addAddedOwner(number) {
    const pure = extractPureNumber(number);
    if (!pure) return false;
    if (isRealOwner(pure)) return false;
    if (!addedOwners.includes(pure)) {
        addedOwners.push(pure);
        saveAddedOwners(addedOwners);
    }
    return true;
}

function removeAddedOwner(number) {
    const pure = extractPureNumber(number);
    if (!pure) return false;
    if (!addedOwners.includes(pure)) return false;

    replaceAddedOwners(addedOwners.filter(n => n !== pure));
    return saveAddedOwners(addedOwners);
}

function isOwner(number) {
    const pure = extractPureNumber(number);
    if (!pure) return false;
    return isRealOwner(pure) || isAddedOwner(pure);
}

function isProtectedNumber(number) {
    return isRealOwner(number);
}

function getProtectedEliteNumber() {
    return sessionNumber || configOwnerNumbers()[0] || '';
}

function addEliteNumber(number) {
    const pure = extractPureNumber(number);
    if (!pure) return false;
    if (!eliteNumbers.includes(pure)) {
        eliteNumbers.push(pure);
        saveEliteNumbers(eliteNumbers);
    }
    return true;
}

function removeEliteNumber(number) {
    const pure = extractPureNumber(number);
    if (!pure) return false;

    if (isProtectedNumber(pure)) {

        return false;
    }

    replaceEliteNumbers(eliteNumbers.filter(n => n !== pure));
    return saveEliteNumbers(eliteNumbers);
}

function isElite(number) {
    const pure = extractPureNumber(number);
    if (!pure) return false;
    return isOwner(pure) || eliteNumbers.includes(pure);
}

module.exports = {
    eliteNumbers,
    addedOwners,
    extractPureNumber,
    addEliteNumber,
    removeEliteNumber,
    isElite,
    isOwner,
    isRealOwner,
    isAddedOwner,
    addAddedOwner,
    removeAddedOwner,
    isProtectedNumber,
    getProtectedEliteNumber,
    setSessionInfo,
    setSessionOwner
};
