// ======================================================
// 🖤 DARK lite — Console Logger
// ======================================================

const { colors } = require('../config');


// ======================================================
// 🎨 تنظيف النص
// ======================================================

function cleanMessage(message) {

    if (
        message === undefined ||
        message === null
    ) {
        return '';
    }

    return String(message);
}


// ======================================================
// 🖤 Logger
// ======================================================

const logger = {

    // --------------------------------------------------
    // ✓ نجاح
    // --------------------------------------------------

    success(message) {

        console.log(
            colors.success +
            '✓ ' +
            cleanMessage(message) +
            colors.reset
        );

    },


    // --------------------------------------------------
    // ✗ خطأ
    // --------------------------------------------------

    error(message, error = '') {

        const mainMessage =
            cleanMessage(message);

        const errorMessage =
            error
                ? `: ${cleanMessage(
                    error?.message || error
                )}`
                : '';

        console.error(
            colors.error +
            '✗ ' +
            mainMessage +
            errorMessage +
            colors.reset
        );

    },


    // --------------------------------------------------
    // ℹ معلومات
    // --------------------------------------------------

    info(message) {

        console.log(
            colors.info +
            'ℹ ' +
            cleanMessage(message) +
            colors.reset
        );

    },


    // --------------------------------------------------
    // ⚠ تحذير
    // --------------------------------------------------

    warn(message) {

        console.warn(
            colors.warn +
            '⚠ ' +
            cleanMessage(message) +
            colors.reset
        );

    }

};


// ======================================================
// 📤 التصدير
// ======================================================

module.exports = logger;