// ======================================================
// 📡 مدير أحداث البوت
// ======================================================

const path = require('path');

// ======================================================
// 📦 صندوق طلبات الانضمام المشترك
// ======================================================

const pendingJoinRequests = new Map();

// ======================================================
// ⏱️ مدة الاحتفاظ بالطلب
// 6 ساعات
// ======================================================

const JOIN_REQUEST_TTL =
    6 * 60 * 60 * 1000;

// ======================================================
// 🧹 تنظيف الطلبات القديمة
// ======================================================

function cleanExpiredJoinRequests() {

    const now = Date.now();

    for (
        const [key, timestamp]
        of pendingJoinRequests.entries()
    ) {

        if (
            now - timestamp >=
            JOIN_REQUEST_TTL
        ) {

            pendingJoinRequests.delete(key);

            console.log(
                `🧹 تم حذف طلب انضمام منتهي: ${key}`
            );
        }
    }
}

// تنظيف كل 10 دقائق
setInterval(
    cleanExpiredJoinRequests,
    10 * 60 * 1000
);

// ======================================================
// 🚀 تحميل الأحداث
// ======================================================

async function register(sock) {

    const context = {
        pendingJoinRequests,
        JOIN_REQUEST_TTL
    };

    // ==================================================
    // طلبات الانضمام
    // ==================================================

    const joinRequest =
        require('./joinRequest');

    if (
        typeof joinRequest?.register === 'function'
    ) {

        await joinRequest.register(
            sock,
            context
        );

        console.log(
            '   ✓ joinRequest.js'
        );

    } else {

        console.warn(
            '   ⚠️ joinRequest.js لا يحتوي على register'
        );
    }

    // ==================================================
    // تغييرات أعضاء المجموعة
    // ==================================================

    const groupParticipants =
        require('./groupParticipants');

    if (
        typeof groupParticipants?.register === 'function'
    ) {

        await groupParticipants.register(
            sock,
            context
        );

        console.log(
            '   ✓ groupParticipants.js'
        );

    } else {

        console.warn(
            '   ⚠️ groupParticipants.js لا يحتوي على register'
        );
    }

}

// ======================================================
// 📤 التصدير
// ======================================================

module.exports = {
    register,
    pendingJoinRequests,
    JOIN_REQUEST_TTL
};