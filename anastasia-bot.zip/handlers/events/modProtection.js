const fs = require('fs');
const path = require('path');

const {
    isElite
} = require('../../haykala/elite.js');

// ======================================================
// 🛡️ ملف بيانات الحماية
// ======================================================

const DATA_FILE = path.join(
    process.cwd(),
    'data',
    'modProtection.json'
);

// ======================================================
// 📂 تحميل حالة الحماية
// ======================================================

function loadData() {

    try {

        if (!fs.existsSync(DATA_FILE)) {
            return {};
        }

        return JSON.parse(
            fs.readFileSync(
                DATA_FILE,
                'utf8'
            )
        );

    } catch (error) {

        console.error(
            '⚠️ خطأ في قراءة حماية الإشراف:',
            error.message
        );

        return {};
    }
}

// ======================================================
// 🔢 توحيد JID
// ======================================================

function normalizeJid(jid) {

    if (!jid) return '';

    return jid
        .toString()
        .trim()
        .split(':')[0]
        .split('@')[0]
        .replace(/\D/g, '');
}

// ======================================================
// 🤖 الحصول على رقم البوت
// ======================================================

function getBotNumber(sock) {

    try {

        const user =
            sock?.user;

        if (!user) return '';

        return normalizeJid(
            user.id ||
            user.jid ||
            ''
        );

    } catch {

        return '';
    }
}

// ======================================================
// 👤 معرفة منفذ التعديل
// ======================================================

function getActor(update) {

    return normalizeJid(
        update?.author ||
        update?.participant ||
        update?.actor ||
        ''
    );
}

// ======================================================
// 🛡️ Event حماية الإشرافات
// ======================================================

async function handleModerationProtection(sock, update) {

    try {

        const chatId =
            update?.id ||
            update?.chatId;

        if (
            !chatId ||
            !chatId.endsWith('@g.us')
        ) {
            return;
        }

        // ==================================================
        // 📂 التأكد أن الحماية مفعلة
        // ==================================================

        const data =
            loadData();

        if (
            data[chatId] !== true
        ) {
            return;
        }

        // ==================================================
        // 📋 التغييرات
        // ==================================================

        const participants =
            update?.participants || [];

        const action =
            update?.action;

        if (
            !participants.length ||
            !action
        ) {
            return;
        }

        // ==================================================
        // 🔢 توحيد الأعضاء المستهدفين
        // ==================================================

        const targets =
            participants
                .filter(Boolean);

        if (!targets.length) {
            return;
        }

        // ==================================================
        // 🤖 رقم البوت
        // ==================================================

        const botNumber =
            getBotNumber(sock);

        // ==================================================
        // 🚫 لو التعديل هو إعطاء البوت إشراف
        // ==================================================

        if (
            action === 'promote' &&
            botNumber
        ) {

            const botIsTarget =
                targets.some(
                    jid =>
                        normalizeJid(jid) === botNumber
                );

            if (botIsTarget) {

                console.log(
                    '🤖 تم إعطاء البوت إشراف — لن يتم إلغاء العملية'
                );

                // نشيل البوت من القائمة
                // حتى لا يتم عكس إشرافه
                const otherTargets =
                    targets.filter(
                        jid =>
                            normalizeJid(jid) !== botNumber
                    );

                // لو مفيش أعضاء غير البوت
                if (!otherTargets.length) {
                    return;
                }

                // نكمل حماية باقي الأعضاء
            }
        }

        // ==================================================
        // 👤 منفذ التعديل
        // ==================================================

        const actor =
            getActor(update);

        if (!actor) {

            console.log(
                '⚠️ تم اكتشاف تغيير إشراف بدون معرفة المنفذ'
            );

            return;
        }

        // ==================================================
        // 🤖 لو البوت نفسه هو منفذ العملية
        // ==================================================

        if (
            botNumber &&
            actor === botNumber
        ) {

            console.log(
                '🤖 التعديل صادر من البوت — تم تجاهله'
            );

            return;
        }

        // ==================================================
        // 👑 النخبة مستثناة
        // ==================================================

        if (isElite(actor)) {

            console.log(
                `👑 تغيير إشراف مسموح للنخبة: ${actor}`
            );

            return;
        }

        // ==================================================
        // 🚫 لو الترقية تشمل البوت
        // لا نعكس ترقية البوت
        // ==================================================

        let targetsToReverse =
            targets;

        if (
            action === 'promote' &&
            botNumber
        ) {

            targetsToReverse =
                targets.filter(
                    jid =>
                        normalizeJid(jid) !== botNumber
                );

            if (!targetsToReverse.length) {

                console.log(
                    '🤖 العضو الوحيد المستهدف هو البوت — تم السماح بالترقية'
                );

                return;
            }
        }

        // ==================================================
        // 🚫 غير مسموح
        // ==================================================

        console.log(
            `🚫 محاولة تعديل إشراف من غير النخبة: ${actor}`
        );

        console.log(
            `📋 العملية: ${action}`
        );

        console.log(
            `👥 الأعضاء: ${targetsToReverse.join(', ')}`
        );

        // ==================================================
        // 🔄 تحديد العملية العكسية
        // ==================================================

        let reverseAction = null;

        // ترقية مشرف
        if (
            action === 'promote'
        ) {

            reverseAction =
                'demote';
        }

        // سحب إشراف
        else if (
            action === 'demote'
        ) {

            reverseAction =
                'promote';
        }

        // أي عملية أخرى
        else {

            return;
        }

        // ==================================================
        // 🔄 محاولة إلغاء التعديل
        // ==================================================

        try {

            await sock.groupParticipantsUpdate(
                chatId,
                targetsToReverse,
                reverseAction
            );

            console.log(
                `🛡️ تم عكس تعديل الإشراف: ${reverseAction}`
            );

        } catch (error) {

            console.error(
                '⚠️ فشل عكس تعديل الإشراف:',
                error.message
            );

        }

        // ==================================================
        // 📢 التحذير
        // ==================================================

        try {

            await sock.sendMessage(
                chatId,
                {
                    text:
                        '🚫 *غير مسموح*\n\n' +
                        '🛡️ التعديل في الإشرافات مسموح للنخبة فقط.\n\n' +
                        '⚠️ تم إلغاء التعديل.',
                    mentions: [actor]
                }
            );

        } catch (error) {

            console.error(
                '⚠️ فشل إرسال رسالة التحذير:',
                error.message
            );

        }

    } catch (error) {

        console.error(
            '❌ خطأ في حماية الإشرافات:',
            error
        );

    }

}

// ======================================================
// ⚡ تسجيل Event
// ======================================================

module.exports = {

    register(sock) {

        sock.ev.on(
            'group-participants.update',
            async update => {

                try {

                    await handleModerationProtection(
                        sock,
                        update
                    );

                } catch (error) {

                    console.error(
                        '❌ خطأ في Event حماية الإشرافات:',
                        error
                    );

                }

            }
        );

        console.log(
            '   ✓ تم تفعيل Event حماية الإشرافات 🛡️'
        );

    }

};