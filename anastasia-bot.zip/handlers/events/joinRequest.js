const fs = require('fs-extra');
const path = require('path');

const JOIN_REQUEST_TTL = 6 * 60 * 60 * 1000;

const DATA_DIR =
path.join(__dirname, '../../data');

const DATA_FILE =
path.join(DATA_DIR, 'joinRequests.json');

let pendingJoinRequests = {};

// ======================================================
// توحيد JID
// ======================================================

function normalizeJid(jid) {

if (!jid) return '';

return String(jid)
    .trim()
    .split(':')[0]
    .toLowerCase();

}

// ======================================================
// استخراج قيمة المعرف
// ======================================================

function getValue(jid) {

const clean =
    normalizeJid(jid);

if (!clean) return '';

return clean
    .replace('@s.whatsapp.net', '')
    .replace('@lid', '')
    .replace('@c.us', '');

}

// ======================================================
// إنشاء المفتاح
// ======================================================

function makeKey(groupId, participant) {

return (
    normalizeJid(groupId) +
    '|' +
    normalizeJid(participant)
);

}

// ======================================================
// إضافة جميع الصيغ الممكنة
// ======================================================

function getPossibleKeys(groupId, participant) {

const group =
    normalizeJid(groupId);

const clean =
    normalizeJid(participant);

const value =
    getValue(clean);

const keys = [];

if (!group || !value) {
    return keys;
}

keys.push(
    `${group}|${clean}`
);

keys.push(
    `${group}|${value}@lid`
);

keys.push(
    `${group}|${value}@s.whatsapp.net`
);

keys.push(
    `${group}|${value}@c.us`
);

return [
    ...new Set(keys)
];

}

// ======================================================
// تحميل
// ======================================================

async function loadData() {

try {

    await fs.ensureDir(DATA_DIR);

    if (
        !(await fs.pathExists(DATA_FILE))
    ) {

        pendingJoinRequests = {};

        await saveData();

        return;
    }

    const data =
        await fs.readJson(DATA_FILE);

    if (
        data &&
        typeof data === 'object' &&
        !Array.isArray(data)
    ) {

        pendingJoinRequests = data;

    } else {

        pendingJoinRequests = {};
    }

    await cleanExpiredRequests();

} catch (error) {

    console.error(
        '❌ فشل تحميل طلبات الانضمام:',
        error.message
    );

    pendingJoinRequests = {};

}

}

// ======================================================
// حفظ
// ======================================================

async function saveData() {

try {

    await fs.ensureDir(DATA_DIR);

    await fs.writeJson(
        DATA_FILE,
        pendingJoinRequests,
        {
            spaces: 2
        }
    );

} catch (error) {

    console.error(
        '❌ فشل حفظ طلبات الانضمام:',
        error.message
    );

}

}

// ======================================================
// إضافة طلب
// ======================================================

async function addJoinRequest(
groupId,
participant
) {

if (
    !groupId ||
    !participant
) {
    return false;
}

const key =
    makeKey(
        groupId,
        participant
    );

pendingJoinRequests[key] =
    {
        participant:
            normalizeJid(participant),

        value:
            getValue(participant),

        createdAt:
            Date.now()
    };

await saveData();

console.log(
    `📥 تم حفظ طلب انضمام: ${normalizeJid(participant)}`
);

return true;

}

// ======================================================
// البحث
// ======================================================

function findJoinRequest(
groupId,
participant
) {

const keys =
    getPossibleKeys(
        groupId,
        participant
    );

const now =
    Date.now();

for (
    const key of keys
) {

    const entry =
        pendingJoinRequests[key];

    if (!entry) {
        continue;
    }

    // دعم البيانات القديمة
    const createdAt =
        typeof entry === 'number'
            ? entry
            : entry.createdAt;

    if (!createdAt) {
        delete pendingJoinRequests[key];
        continue;
    }

    if (
        now - createdAt >=
        JOIN_REQUEST_TTL
    ) {

        delete pendingJoinRequests[key];

        continue;
    }

    return {
        key,
        entry
    };

}

return null;

}

// ======================================================
// التحقق
// ======================================================

function hasJoinRequest(
groupId,
participant
) {

return !!findJoinRequest(
    groupId,
    participant
);

}

// ======================================================
// استهلاك
// ======================================================

async function consumeJoinRequest(
groupId,
participant
) {

const result =
    findJoinRequest(
        groupId,
        participant
    );

if (!result) {
    return false;
}

delete pendingJoinRequests[
    result.key
];

await saveData();

console.log(
    `✅ تم استهلاك طلب الانضمام: ${normalizeJid(participant)}`
);

return true;

}

// ======================================================
// تنظيف
// ======================================================

async function cleanExpiredRequests() {

const now =
    Date.now();

let changed = false;

for (
    const [key, entry]
    of Object.entries(
        pendingJoinRequests
    )
) {

    const createdAt =
        typeof entry === 'number'
            ? entry
            : entry?.createdAt;

    if (
        !createdAt ||
        now - createdAt >=
        JOIN_REQUEST_TTL
    ) {

        delete pendingJoinRequests[key];

        changed = true;
    }

}

if (changed) {
    await saveData();
}

}

// ======================================================
// محاولة الحصول على المعرف المقابل
// ======================================================

async function resolveAlternativeJid(
sock,
jid
) {

try {

    const clean =
        normalizeJid(jid);

    if (!clean) {
        return [];
    }

    const result =
        new Set([
            clean
        ]);

    const mapping =
        sock?.signalRepository
            ?.lidMapping;

    if (!mapping) {
        return [...result];
    }

    // LID -> Phone Number
    if (
        clean.endsWith('@lid') &&
        typeof mapping.getPNForLID ===
        'function'
    ) {

        const pn =
            await mapping.getPNForLID(
                clean
            );

        if (pn) {

            result.add(
                normalizeJid(pn)
            );

            if (
                !String(pn)
                    .includes('@')
            ) {

                result.add(
                    `${pn}@s.whatsapp.net`
                );

            }

        }

    }

    // Phone Number -> LID
    if (
        clean.endsWith('@s.whatsapp.net') &&
        typeof mapping.getLIDForPN ===
        'function'
    ) {

        const lid =
            await mapping.getLIDForPN(
                clean
            );

        if (lid) {

            result.add(
                normalizeJid(lid)
            );

            if (
                !String(lid)
                    .includes('@')
            ) {

                result.add(
                    `${lid}@lid`
                );

            }

        }

    }

    return [
        ...result
    ];

} catch (error) {

    return [
        normalizeJid(jid)
    ];

}

}

// ======================================================
// بحث ذكي باستخدام Baileys
// ======================================================

async function hasJoinRequestSmart(
sock,
groupId,
participant
) {

if (
    hasJoinRequest(
        groupId,
        participant
    )
) {
    return true;
}

const alternatives =
    await resolveAlternativeJid(
        sock,
        participant
    );

for (
    const jid
    of alternatives
) {

    if (
        hasJoinRequest(
            groupId,
            jid
        )
    ) {

        return true;
    }

}

return false;

}

// ======================================================
// استهلاك ذكي
// ======================================================

async function consumeJoinRequestSmart(
sock,
groupId,
participant
) {

if (
    await consumeJoinRequest(
        groupId,
        participant
    )
) {
    return true;
}

const alternatives =
    await resolveAlternativeJid(
        sock,
        participant
    );

for (
    const jid
    of alternatives
) {

    if (
        await consumeJoinRequest(
            groupId,
            jid
        )
    ) {

        return true;
    }

}

return false;

}

// ======================================================
// حدث طلب الانضمام
// ======================================================

async function handleJoinRequest(
sock,
update
) {

try {

    const groupId =
        update?.id;

    const participant =
        update?.participant;

    const action =
        update?.action;

    if (
        !groupId ||
        !groupId.endsWith('@g.us') ||
        !participant
    ) {
        return;
    }

    if (
        action !== 'created'
    ) {
        return;
    }

    await addJoinRequest(
        groupId,
        participant
    );

} catch (error) {

    console.error(
        '❌ خطأ في group.join-request:',
        error
    );

}

}

// ======================================================
// التسجيل
// ======================================================

module.exports = {

async register(sock) {

    await loadData();

    if (!this._cleanupStarted) {

        this._cleanupStarted = true;

        setInterval(
            () => {

                cleanExpiredRequests()
                    .catch(() => {});

            },
            10 * 60 * 1000
        );

    }

    sock.ev.on(
        'group.join-request',
        async update => {

            await handleJoinRequest(
                sock,
                update
            );

        }
    );

    console.log(
        '   ✓ نظام طلبات الانضمام جاهز'
    );

},

hasJoinRequest,

consumeJoinRequest,

hasJoinRequestSmart,

consumeJoinRequestSmart,

addJoinRequest,

cleanExpiredRequests,

normalizeJid,

resolveAlternativeJid

};