const groupMonitor = require('../../lib/groupMonitor');
const joinRequest = require('./joinRequest');

// ======================================================
// طلبات محتملة: remove -> add
// ======================================================

const possibleJoinRequests = new Map();

const POSSIBLE_REQUEST_TTL = 60 * 1000;

// ======================================================
// توحيد JID
// ======================================================

function normalizeJid(jid) {
if (!jid) return '';

return String(jid)
    .trim()
    .split(':')[0];

}

// ======================================================
// Mention
// ======================================================

function mention(jid) {
const clean = normalizeJid(jid);

if (!clean) return '';

return `@${clean.split('@')[0]}`;

}

// ======================================================
// معرفة منفذ العملية
// ======================================================

function getExecutor(update) {
return normalizeJid(
update?.author ||
update?.actor ||
update?.by ||
''
);
}

// ======================================================
// إنشاء المفتاح
// ======================================================

function makeKey(groupId, member) {
return (
normalizeJid(groupId) +
'|' +
normalizeJid(member)
);
}

// ======================================================
// حفظ عملية remove مؤقتًا
// ======================================================

function rememberPossibleJoinRequest(groupId, member) {
const key = makeKey(groupId, member);

possibleJoinRequests.set(
    key,
    Date.now()
);

console.log(
    `🕐 تم تسجيل دخول محتمل: ${member}`
);

}

// ======================================================
// فحص remove سابق
// ======================================================

function hasPossibleJoinRequest(groupId, member) {
const key = makeKey(groupId, member);

const timestamp =
    possibleJoinRequests.get(key);

if (!timestamp) {
    return false;
}

if (
    Date.now() - timestamp >
    POSSIBLE_REQUEST_TTL
) {
    possibleJoinRequests.delete(key);
    return false;
}

return true;

}

// ======================================================
// استهلاك العلامة
// ======================================================

function consumePossibleJoinRequest(groupId, member) {
const key = makeKey(groupId, member);

possibleJoinRequests.delete(key);

}

// ======================================================
// تنظيف دوري
// ======================================================

setInterval(() => {

const now = Date.now();

for (
    const [key, timestamp]
    of possibleJoinRequests
) {

    if (
        now - timestamp >
        POSSIBLE_REQUEST_TTL
    ) {
        possibleJoinRequests.delete(key);
    }
}

}, 30 * 1000);

// ======================================================
// معالجة تغييرات الأعضاء
// ======================================================

async function handleGroupParticipants(sock, update) {

try {

    console.log(
        '🔎 GROUP PARTICIPANTS UPDATE:',
        JSON.stringify(update, null, 2)
    );

    const groupId =
        update?.id;

    const participants =
        update?.participants;

    const action =
        update?.action;

    if (
        !groupId ||
        !groupId.endsWith('@g.us')
    ) {
        return;
    }

    if (
        !Array.isArray(participants) ||
        !participants.length
    ) {
        return;
    }

    // ==================================================
    // هل المراقبة مفعلة؟
    // ==================================================

    if (
        !groupMonitor.shouldMonitorGroup(
            groupId
        )
    ) {
        return;
    }

    // ==================================================
    // بيانات المجموعة
    // ==================================================

    const metadata =
        await sock
            .groupMetadata(groupId)
            .catch(() => null);

    const groupName =
        metadata?.subject ||
        'مجموعة غير معروفة';

    const reportGroup =
        groupMonitor.getReportGroup(
            groupId
        ) || groupId;

    const executor =
        getExecutor(update);

    // ==================================================
    // معالجة الأعضاء
    // ==================================================

    for (
        const participant
        of participants
    ) {

        const member =
            normalizeJid(participant);

        if (!member) {
            continue;
        }

        let title = '';
        let description = '';
        let mentions = [];

        // ==================================================
        // 👑 ترقية
        // ==================================================

        if (
            action === 'promote'
        ) {

            title =
                '👑 ترقية إلى الإشراف';

            if (executor) {

                description =
                    `قام ${mention(executor)} بترقية ${mention(member)} إلى الإشراف`;

                mentions = [
                    executor,
                    member
                ];

            } else {

                description =
                    `تمت ترقية ${mention(member)} إلى الإشراف`;

                mentions = [
                    member
                ];
            }
        }

        // ==================================================
        // ⬇️ خفض
        // ==================================================

        else if (
            action === 'demote'
        ) {

            title =
                '⬇️ خفض من الإشراف';

            if (executor) {

                description =
                    `قام ${mention(executor)} بخفض ${mention(member)} من الإشراف`;

                mentions = [
                    executor,
                    member
                ];

            } else {

                description =
                    `تم خفض ${mention(member)} من الإشراف`;

                mentions = [
                    member
                ];
            }
        }

        // ==================================================
        // ➕ إضافة عضو
        // ==================================================

        else if (
            action === 'add'
        ) {

            // ==================================================
            // أولاً:
            // طلب انضمام محفوظ فعليًا
            // ==================================================

            let isJoinRequest = false;

            try {

                isJoinRequest =
                    joinRequest.hasJoinRequest(
                        groupId,
                        member
                    );

            } catch (error) {

                console.log(
                    '⚠️ خطأ أثناء فحص طلب الانضمام:',
                    error.message
                );
            }

            // ==================================================
            // ثانيًا:
            // remove -> add
            // ==================================================

            const possibleRequest =
                hasPossibleJoinRequest(
                    groupId,
                    member
                );

            // ==================================================
            // ✅ قبول طلب انضمام
            // ==================================================

            if (
                isJoinRequest ||
                possibleRequest
            ) {

                consumePossibleJoinRequest(
                    groupId,
                    member
                );

                if (
                    isJoinRequest
                ) {

                    try {

                        await joinRequest.consumeJoinRequest(
                            groupId,
                            member
                        );

                    } catch (error) {

                        console.log(
                            '⚠️ خطأ أثناء استهلاك طلب الانضمام:',
                            error.message
                        );
                    }
                }

                title =
                    '✅ قبول طلب انضمام';

                if (executor) {

                    description =
                        `وافق ${mention(executor)} على طلب انضمام ${mention(member)}`;

                    mentions = [
                        executor,
                        member
                    ];

                } else {

                    description =
                        `تمت الموافقة على طلب انضمام ${mention(member)}`;

                    mentions = [
                        member
                    ];
                }
            }

            // ==================================================
            // 🔗 انضمام عبر رابط
            // ==================================================

            else if (
                executor &&
                executor === member
            ) {

                title =
                    '🔗 انضمام عبر رابط';

                description =
                    `انضم ${mention(member)} إلى المجموعة عبر رابط الدعوة`;

                mentions = [
                    member
                ];
            }

            // ==================================================
            // 🔗 انضمام بدون منفذ
            // ==================================================

            else if (
                !executor
            ) {

                title =
                    '🔗 انضمام عبر رابط';

                description =
                    `انضم ${mention(member)} إلى المجموعة عبر رابط الدعوة`;

                mentions = [
                    member
                ];
            }

            // ==================================================
            // ➕ إضافة بواسطة عضو
            // ==================================================

            else {

                title =
                    '➕ إضافة عضو';

                description =
                    `قام ${mention(executor)} بإضافة ${mention(member)} إلى المجموعة`;

                mentions = [
                    executor,
                    member
                ];
            }
        }

        // ==================================================
        // 🚪 إزالة عضو
        // ==================================================

        else if (
            action === 'remove'
        ) {

            // ==================================================
            // مهم:
            //
            // لا نرسل أي رسالة عند remove.
            //
            // فقط نحفظه مؤقتًا لأن بعض نسخ Baileys
            // ترسل:
            //
            // remove -> add
            //
            // عند قبول طلب الانضمام.
            // ==================================================

            if (
                executor &&
                executor === member
            ) {

                rememberPossibleJoinRequest(
                    groupId,
                    member
                );

                continue;
            }

            // ==================================================
            // ❌ طرد
            // ==================================================

            if (executor) {

                title =
                    '❌ طرد عضو';

                description =
                    `قام ${mention(executor)} بطرد ${mention(member)} من المجموعة`;

                mentions = [
                    executor,
                    member
                ];
            }

            // ==================================================
            // ❓ إزالة مجهولة
            // ==================================================

            else {

                title =
                    '❓ إزالة عضو';

                description =
                    `تمت إزالة ${mention(member)} من المجموعة بواسطة غير معروف`;

                mentions = [
                    member
                ];
            }
        }

        // ==================================================
        // Action غير معروف
        // ==================================================

        else {

            continue;
        }

        // ==================================================
        // التاريخ
        // ==================================================

        const now =
            new Date();

        const dateText =
            new Intl.DateTimeFormat(
                'ar-EG',
                {
                    timeZone:
                        'Africa/Cairo',

                    year:
                        'numeric',

                    month:
                        '2-digit',

                    day:
                        '2-digit'
                }
            ).format(now);

        const timeText =
            new Intl.DateTimeFormat(
                'ar-EG',
                {
                    timeZone:
                        'Africa/Cairo',

                    hour:
                        '2-digit',

                    minute:
                        '2-digit',

                    second:
                        '2-digit',

                    hour12:
                        true
                }
            ).format(now);

        // ==================================================
        // التقرير
        // ==================================================

        const text =
            `${title}\n\n` +
            `${description}\n\n` +
            `👥 المجموعة: ${groupName}\n` +
            `📅 التاريخ: ${dateText}\n` +
            `⏰ الوقت: ${timeText}`;

        // ==================================================
        // إرسال التقرير
        // ==================================================

        await sock.sendMessage(
            reportGroup,
            {
                text,
                mentions
            }
        );
    }

} catch (error) {

    console.error(
        '❌ خطأ في مراقبة تغييرات أعضاء المجموعة:',
        error
    );
}

}

// ======================================================
// التسجيل
// ======================================================

module.exports = {

register(sock) {

    sock.ev.on(
        'group-participants.update',
        async update => {

            await handleGroupParticipants(
                sock,
                update
            );

        }
    );

}

};