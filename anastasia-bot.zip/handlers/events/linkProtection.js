'use strict';

const fs = require('fs');
const path = require('path');

const {
    isElite,
    isOwner,
    extractPureNumber
} = require('../../haykala/elite.js');

// ======================================================
// 📂 ملفات البيانات
// ======================================================

const SETTINGS_FILE = path.join(
    process.cwd(),
    'data',
    'linkProtection.json'
);

const STRIKES_FILE = path.join(
    process.cwd(),
    'data',
    'linkStrikes.json'
);

// ======================================================
// ⚙️ الإعدادات
// ======================================================

const CONFIG = {

    // عدد المخالفات قبل الطرد
    MAX_STRIKES: 3,

    // مدة الاحتفاظ بالمخالفات (7 أيام)
    STRIKE_EXPIRY: 7 * 24 * 60 * 60 * 1000,

    // تسجيل الأحداث في الكونسول
    LOG: true

};

// ======================================================
// 🔗 كشف الروابط
// ======================================================

// روابط مباشرة + دومينات + روابط واتساب وتليجرام وديسكورد
const LINK_REGEX = new RegExp(
    [
        // http / https
        String.raw`https?:\/\/[^\s<>"']+`,

        // www
        String.raw`www\.[^\s<>"']+`,

        // WhatsApp
        String.raw`chat\.whatsapp\.com\/[^\s<>"']+`,
        String.raw`wa\.me\/[^\s<>"']+`,
        String.raw`api\.whatsapp\.com\/[^\s<>"']+`,

        // Telegram
        String.raw`t\.me\/[^\s<>"']+`,
        String.raw`telegram\.me\/[^\s<>"']+`,

        // Discord
        String.raw`discord\.gg\/[^\s<>"']+`,
        String.raw`discord\.com\/invite\/[^\s<>"']+`,

        // Shorteners
        String.raw`bit\.ly\/[^\s<>"']+`,
        String.raw`tinyurl\.com\/[^\s<>"']+`,
        String.raw`cutt\.ly\/[^\s<>"']+`,

        // أي دومين مشهور أو امتداد TLD
        String.raw`\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+(?:com|net|org|io|me|co|ai|app|dev|xyz|link|info|biz|site|online|store|tech|live|cloud|tv|gg|pro|vip|cc|ly|eg|sa|ae|uk|us|de|fr|ru|in|jp|cn)\b(?:\/[^\s<>"']*)?`
    ].join('|'),
    'gi'
);

// ======================================================
// 📝 Logging
// ======================================================

function log(message) {

    if (!CONFIG.LOG) return;

    console.log(
        `[LinkProtection] ${message}`
    );

}

// ======================================================
// 📂 JSON Helpers
// ======================================================

function readJSON(file) {

    try {

        const directory =
            path.dirname(file);

        if (!fs.existsSync(directory)) {

            fs.mkdirSync(
                directory,
                { recursive: true }
            );

        }

        if (!fs.existsSync(file)) {
            return {};
        }

        const content =
            fs.readFileSync(
                file,
                'utf8'
            );

        if (!content.trim()) {
            return {};
        }

        const data =
            JSON.parse(content);

        return (
            data &&
            typeof data === 'object' &&
            !Array.isArray(data)
        )
            ? data
            : {};

    } catch (error) {

        console.error(
            '⚠️ JSON Read Error:',
            error.message
        );

        return {};
    }

}

function writeJSON(file, data) {

    try {

        const directory =
            path.dirname(file);

        fs.mkdirSync(
            directory,
            { recursive: true }
        );

        // كتابة آمنة لمنع تلف الملف
        const tempFile =
            `${file}.tmp`;

        fs.writeFileSync(
            tempFile,
            JSON.stringify(
                data,
                null,
                2
            ),
            'utf8'
        );

        fs.renameSync(
            tempFile,
            file
        );

        return true;

    } catch (error) {

        console.error(
            '⚠️ JSON Write Error:',
            error.message
        );

        return false;
    }

}

// ======================================================
// 🔢 توحيد الرقم
// ======================================================

function normalizeNumber(jid) {

    if (!jid) return '';

    return jid
        .toString()
        .trim()
        .split(':')[0]
        .split('@')[0]
        .replace(/\D/g, '');

}

// ======================================================
// 📩 استخراج المرسل
// ======================================================

function getSenderJid(msg) {

    return (
        msg?.key?.participant ||
        msg?.participant ||
        msg?.key?.remoteJid ||
        ''
    );

}

// ======================================================
// 📦 فك الرسائل المغلفة
// ======================================================

function unwrapMessage(message) {

    if (!message) return {};

    let current = message;

    const wrappers = [
        'ephemeralMessage',
        'viewOnceMessage',
        'viewOnceMessageV2',
        'viewOnceMessageV2Extension',
        'documentWithCaptionMessage'
    ];

    let changed = true;
    let safety = 0;

    while (
        changed &&
        safety < 10
    ) {

        changed = false;
        safety++;

        for (const wrapper of wrappers) {

            if (
                current?.[wrapper]?.message
            ) {

                current =
                    current[wrapper].message;

                changed = true;
                break;
            }

        }

    }

    return current;

}

// ======================================================
// 📝 استخراج النص
// ======================================================

function getMessageText(msg) {

    try {

        const message =
            unwrapMessage(
                msg?.message
            );

        return (
            message?.conversation ||
            message?.extendedTextMessage?.text ||
            message?.imageMessage?.caption ||
            message?.videoMessage?.caption ||
            message?.documentMessage?.caption ||
            message?.buttonsResponseMessage?.selectedDisplayText ||
            message?.templateButtonReplyMessage?.selectedDisplayText ||
            message?.listResponseMessage?.title ||
            ''
        )
            .toString()
            .trim();

    } catch {

        return '';

    }

}

// ======================================================
// 🔗 استخراج الروابط
// ======================================================

function extractLinks(text) {

    if (
        !text ||
        typeof text !== 'string'
    ) {
        return [];
    }

    // Reset بسبب Global Regex
    LINK_REGEX.lastIndex = 0;

    const matches =
        text.match(LINK_REGEX);

    if (!matches) {
        return [];
    }

    return [
        ...new Set(
            matches
                .map(link =>
                    link
                        .trim()
                        .replace(
                            /[.,!?;:)\]}]+$/g,
                            ''
                        )
                )
                .filter(Boolean)
        )
    ];

}

// ======================================================
// 🛡️ حالة حماية الجروب
// ======================================================

function isProtectionEnabled(chatId) {

    const settings =
        readJSON(
            SETTINGS_FILE
        );

    return (
        settings[chatId] === true
    );

}

// ======================================================
// 📊 الحصول على المخالفات
// ======================================================

function getStrikes(
    chatId,
    userNumber
) {

    const data =
        readJSON(
            STRIKES_FILE
        );

    const key =
        `${chatId}:${userNumber}`;

    const record =
        data[key];

    if (!record) {
        return 0;
    }

    // توافق مع النظام القديم
    if (
        typeof record === 'number'
    ) {
        return record;
    }

    const updatedAt =
        Number(record.updatedAt) || 0;

    // انتهاء المخالفات القديمة
    if (
        updatedAt &&
        Date.now() - updatedAt >
            CONFIG.STRIKE_EXPIRY
    ) {

        delete data[key];

        writeJSON(
            STRIKES_FILE,
            data
        );

        return 0;
    }

    return Number(
        record.strikes
    ) || 0;

}

// ======================================================
// ➕ إضافة مخالفة
// ======================================================

function addStrike(
    chatId,
    userNumber
) {

    const data =
        readJSON(
            STRIKES_FILE
        );

    const key =
        `${chatId}:${userNumber}`;

    let current = 0;

    const old =
        data[key];

    if (
        typeof old === 'number'
    ) {

        current = old;

    } else if (
        old &&
        typeof old === 'object'
    ) {

        const updatedAt =
            Number(old.updatedAt) || 0;

        if (
            updatedAt &&
            Date.now() - updatedAt <=
                CONFIG.STRIKE_EXPIRY
        ) {

            current =
                Number(old.strikes) || 0;

        }

    }

    const strikes =
        current + 1;

    data[key] = {
        strikes,
        updatedAt: Date.now()
    };

    writeJSON(
        STRIKES_FILE,
        data
    );

    return strikes;

}

// ======================================================
// 🗑️ تصفير المخالفات
// ======================================================

function clearStrikes(
    chatId,
    userNumber
) {

    const data =
        readJSON(
            STRIKES_FILE
        );

    const key =
        `${chatId}:${userNumber}`;

    if (data[key]) {

        delete data[key];

        writeJSON(
            STRIKES_FILE,
            data
        );

    }

}

// ======================================================
// 🗑️ حذف الرسالة
// ======================================================

async function deleteMessage(
    sock,
    chatId,
    msg
) {

    try {

        await sock.sendMessage(
            chatId,
            {
                delete: msg.key
            }
        );

        return true;

    } catch (error) {

        log(
            `فشل حذف رسالة: ${error.message}`
        );

        return false;

    }

}

// ======================================================
// 👑 التحقق من الاستثناء
// ======================================================

function isExempt(
    senderJid,
    senderNumber
) {

    try {

        // النخبة
        if (
            typeof isElite === 'function' &&
            isElite(senderNumber)
        ) {
            return true;
        }

        // المالك إذا كانت الدالة موجودة
        if (
            typeof isOwner === 'function' &&
            isOwner(senderNumber)
        ) {
            return true;
        }

        return false;

    } catch {

        return false;

    }

}

// ======================================================
// 📢 إرسال الإنذار
// ======================================================

async function sendStrikeWarning(
    sock,
    chatId,
    senderJid,
    senderNumber,
    strikes
) {

    let text = '';

    if (strikes === 1) {

        text =
            `⚠️ *إنذار أول*\n\n` +
            `@${senderNumber}\n\n` +
            `🚫 يمنع إرسال الروابط في هذه المجموعة.\n\n` +
            `📊 الإنذارات: 1/${CONFIG.MAX_STRIKES}\n` +
            `⚠️ الإنذار القادم سيكون تحذيرًا أخيرًا.`;

    }

    else if (strikes === 2) {

        text =
            `🚨 *تحذير أخير*\n\n` +
            `@${senderNumber}\n\n` +
            `🚫 تم رصد إرسال رابط مرة أخرى.\n\n` +
            `📊 الإنذارات: 2/${CONFIG.MAX_STRIKES}\n` +
            `⛔ المخالفة القادمة ستؤدي إلى الطرد.`;

    }

    if (!text) {
        return;
    }

    await sock.sendMessage(
        chatId,
        {
            text,
            mentions: [senderJid]
        }
    );

}

// ======================================================
// 🚫 طرد العضو
// ======================================================

async function removeUser(
    sock,
    chatId,
    senderJid,
    senderNumber
) {

    try {

        await sock.groupParticipantsUpdate(
            chatId,
            [senderJid],
            'remove'
        );

        clearStrikes(
            chatId,
            senderNumber
        );

        await sock.sendMessage(
            chatId,
            {
                text:
                    `🚫 *تم طرد العضو*\n\n` +
                    `@${senderNumber}\n\n` +
                    `📌 السبب: تجاوز الحد المسموح ` +
                    `لإرسال الروابط.\n\n` +
                    `📊 الإنذارات: ${CONFIG.MAX_STRIKES}/${CONFIG.MAX_STRIKES}`,
                mentions: [senderJid]
            }
        );

        log(
            `تم طرد ${senderNumber} بسبب الروابط`
        );

        return true;

    } catch (error) {

        console.error(
            '⚠️ فشل طرد العضو:',
            error.message
        );

        await sock.sendMessage(
            chatId,
            {
                text:
                    `⚠️ @${senderNumber} تجاوز الحد المسموح من الإنذارات.\n\n` +
                    `❌ تعذر طرده، تأكد أن البوت أدمن.`,
                mentions: [senderJid]
            }
        ).catch(() => {});

        return false;

    }

}

// ======================================================
// 🛡️ المعالج الرئيسي
// ======================================================

async function handleLinkProtection(
    sock,
    msg
) {

    try {

        const chatId =
            msg?.key?.remoteJid;

        // مجموعات فقط
        if (
            !chatId ||
            !chatId.endsWith('@g.us')
        ) {
            return;
        }

        // تجاهل رسائل البوت
        if (
            msg?.key?.fromMe
        ) {
            return;
        }

        // الحماية غير مفعلة
        if (
            !isProtectionEnabled(chatId)
        ) {
            return;
        }

        // النص
        const text =
            getMessageText(msg);

        if (!text) {
            return;
        }

        // الروابط
        const links =
            extractLinks(text);

        if (!links.length) {
            return;
        }

        const senderJid =
            getSenderJid(msg);

        if (!senderJid) {
            return;
        }

        const senderNumber =
            typeof extractPureNumber === 'function'
                ? extractPureNumber(senderJid)
                : normalizeNumber(senderJid);

        if (!senderNumber) {
            return;
        }

        // استثناء المالك والنخبة
        if (
            isExempt(
                senderJid,
                senderNumber
            )
        ) {

            log(
                `رابط مسموح للمستثنى: ${senderNumber}`
            );

            return;
        }

        // ==================================================
        // 🗑️ حذف الرسالة
        // ==================================================

        await deleteMessage(
            sock,
            chatId,
            msg
        );

        // ==================================================
        // ➕ إضافة إنذار
        // ==================================================

        const strikes =
            addStrike(
                chatId,
                senderNumber
            );

        log(
            `رابط من ${senderNumber} | Strike ${strikes}/${CONFIG.MAX_STRIKES}`
        );

        // ==================================================
        // 🚫 طرد
        // ==================================================

        if (
            strikes >=
            CONFIG.MAX_STRIKES
        ) {

            await removeUser(
                sock,
                chatId,
                senderJid,
                senderNumber
            );

            return;
        }

        // ==================================================
        // ⚠️ إنذار
        // ==================================================

        await sendStrikeWarning(
            sock,
            chatId,
            senderJid,
            senderNumber,
            strikes
        );

    } catch (error) {

        console.error(
            '❌ خطأ في حماية الروابط:',
            error
        );

    }

}

// ======================================================
// ⚡ تسجيل Event
// ======================================================

module.exports = {

    register(sock) {

        // تحميل Event
        sock.ev.on(
            'messages.upsert',
            async ({ messages }) => {

                if (
                    !Array.isArray(messages) ||
                    !messages.length
                ) {
                    return;
                }

                // معالجة جميع الرسائل
                for (
                    const msg of messages
                ) {

                    if (!msg?.message) {
                        continue;
                    }

                    try {

                        await handleLinkProtection(
                            sock,
                            msg
                        );

                    } catch (error) {

                        console.error(
                            '❌ خطأ Event حماية الروابط:',
                            error.message
                        );

                    }

                }

            }
        );

        console.log(
            '   ✓ تم تفعيل Event حماية الروابط 🔗'
        );

    }

};