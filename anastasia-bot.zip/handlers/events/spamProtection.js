'use strict';

const fs = require('fs-extra');
const path = require('path');

const {
    isElite,
    isOwner,
    extractPureNumber
} = require('../../haykala/elite');

// ======================================================
// 📁 الملفات
// ======================================================

const SETTINGS_FILE = path.join(
    process.cwd(),
    'data',
    'spamProtection.json'
);

const STRIKES_FILE = path.join(
    process.cwd(),
    'data',
    'spamStrikes.json'
);

// ======================================================
// ⚙️ الإعدادات
// ======================================================

const CONFIG = {

    // عدد الرسائل المتتالية المسموح بها
    MAX_MESSAGES: 6,

    // الفترة الزمنية للمراقبة
    TIME_WINDOW: 5000,

    // عدد المخالفات قبل الطرد
    MAX_STRIKES: 3,

    // مدة الاحتفاظ بالإنذارات
    STRIKE_EXPIRY: 7 * 24 * 60 * 60 * 1000,

    // مدة تجاهل المستخدم بعد اكتشاف الإسبام
    COOLDOWN: 3000

};

// ======================================================
// 🧠 الذاكرة المؤقتة
// لا يتم حفظ الرسائل نفسها في JSON
// ======================================================

const messageTracker = new Map();

const cooldowns = new Map();

// ======================================================
// 📂 قراءة JSON
// ======================================================

async function readJSON(file) {

    try {

        await fs.ensureDir(
            path.dirname(file)
        );

        if (
            !await fs.pathExists(file)
        ) {
            return {};
        }

        const data =
            await fs.readJson(file);

        return (
            data &&
            typeof data === 'object' &&
            !Array.isArray(data)
        )
            ? data
            : {};

    } catch (error) {

        console.error(
            `⚠️ فشل قراءة ${path.basename(file)}:`,
            error.message
        );

        return {};

    }

}

// ======================================================
// 💾 كتابة JSON
// ======================================================

async function writeJSON(file, data) {

    try {

        await fs.ensureDir(
            path.dirname(file)
        );

        const tempFile =
            `${file}.tmp`;

        await fs.writeJson(
            tempFile,
            data,
            {
                spaces: 2
            }
        );

        await fs.move(
            tempFile,
            file,
            {
                overwrite: true
            }
        );

        return true;

    } catch (error) {

        console.error(
            `⚠️ فشل حفظ ${path.basename(file)}:`,
            error.message
        );

        return false;

    }

}

// ======================================================
// 🔢 توحيد الرقم
// ======================================================

function normalizeNumber(value) {

    if (!value) return '';

    return String(value)
        .split(':')[0]
        .split('@')[0]
        .replace(/\D/g, '');

}

// ======================================================
// 👤 الحصول على المرسل
// ======================================================

function getSenderJid(msg) {

    const chatId =
        msg?.key?.remoteJid || '';

    if (chatId.endsWith('@g.us')) {

        return (
            msg?.key?.participant ||
            msg?.participant ||
            msg?.key?.senderPn ||
            ''
        );

    }

    return chatId;

}

// ======================================================
// 📨 فك الرسائل المغلفة
// ======================================================

function unwrapMessage(message) {

    let current = message;
    let loops = 0;

    const wrappers = [
        'ephemeralMessage',
        'viewOnceMessage',
        'viewOnceMessageV2',
        'viewOnceMessageV2Extension'
    ];

    while (
        current &&
        loops < 10
    ) {

        let changed = false;

        for (const wrapper of wrappers) {

            if (
                current?.[wrapper]?.message
            ) {

                current =
                    current[wrapper].message;

                changed = true;
                break;

            }

        }

        if (!changed) break;

        loops++;

    }

    return current || {};

}

// ======================================================
// 🔍 تحديد نوع الرسالة القابلة للمراقبة
// ======================================================

function getSpamMessageType(msg) {

    try {

        const message =
            unwrapMessage(msg?.message);

        if (!message) {
            return null;
        }

        // نص
        if (
            typeof message.conversation === 'string' ||
            typeof message?.extendedTextMessage?.text === 'string'
        ) {

            return 'text';

        }

        // Sticker
        if (message.stickerMessage) {
            return 'sticker';
        }

        // صور
        if (message.imageMessage) {
            return 'image';
        }

        // فيديو
        if (message.videoMessage) {
            return 'video';
        }

        // صوت
        if (message.audioMessage) {
            return 'audio';
        }

        // GIF
        if (message.gifMessage) {
            return 'gif';
        }

        // مستند
        if (message.documentMessage) {
            return 'document';
        }

        return null;

    } catch {

        return null;

    }

}

// ======================================================
// ⚙️ إعدادات الجروب
// ======================================================

async function getSettings(chatId) {

    const data =
        await readJSON(SETTINGS_FILE);

    const settings =
        data[chatId];

    if (!settings) {

        return {
            enabled: false,
            ignored: []
        };

    }

    // توافق لو كان النظام القديم true/false
    if (typeof settings === 'boolean') {

        return {
            enabled: settings,
            ignored: []
        };

    }

    return {
        enabled: settings.enabled === true,

        ignored: Array.isArray(
            settings.ignored
        )
            ? settings.ignored
            : []
    };

}

// ======================================================
// 👑 هل المستخدم مستثنى؟
// ======================================================

function isExempt(
    senderJid,
    senderNumber,
    settings
) {

    try {

        // النخبة
        if (
            typeof isElite === 'function' &&
            isElite(senderNumber)
        ) {
            return true;
        }

        // المالك
        if (
            typeof isOwner === 'function' &&
            isOwner(senderNumber)
        ) {
            return true;
        }

        // قائمة التجاهل الخاصة بالجروب
        if (
            settings?.ignored?.includes(
                senderNumber
            )
        ) {
            return true;
        }

        return false;

    } catch {

        return false;

    }

}

// ======================================================
// 📊 تسجيل الرسائل وتحليل الإسبام
// ======================================================

function checkSpam(
    chatId,
    senderNumber,
    messageType
) {

    const key =
        `${chatId}:${senderNumber}`;

    const now =
        Date.now();

    let records =
        messageTracker.get(key) || [];

    // حذف الرسائل القديمة خارج النافذة الزمنية
    records =
        records.filter(
            record =>
                now - record.time <=
                CONFIG.TIME_WINDOW
        );

    // إضافة الرسالة الجديدة
    records.push({
        time: now,
        type: messageType
    });

    messageTracker.set(
        key,
        records
    );

    // هل وصل للحد؟
    if (
        records.length >=
        CONFIG.MAX_MESSAGES
    ) {

        // تصفير السجل حتى لا يحتسب
        // نفس الإسبام أكثر من مرة
        messageTracker.set(
            key,
            []
        );

        return {
            spam: true,
            count: records.length,
            types: records.map(
                item => item.type
            )
        };

    }

    return {
        spam: false,
        count: records.length
    };

}

// ======================================================
// ⏳ منع التكرار
// ======================================================

function isOnCooldown(
    chatId,
    senderNumber
) {

    const key =
        `${chatId}:${senderNumber}`;

    const until =
        cooldowns.get(key);

    if (!until) {
        return false;
    }

    if (Date.now() >= until) {

        cooldowns.delete(key);

        return false;

    }

    return true;

}

function setCooldown(
    chatId,
    senderNumber
) {

    const key =
        `${chatId}:${senderNumber}`;

    cooldowns.set(
        key,
        Date.now() + CONFIG.COOLDOWN
    );

}

// ======================================================
// ⚠️ الحصول على الإنذارات
// ======================================================

async function addStrike(
    chatId,
    senderNumber
) {

    const data =
        await readJSON(STRIKES_FILE);

    const key =
        `${chatId}:${senderNumber}`;

    let current = 0;

    const old =
        data[key];

    if (
        old &&
        typeof old === 'object'
    ) {

        const updatedAt =
            Number(old.updatedAt) || 0;

        if (
            !updatedAt ||
            Date.now() - updatedAt <=
            CONFIG.STRIKE_EXPIRY
        ) {

            current =
                Number(old.strikes) || 0;

        }

    }

    const strikes =
        current + 1;

    data[key] = {
        strikes,
        updatedAt: Date.now(),
        reason: 'spam'
    };

    await writeJSON(
        STRIKES_FILE,
        data
    );

    return strikes;

}

// ======================================================
// 🧹 حذف الإنذارات
// ======================================================

async function clearStrikes(
    chatId,
    senderNumber
) {

    const data =
        await readJSON(STRIKES_FILE);

    const key =
        `${chatId}:${senderNumber}`;

    if (data[key]) {

        delete data[key];

        await writeJSON(
            STRIKES_FILE,
            data
        );

    }

}

// ======================================================
// 🗑️ محاولة حذف الرسالة الحالية
// ======================================================

async function deleteMessage(
    sock,
    chatId,
    msg
) {

    try {

        await sock.sendMessage(
            chatId,
            {
                delete: msg.key
            }
        );

    } catch {}

}

// ======================================================
// 🚨 إرسال التحذير
// ======================================================

async function sendWarning(
    sock,
    chatId,
    senderJid,
    senderNumber,
    strikes,
    count
) {

    let text = '';

    if (strikes === 1) {

        text =
            `⚠️ *إنذار بسبب الإسبام*\n\n` +
            `👤 @${senderNumber}\n\n` +
            `🚫 تم رصد إرسال ${count} رسائل متتالية بسرعة كبيرة.\n\n` +
            `📊 الإنذارات: 1/${CONFIG.MAX_STRIKES}\n\n` +
            `⚠️ يرجى التوقف عن إرسال الرسائل بشكل متكرر.`;

    }

    else if (strikes === 2) {

        text =
            `🚨 *تحذير أخير بسبب الإسبام*\n\n` +
            `👤 @${senderNumber}\n\n` +
            `🚫 تم رصد تكرار سلوك الإسبام مرة أخرى.\n\n` +
            `📊 الإنذارات: 2/${CONFIG.MAX_STRIKES}\n\n` +
            `⛔ المخالفة القادمة ستؤدي إلى الطرد.`;

    }

    if (!text) return;

    await sock.sendMessage(
        chatId,
        {
            text,
            mentions: [senderJid]
        }
    ).catch(() => {});

}

// ======================================================
// 🚫 طرد العضو
// ======================================================

async function removeUser(
    sock,
    chatId,
    senderJid,
    senderNumber
) {

    try {

        await sock.groupParticipantsUpdate(
            chatId,
            [senderJid],
            'remove'
        );

        await clearStrikes(
            chatId,
            senderNumber
        );

        await sock.sendMessage(
            chatId,
            {
                text:
                    `🚫 *تم طرد عضو بسبب الإسبام*\n\n` +
                    `👤 @${senderNumber}\n\n` +
                    `📌 السبب: تكرار إرسال الرسائل والملصقات بشكل مزعج.\n` +
                    `📊 تجاوز الحد المسموح من الإنذارات.`,
                mentions: [senderJid]
            }
        ).catch(() => {});

        console.log(
            `🚫 Spam Protection: تم طرد ${senderNumber}`
        );

    } catch (error) {

        console.error(
            '⚠️ فشل طرد عضو بسبب الإسبام:',
            error.message
        );

        await sock.sendMessage(
            chatId,
            {
                text:
                    `⚠️ تم اكتشاف مخالفة إسبام من @${senderNumber} لكن تعذر طرده.\n\n` +
                    `تأكد أن البوت أدمن.`,
                mentions: [senderJid]
            }
        ).catch(() => {});

    }

}

// ======================================================
// 🛡️ المعالج الرئيسي
// ======================================================

async function handleSpamProtection(
    sock,
    msg
) {

    try {

        const chatId =
            msg?.key?.remoteJid;

        // مجموعات فقط
        if (
            !chatId ||
            !chatId.endsWith('@g.us')
        ) {
            return;
        }

        // رسائل البوت
        if (msg?.key?.fromMe) {
            return;
        }

        // نوع الرسالة
        const messageType =
            getSpamMessageType(msg);

        if (!messageType) {
            return;
        }

        // المرسل
        const senderJid =
            getSenderJid(msg);

        if (!senderJid) {
            return;
        }

        const senderNumber =
            typeof extractPureNumber === 'function'
                ? extractPureNumber(senderJid)
                : normalizeNumber(senderJid);

        if (!senderNumber) {
            return;
        }

        // إعدادات الحماية
        const settings =
            await getSettings(chatId);

        // غير مفعلة
        if (!settings.enabled) {
            return;
        }

        // مستثنى
        if (
            isExempt(
                senderJid,
                senderNumber,
                settings
            )
        ) {
            return;
        }

        // منع معالجة نفس المخالفة عدة مرات
        if (
            isOnCooldown(
                chatId,
                senderNumber
            )
        ) {
            return;
        }

        // تحليل الرسائل
        const result =
            checkSpam(
                chatId,
                senderNumber,
                messageType
            );

        if (!result.spam) {
            return;
        }

        // وضع Cooldown
        setCooldown(
            chatId,
            senderNumber
        );

        console.log(
            `🚨 تم اكتشاف Spam من ${senderNumber} (${result.count} رسائل)`
        );

        // حذف آخر رسالة
        await deleteMessage(
            sock,
            chatId,
            msg
        );

        // إضافة مخالفة
        const strikes =
            await addStrike(
                chatId,
                senderNumber
            );

        // طرد
        if (
            strikes >=
            CONFIG.MAX_STRIKES
        ) {

            await removeUser(
                sock,
                chatId,
                senderJid,
                senderNumber
            );

            return;
        }

        // إنذار
        await sendWarning(
            sock,
            chatId,
            senderJid,
            senderNumber,
            strikes,
            result.count
        );

    } catch (error) {

        console.error(
            '❌ خطأ في حماية الإسبام:',
            error.stack || error
        );

    }

}

// ======================================================
// 🧹 تنظيف الذاكرة كل 10 دقائق
// ======================================================

setInterval(
    () => {

        const now =
            Date.now();

        for (
            const [key, records] of messageTracker
        ) {

            const valid =
                records.filter(
                    record =>
                        now - record.time <=
                        CONFIG.TIME_WINDOW
                );

            if (valid.length) {

                messageTracker.set(
                    key,
                    valid
                );

            } else {

                messageTracker.delete(key);

            }

        }

        for (
            const [key, until] of cooldowns
        ) {

            if (now >= until) {
                cooldowns.delete(key);
            }

        }

    },
    10 * 60 * 1000
).unref();

// ======================================================
// ⚡ تسجيل الـ Event
// ======================================================

module.exports = {

    register(sock) {

        sock.ev.on(
            'messages.upsert',
            async ({ messages }) => {

                if (
                    !Array.isArray(messages)
                ) {
                    return;
                }

                for (
                    const msg of messages
                ) {

                    if (!msg?.message) {
                        continue;
                    }

                    await handleSpamProtection(
                        sock,
                        msg
                    );

                }

            }
        );

        console.log(
            '   ✓ تم تفعيل Event حماية الإسبام 🚨'
        );

    }

};