const contactProtection =
    require('../../lib/contactProtection');

// ======================================================
// 🔧 استخراج نص الرسالة
// ======================================================

function getMessage(message) {

    if (!message) return null;

    return (
        message.message ||
        message
    );

}

// ======================================================
// 📱 هل الرسالة تحتوي على جهة اتصال؟
// ======================================================

function getContactMessage(message) {

    const m = getMessage(message);

    if (!m) return null;

    // جهة اتصال واحدة
    if (m.contactMessage) {
        return m.contactMessage;
    }

    // عدة جهات اتصال
    if (m.contactsArrayMessage) {
        return m.contactsArrayMessage;
    }

    return null;
}

// ======================================================
// 🚫 حماية جهات الاتصال
// ======================================================

async function handleContactProtection(sock, msg) {

    try {

        // ==================================================
        // الحماية متوقفة
        // ==================================================

        if (!contactProtection.isEnabled()) {
            return;
        }

        // ==================================================
        // لازم تكون الرسالة في مجموعة
        // ==================================================

        const chatId =
            msg?.key?.remoteJid;

        if (
            !chatId ||
            !chatId.endsWith('@g.us')
        ) {
            return;
        }

        // ==================================================
        // تجاهل رسائل البوت نفسه
        // ==================================================

        if (msg?.key?.fromMe) {
            return;
        }

        // ==================================================
        // استخراج جهة الاتصال
        // ==================================================

        const contact =
            getContactMessage(msg);

        if (!contact) {
            return;
        }

        // ==================================================
        // صاحب الرسالة
        // ==================================================

        const sender =
            msg?.key?.participant ||
            msg?.participant ||
            '';

        if (!sender) {
            return;
        }

        console.log(
            `🚫 تم اكتشاف جهة اتصال من: ${sender}`
        );

        // ==================================================
        // 🗑️ حذف الرسالة
        // ==================================================

        try {

            await sock.sendMessage(
                chatId,
                {
                    delete: msg.key
                }
            );

        } catch (error) {

            console.error(
                '⚠️ فشل حذف جهة الاتصال:',
                error.message
            );

        }

        // ==================================================
        // 🚫 الطرد
        // ==================================================

        try {

            await sock.groupParticipantsUpdate(
                chatId,
                [sender],
                'remove'
            );

            console.log(
                `🚫 تم طرد ${sender} بسبب إرسال جهة اتصال`
            );

        } catch (error) {

            console.error(
                '⚠️ فشل طرد العضو:',
                error.message
            );

            // لو البوت مش قادر يطرد
            // لا نوقف الحدث

        }

        // ==================================================
        // 📢 رسالة السبب بعد الطرد
        // ==================================================

        try {

            await sock.sendMessage(
                chatId,
                {
                    text:
                        `🚫 تم طرد العضو\n\n` +
                        `👤 العضو: @${sender.split('@')[0]}\n` +
                        `📱 السبب: إرسال جهة اتصال داخل المجموعة\n\n` +
                        `⚠️ حماية جهات الاتصال مفعلة`,
                    mentions: [sender]
                }
            );

        } catch (error) {

            console.error(
                '⚠️ فشل إرسال رسالة الطرد:',
                error.message
            );

        }

    } catch (error) {

        console.error(
            '❌ خطأ في حماية جهات الاتصال:',
            error
        );

    }

}

// ======================================================
// التسجيل في نظام الأحداث
// ======================================================

module.exports = {

    register(sock) {

        sock.ev.on(
            'messages.upsert',
            async update => {

                try {

                    const messages =
                        update?.messages || [];

                    for (
                        const msg
                        of messages
                    ) {

                        await handleContactProtection(
                            sock,
                            msg
                        );

                    }

                } catch (error) {

                    console.error(
                        '❌ خطأ في Event حماية الجهات:',
                        error
                    );

                }

            }
        );

        console.log(
            '   ✓ تم تفعيل Event حماية جهات الاتصال'
        );

    }

};