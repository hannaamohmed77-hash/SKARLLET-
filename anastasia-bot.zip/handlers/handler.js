const { loadPlugins } = require('./plugins');
const config = require('../config');
const logger = require('../utils/console');
const fs = require('fs-extra');
const path = require('path');

const {
    isElite,
    isOwner,
    addEliteNumber,
    extractPureNumber,
    setSessionInfo
} = require('../haykala/elite');

const commands = new Map();

let pluginsCache = null;
let pluginsLoading = null;

async function getPlugins() {

    if (pluginsCache) {
        return pluginsCache;
    }

    if (pluginsLoading) {
        return pluginsLoading;
    }

    pluginsLoading = (async () => {

        try {

            const plugins = await loadPlugins();

            pluginsCache = plugins || {};

            logger.success(
                `⚡ تم تحميل ${Object.keys(pluginsCache).length} إضافة في الذاكرة`
            );

            return pluginsCache;

        } catch (error) {

            logger.error(
                `❌ فشل تحميل الإضافات: ${error.message}`
            );

            pluginsCache = null;

            throw error;

        } finally {

            pluginsLoading = null;

        }

    })();

    return pluginsLoading;
}

async function reloadPlugins() {

    pluginsCache = null;

    if (pluginsLoading) {

        try {
            await pluginsLoading;
        } catch {}

    }

    pluginsLoading = null;

    return await getPlugins();

}

async function reloadHandler() {

    try {

        const plugins =
            await reloadPlugins();

        logger.success(
            `🔄 تمت إعادة تحميل ${Object.keys(plugins || {}).length} إضافة بنجاح`
        );

        return plugins;

    } catch (error) {

        logger.error(
            `❌ فشل إعادة تحميل النظام: ${error.message}`
        );

        throw error;

    }

}

const botPath = path.join(
    __dirname,
    '../data/bot.txt'
);

const modePath = path.join(
    __dirname,
    '../data/mode.txt'
);

let botStatus = '[on]';
let eliteMode = false;

function loadBotSettings() {

    try {

        if (fs.existsSync(botPath)) {

            botStatus =
                fs.readFileSync(
                    botPath,
                    'utf8'
                ).trim() || '[on]';

        }

    } catch (error) {

        logger.warn(
            `تعذر قراءة bot.txt: ${error.message}`
        );

    }

    try {

        if (fs.existsSync(modePath)) {

            const value =
                fs.readFileSync(
                    modePath,
                    'utf8'
                ).trim();

            eliteMode =
                value === '[on]';

        }

    } catch (error) {

        logger.warn(
            `تعذر قراءة mode.txt: ${error.message}`
        );

    }

}

function refreshBotSettings() {

    loadBotSettings();

    return {
        botStatus,
        eliteMode
    };

}

try {

    if (fs.existsSync(botPath)) {

        fs.watch(
            botPath,
            {
                persistent: false
            },
            () => {

                try {

                    botStatus =
                        fs.readFileSync(
                            botPath,
                            'utf8'
                        ).trim() || '[on]';

                } catch {}

            }
        );

    }

    if (fs.existsSync(modePath)) {

        fs.watch(
            modePath,
            {
                persistent: false
            },
            () => {

                try {

                    eliteMode =
                        fs.readFileSync(
                            modePath,
                            'utf8'
                        ).trim() === '[on]';

                } catch {}

            }
        );

    }

} catch (error) {

    logger.warn(
        `تعذر تفعيل مراقبة الإعدادات: ${error.message}`
    );

}

loadBotSettings();

function getCommandsCount() {

    return commands.size;

}

let botSessionNumber = '';
let botSessionLid = '';

function setBotSessionInfo(
    number,
    lid = ''
) {

    botSessionNumber =
        String(number || '')
            .replace(/\D/g, '');

    botSessionLid =
        String(lid || '')
            .replace(/\D/g, '');

    if (typeof setSessionInfo === 'function') {
        setSessionInfo(botSessionNumber, botSessionLid);
    }

    try {

        if (botSessionNumber) {

            const pureNumber =
                typeof extractPureNumber === 'function'
                    ? extractPureNumber(botSessionNumber)
                    : botSessionNumber;

            if (pureNumber) {

                addEliteNumber(pureNumber);

                logger.success(
                    `👑 تم تسجيل مالك الجلسة في النخبة: ${pureNumber}`
                );

            }

        }

        if (botSessionLid) {

            const pureLid =
                typeof extractPureNumber === 'function'
                    ? extractPureNumber(botSessionLid)
                    : botSessionLid;

            if (pureLid) {

                addEliteNumber(pureLid);

                logger.success(
                    `🆔 تم تسجيل LID الخاص بالمالك: ${pureLid}`
                );

            }

        }

    } catch (error) {

        logger.error(
            `❌ فشل تسجيل مالك الجلسة في النخبة: ${
                error.message
            }`
        );

    }

}

function isBotOwner(number) {
    return isOwner(number);
}

function cmd(options = {}) {

    if (
        !options.name ||
        !options.exec
    ) {

        throw new Error(
            'يجب تحديد اسم الأمر ودالة التنفيذ'
        );

    }

    commands.set(
        options.name.toLowerCase(),
        {

            name:
                options.name,

            exec:
                options.exec,

            description:
                options.description || '',

            usage:
                options.usage || '',

            category:
                options.category || 'عام',

            cooldown:
                options.cooldown || 0,

            owner:
                options.owner || false,

            group:
                options.group || false

        }
    );

    logger.info(
        `تم تسجيل الأمر: ${options.name}`
    );

}

function getMessageBody(message) {

    return (

        message.message?.conversation ||

        message.message?.extendedTextMessage?.text ||

        message.message?.imageMessage?.caption ||

        message.message?.videoMessage?.caption ||

        message.message?.documentMessage?.caption ||

        message.message?.buttonsResponseMessage?.selectedButtonId ||

        message.message?.listResponseMessage
            ?.singleSelectReply
            ?.selectedRowId ||

        ''

    );

}

function getSenderNumber(message) {

    const remoteJid =
        message.key?.remoteJid || '';

    let sender = '';

    if (
        remoteJid.endsWith('@g.us')
    ) {

        sender =
            message.key?.participant ||
            message.participant ||
            message.key?.senderPn ||
            '';

    } else {

        sender =
            message.key?.participant ||
            message.participant ||
            remoteJid ||
            '';

    }

    return String(sender)
        .split(':')[0]
        .split('@')[0]
        .replace(/\D/g, '');

}

async function handleActivityMessage(
    sock,
    message,
    plugins
) {

    try {

        const groupId =
            message.key?.remoteJid || '';

        if (
            !groupId.endsWith('@g.us')
        ) {

            return false;

        }

        const activityPlugin =
            plugins?.['فعالية'];

        if (
            !activityPlugin ||
            typeof activityPlugin.handleActivityMessage !==
            'function'
        ) {

            return false;

        }

        await activityPlugin.handleActivityMessage(
            sock,
            message
        );

        return true;

    } catch (error) {

        logger.error(
            `❌ خطأ في نظام الفعاليات: ${
                error.stack || error
            }`
        );

        return false;

    }

}

async function handleMessages(
    sock,
    { messages }
) {

    let message;

    try {

        message =
            messages?.[0];

        if (!message) {
            return;
        }

        const body =
            getMessageBody(message);

        if (!body) {
            return;
        }

        const currentPrefix =
            String(
                config.prefix || '.'
            );

        const lowerBody =
            body.toLowerCase();

        const lowerPrefix =
            currentPrefix.toLowerCase();

        const plugins =
            await getPlugins();

        if (
            !lowerBody.startsWith(
                lowerPrefix
            )
        ) {

            await handleActivityMessage(
                sock,
                message,
                plugins
            );

            return;

        }

        const content =
            body
                .slice(
                    currentPrefix.length
                )
                .trim();

        if (!content) {
            return;
        }

        const parts =
            content.split(/\s+/);

        const command =
            parts[0]?.toLowerCase();

        if (!command) {
            return;
        }

        const args =
            parts.slice(1);

        logger.info(
            `تم استلام أمر: ${command} من: ${
                message.key?.remoteJid || 'unknown'
            }`
        );

        if (
            botStatus === '[off]' &&
            command !== 'bot'
        ) {

            logger.warn(
                `البوت موقوف. تجاهل الأمر: ${command}`
            );

            return;

        }

        const senderNumber =
            getSenderNumber(message);

        message.senderNumber =
            senderNumber;

        const senderIsElite =
            isElite(senderNumber);

        if (
            eliteMode &&
            !senderIsElite
        ) {

            logger.warn(
                `تجاهل أمر من غير النخبة: ${senderNumber}`
            );

            return;

        }

        const handler =
            plugins[command];

        if (!handler) {

            logger.warn(
                `أمر غير معروف: ${command}`
            );

            return;

        }

        message.args =
            args;

        message.command =
            command;

        message.prefix =
            currentPrefix;

        message.isGroup =
            message.key?.remoteJid
                ?.endsWith('@g.us') || false;

        message.chat =
            message.key?.remoteJid || '';

        if (
            handler.elite &&
            !senderIsElite
        ) {

            logger.warn(
                `محاولة أمر نخبة من غير مصرح: ${senderNumber}`
            );

            await sock.sendMessage(
                message.key.remoteJid,
                {
                    text:
                        config.messages.ownerOnly
                }
            );

            return;

        }

        if (
            handler.owner &&
            !isBotOwner(senderNumber)
        ) {

            logger.warn(
                `محاولة أمر مالك من غير مصرح: ${senderNumber}`
            );

            await sock.sendMessage(
                message.key.remoteJid,
                {
                    text:
                        '❌ هذا الأمر مخصص لمالك البوت فقط.'
                }
            );

            return;

        }

        if (
            handler.group &&
            !message.isGroup
        ) {

            await sock.sendMessage(
                message.key.remoteJid,
                {
                    text:
                        config.messages.groupOnly
                }
            );

            return;

        }

        if (
            typeof handler === 'function'
        ) {

            await handler(
                sock,
                message
            );

        } else if (
            typeof handler.execute === 'function'
        ) {

            await handler.execute(
                sock,
                message
            );

        } else {

            throw new Error(
                `Plugin "${command}" لا يحتوي على execute صالح`
            );

        }

        logger.success(
            `تم تنفيذ الأمر: ${command}`
        );

    } catch (error) {

        logger.error(
            `✗ خطأ في معالجة الرسالة: ${
                error.stack || error
            }`
        );

        if (
            message?.key?.remoteJid
        ) {

            await sock.sendMessage(
                message.key.remoteJid,
                {
                    text:
                        config.messages.error
                }
            ).catch(() => {});

        }

    }

}

async function handleCommand(
    sock,
    msg,
    command,
    args
) {

    const commandData =
        commands.get(
            String(command || '')
                .toLowerCase()
        );

    if (!commandData) {
        return;
    }

    try {

        if (
            commandData.owner &&
            !isBotOwner(
                msg.sender
            )
        ) {

            return msg.reply(
                config.messages.ownerOnly
            );

        }

        if (
            commandData.group &&
            !msg.isGroup
        ) {

            return msg.reply(
                config.messages.groupOnly
            );

        }

        if (
            msg.isGroup &&
            Array.isArray(
                config.allowedGroups
            ) &&
            config.allowedGroups.length > 0 &&
            !config.allowedGroups.includes(
                msg.chat
            )
        ) {

            return msg.reply(
                config.messages.notAllowedGroup
            );

        }

        await commandData.exec(
            sock,
            msg,
            args
        );

    } catch (error) {

        logger.error(
            `✗ خطأ في تنفيذ الأمر ${command}:`,
            error
        );

        if (
            typeof msg.reply === 'function'
        ) {

            await msg.reply(
                config.messages.error
            ).catch(() => {});

        }

    }

}

function createPluginHandler(
    options = {}
) {

    const pluginHandler =
        options.execute ||
        (() => {});

    pluginHandler.elite =
        options.elite || false;

    pluginHandler.owner =
        options.owner || false;

    pluginHandler.group =
        options.group || false;

    pluginHandler.desc =
        options.desc ||
        'لا يوجد وصف';

    pluginHandler.command =
        options.command ||
        'لا يوجد أمر محدد';

    pluginHandler.usage =
        options.usage ||
        'لا توجد معلومات استخدام';

    return pluginHandler;

}

async function handleMessagesLoader() {

    try {

        await getPlugins();

        logger.success(
            '⚡ تم تهيئة نظام الرسائل والإضافات بنجاح.'
        );

    } catch (error) {

        logger.error(
            '❌ فشل تهيئة نظام الرسائل:',
            error
        );

    }

}

module.exports = {

    handleMessages,

    handleCommand,

    cmd,

    commands,

    getCommandsCount,

    createPluginHandler,

    handleMessagesLoader,

    setBotSessionInfo,

    isBotOwner,

    reloadPlugins,

    reloadHandler,

    getPlugins,

    refreshBotSettings,

    handleActivityMessage

};