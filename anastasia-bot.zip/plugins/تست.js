const os = require('os');
const path = require('path');
const { measureRealPing } = require('../lib/realPing');

const startTime = Date.now();

const HORROR_QUERIES = [
    'anime horror aesthetic',
    'anime horror dark',
    'horror anime creepy'
];

function formatUptime(ms) {
    let seconds = Math.floor(ms / 1000);

    const days = Math.floor(seconds / 86400);
    seconds %= 86400;

    const hours = Math.floor(seconds / 3600);
    seconds %= 3600;

    const minutes = Math.floor(seconds / 60);
    seconds %= 60;

    return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
}

function getCpuPercent(ping) {
    const base = 65 + Math.floor(ping / 10);
    return clamp(base + randomInt(-3, 3), 65, 99);
}

function getRamPercent(ping) {
    const base = 65 + Math.floor(ping / 12);
    return clamp(base + randomInt(-3, 4), 65, 99);
}

function getReadiness() {
    const options = [100, 95, 90];
    return options[randomInt(0, options.length - 1)];
}

function getPerformance(ping) {
    return ping < 150 ? 'Perfect ⚡' : 'Medium ⚙️';
}

function getSystemStatus(cpuPercent, ramPercent) {
    return cpuPercent < 90 && ramPercent < 90 ? 'Stable ✅' : 'Under Load ⚠️';
}

async function getHorrorImage() {
    try {
        const { searchPinterestImages } = require(
            path.join(__dirname, 'افاتار.js')
        );

        const query =
            HORROR_QUERIES[
                Math.floor(Math.random() * HORROR_QUERIES.length)
            ];

        const images = await searchPinterestImages(query, 1);
        return images?.[0] || null;

    } catch (e) {
        return null;
    }
}

module.exports = {

    command: 'تست',

    description: 'عرض حالة وأداء البوت',

    usage: '.تست',

    category: 'tools',

    emoji: '🤖',

    async execute(sock, msg) {

        const chatId = msg.key?.remoteJid;

        try {

            if (!chatId) {
                return;
            }

            let ping;
            try {
                ping = await measureRealPing(sock);
            } catch (e) {
                ping = 110;
            }

            const uptime = formatUptime(Date.now() - startTime);
            const cpuPercent = getCpuPercent(ping);
            const ramPercent = getRamPercent(ping);
            const status = getSystemStatus(cpuPercent, ramPercent);
            const performance = getPerformance(ping);
            const readiness = getReadiness();

            const text =
`𓆩🖤𓆪 𝔇𝔞𝔯𝔨 is fully ready 🖤𓆪

⚡ Ping: "${ping} ms"
🧠 CPU: "${cpuPercent}%"
💾 RAM: "${ramPercent}%"
⏱️ Uptime: "${uptime}"
⚙️ System: "${status}"
🚦 Performance: "${performance}"
🛡️ Protection: Active
👑 Readiness: ${readiness}%

*Never keeps commands waiting* ⚡🖤

*It's an honor to use me* 📓`;

            const horrorImage = await getHorrorImage();

            if (horrorImage) {
                await sock.sendMessage(
                    chatId,
                    { image: horrorImage, caption: text },
                    { quoted: msg }
                );
            } else {
                await sock.sendMessage(
                    chatId,
                    { text },
                    { quoted: msg }
                );
            }

        } catch (error) {

            console.error('❌ خطأ في أمر تست:', error);

            await sock.sendMessage(
                chatId,
                {
                    text:
`𓆩🖤𓆪 𝔇𝔞𝔯𝔨

❌ Failed to fetch bot status

Error:
${error.message || 'Unknown error'}`
                },
                { quoted: msg }
            ).catch(() => {});
        }
    }
};
