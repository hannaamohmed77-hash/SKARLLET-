const fs = require('fs');
const path = require('path');

// ======================================================
// 🛡️ ملف بيانات حماية الإشراف
// ======================================================

const DATA_DIR = path.join(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'modProtection.json');

// إنشاء مجلد البيانات
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}

// ======================================================
// 📂 تحميل البيانات
// ======================================================

function loadData() {
    try {

        if (!fs.existsSync(DATA_FILE)) {
            return {};
        }

        return JSON.parse(
            fs.readFileSync(DATA_FILE, 'utf8')
        );

    } catch (error) {

        console.error(
            '⚠️ خطأ في تحميل بيانات حماية الإشراف:',
            error.message
        );

        return {};
    }
}

// ======================================================
// 💾 حفظ البيانات
// ======================================================

function saveData(data) {

    try {

        fs.writeFileSync(
            DATA_FILE,
            JSON.stringify(data, null, 2),
            'utf8'
        );

    } catch (error) {

        console.error(
            '⚠️ خطأ في حفظ بيانات حماية الإشراف:',
            error.message
        );
    }
}

// ======================================================
// ⚡ الأمر
// ======================================================

module.exports = {

    command: 'اشراف',

    description: 'تشغيل أو إيقاف حماية الإشراف',

    group: true,

    async execute(sock, message) {

        try {

            const chatId =
                message?.key?.remoteJid;

            if (
                !chatId ||
                !chatId.endsWith('@g.us')
            ) {
                return;
            }

            // ==================================================
            // 🔍 استخراج الوسيط
            // ==================================================

            const args =
                message?.args || [];

            const action =
                args[0]?.toString().trim().toLowerCase();

            // ==================================================
            // 📂 البيانات
            // ==================================================

            const data =
                loadData();

            // ==================================================
            // 🛡️ تشغيل الحماية
            // ==================================================

            if (
                action === 'تشغيل' ||
                action === 'on'
            ) {

                data[chatId] = true;

                saveData(data);

                await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '🛡️ *حماية الإشرافات*\n\n' +
                            '✅ تم تشغيل حماية الإشرافات\n\n' +
                            '👑 النخبة فقط مسموح لهم بتعديل الإشرافات\n' +
                            '🚫 أي تعديل من غير النخبة سيتم إلغاؤه'
                    }
                );

                return;
            }

            // ==================================================
            // 🔓 إيقاف الحماية
            // ==================================================

            if (
                action === 'ايقاف' ||
                action === 'off'
            ) {

                data[chatId] = false;

                saveData(data);

                await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '🛡️ *حماية الإشرافات*\n\n' +
                            '⛔ تم إيقاف حماية الإشرافات\n\n' +
                            'البوت لن يتدخل في تغييرات الإشرافات.'
                    }
                );

                return;
            }

            // ==================================================
            // ℹ️ استخدام الأمر
            // ==================================================

            await sock.sendMessage(
                chatId,
                {
                    text:
                        '🛡️ *طريقة الاستخدام*\n\n' +
                        '• `.اشراف تشغيل`\n' +
                        '  ↳ تشغيل حماية الإشرافات\n\n' +
                        '• `.اشراف ايقاف`\n' +
                        '  ↳ إيقاف حماية الإشرافات'
                }
            );

        } catch (error) {

            console.error(
                '❌ خطأ في أمر حماية الإشراف:',
                error
            );

        }
    }
};