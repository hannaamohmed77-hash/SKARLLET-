'use strict';

const fs = require('fs-extra');
const path = require('path');

const SETTINGS_FILE = path.join(
    process.cwd(),
    'data',
    'linkProtection.json'
);

// ======================================================
// 📂 قراءة الإعدادات
// ======================================================

async function loadSettings() {

    try {

        await fs.ensureDir(
            path.dirname(SETTINGS_FILE)
        );

        if (
            !await fs.pathExists(
                SETTINGS_FILE
            )
        ) {
            return {};
        }

        const data =
            await fs.readJson(
                SETTINGS_FILE
            );

        return (
            data &&
            typeof data === 'object'
        )
            ? data
            : {};

    } catch (error) {

        console.error(
            '⚠️ خطأ في قراءة إعدادات حماية الروابط:',
            error.message
        );

        return {};
    }

}

// ======================================================
// 💾 حفظ الإعدادات
// ======================================================

async function saveSettings(data) {

    try {

        await fs.ensureDir(
            path.dirname(SETTINGS_FILE)
        );

        await fs.writeJson(
            SETTINGS_FILE,
            data,
            {
                spaces: 2
            }
        );

        return true;

    } catch (error) {

        console.error(
            '⚠️ خطأ في حفظ إعدادات حماية الروابط:',
            error.message
        );

        return false;
    }

}

// ======================================================
// 🔢 استخراج رقم المرسل
// ======================================================

function getSenderNumber(msg) {

    return String(
        msg?.senderNumber ||
        msg?.key?.participant ||
        msg?.participant ||
        ''
    )
        .split(':')[0]
        .split('@')[0]
        .replace(/\D/g, '');

}

// ======================================================
// 👑 التحقق من الصلاحيات
// ======================================================

async function hasPermission(
    sock,
    msg
) {

    try {

        const chatId =
            msg?.key?.remoteJid;

        if (!chatId) {
            return false;
        }

        const senderNumber =
            getSenderNumber(msg);

        // استيراد نظام النخبة والمالك
        const {
            isElite,
            isOwner
        } = require('../haykala/elite');

        // المالك
        if (
            typeof isOwner === 'function' &&
            isOwner(senderNumber)
        ) {
            return true;
        }

        // النخبة
        if (
            typeof isElite === 'function' &&
            isElite(senderNumber)
        ) {
            return true;
        }

        // الحصول على بيانات المجموعة
        const metadata =
            await sock.groupMetadata(chatId);

        const participants =
            metadata?.participants || [];

        const sender =
            participants.find(
                participant => {

                    const id =
                        String(
                            participant.id ||
                            participant.jid ||
                            ''
                        )
                            .split(':')[0]
                            .split('@')[0]
                            .replace(/\D/g, '');

                    return id === senderNumber;

                }
            );

        // أدمن المجموعة
        if (
            sender?.admin === 'admin' ||
            sender?.admin === 'superadmin'
        ) {
            return true;
        }

        return false;

    } catch (error) {

        console.error(
            '⚠️ خطأ في التحقق من الصلاحيات:',
            error.message
        );

        return false;
    }

}

// ======================================================
// 📢 إرسال رد
// ======================================================

async function reply(
    sock,
    msg,
    text
) {

    const chatId =
        msg?.key?.remoteJid;

    if (!chatId) return;

    await sock.sendMessage(
        chatId,
        {
            text
        },
        {
            quoted: msg
        }
    );

}

// ======================================================
// ⚡ Plugin
// ======================================================

module.exports = {

    command: 'روابط',

    description:
        'إدارة نظام حماية الروابط',

    group: true,

    async execute(sock, msg) {

        try {

            const chatId =
                msg?.key?.remoteJid;

            if (
                !chatId ||
                !chatId.endsWith('@g.us')
            ) {

                return await reply(
                    sock,
                    msg,
                    '❌ هذا الأمر يعمل داخل المجموعات فقط.'
                );

            }

            // ==============================================
            // 🛡️ التحقق من الصلاحيات
            // ==============================================

            const allowed =
                await hasPermission(
                    sock,
                    msg
                );

            if (!allowed) {

                return await reply(
                    sock,
                    msg,
                    '❌ هذا الأمر مخصص لأدمن المجموعة والنخبة فقط.'
                );

            }

            // الـ Handler يضيف args إلى message
            const action =
                String(
                    msg?.args?.[0] || ''
                )
                    .trim()
                    .toLowerCase();

            const settings =
                await loadSettings();

            // ==============================================
            // 🟢 تشغيل
            // ==============================================

            if (
                action === 'تشغيل' ||
                action === 'on'
            ) {

                settings[chatId] = true;

                const saved =
                    await saveSettings(
                        settings
                    );

                if (!saved) {

                    return await reply(
                        sock,
                        msg,
                        '❌ حدث خطأ أثناء حفظ الإعدادات.'
                    );

                }

                return await reply(
                    sock,
                    msg,
                    `🛡️ *تم تشغيل حماية الروابط*

🚫 سيتم حذف جميع الروابط الممنوعة تلقائيًا.

⚠️ نظام العقوبات:

1️⃣ المخالفة الأولى: إنذار أول
2️⃣ المخالفة الثانية: تحذير أخير
3️⃣ المخالفة الثالثة: طرد تلقائي

👑 النخبة والمالك مستثنون من الحماية.`
                );

            }

            // ==============================================
            // 🔴 إيقاف
            // ==============================================

            if (
                action === 'إيقاف' ||
                action === 'ايقاف' ||
                action === 'off'
            ) {

                settings[chatId] = false;

                const saved =
                    await saveSettings(
                        settings
                    );

                if (!saved) {

                    return await reply(
                        sock,
                        msg,
                        '❌ حدث خطأ أثناء حفظ الإعدادات.'
                    );

                }

                return await reply(
                    sock,
                    msg,
                    `🔓 *تم إيقاف حماية الروابط*

🔗 أصبح إرسال الروابط مسموحًا في المجموعة.`
                );

            }

            // ==============================================
            // 📊 عرض الحالة والمساعدة
            // ==============================================

            const enabled =
                settings[chatId] === true;

            return await reply(
                sock,
                msg,
                `🔗 *نظام حماية الروابط*

📊 الحالة الحالية:
${enabled ? '🟢 مفعلة' : '🔴 متوقفة'}

━━━━━━━━━━━━━━━

📌 *طريقة الاستخدام:*

🟢 *.روابط تشغيل*
لتفعيل حماية الروابط.

🔴 *.روابط إيقاف*
لإيقاف حماية الروابط.

━━━━━━━━━━━━━━━

🛡️ *نظام العقوبات عند التفعيل:*

1️⃣ إنذار أول
2️⃣ تحذير أخير
3️⃣ طرد تلقائي

👑 المالك والنخبة مستثنون.`
            );

        } catch (error) {

            console.error(
                '❌ خطأ في Plugin الروابط:',
                error
            );

            throw error;
        }

    }

};