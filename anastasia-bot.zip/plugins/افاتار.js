const axios = require('axios');
const cheerio = require('cheerio');

const PINTEREST_SEARCH =
    'https://www.pinterest.com/search/pins/?q=';

function getText(msg) {

    return (
        msg.message?.conversation ||
        msg.message?.extendedTextMessage?.text ||
        msg.message?.imageMessage?.caption ||
        msg.message?.videoMessage?.caption ||
        msg.message?.documentMessage?.caption ||
        ''
    );

}

function isGroup(msg) {

    return Boolean(
        msg.key?.remoteJid?.endsWith('@g.us')
    );

}

function getMentionedJid(msg) {

    const context =
        msg.message
            ?.extendedTextMessage
            ?.contextInfo;

    const mentioned =
        context?.mentionedJid;

    if (
        Array.isArray(mentioned) &&
        mentioned.length
    ) {

        return mentioned[0];

    }

    return null;

}

function getDisplayNumber(jid) {

    if (!jid) {
        return '';
    }

    return String(jid)
        .split('@')[0]
        .split(':')[0]
        .replace(/\D/g, '');

}

function getOriginalPinterestUrl(url) {

    if (
        typeof url !== 'string'
    ) {

        return url;

    }

    let original =
        url
            .replace(/\\u002F/g, '/')
            .replace(/\\\//g, '/')
            .replace(/&amp;/g, '&');

    if (
        original.includes('i.pinimg.com')
    ) {

        original =
            original.replace(
                /\/(?:60x60|170x|236x|474x|564x|736x|1200x)\//i,
                '/originals/'
            );

    }

    return original;

}

function extractImageUrls(html) {

    const urls =
        new Set();

    function addUrl(value) {

        if (!value) {
            return;
        }

        let url =
            String(value)
                .replace(/\\u002F/g, '/')
                .replace(/\\\//g, '/')
                .replace(/&amp;/g, '&')
                .trim();

        if (
            !/^https?:\/\//i.test(url)
        ) {

            return;

        }

        if (
            /\/(?:60x60|170x|236x)\//i.test(url)
        ) {

            return;

        }

        if (
            /\.(jpg|jpeg|png|webp)(?:[?#&]|$)/i.test(url)
        ) {

            urls.add(url);

        }

    }

    const $ =
        cheerio.load(html);

    $('img').each((_, element) => {

        addUrl(
            $(element).attr('src')
        );

        addUrl(
            $(element).attr('data-src')
        );

        addUrl(
            $(element).attr('data-lazy-src')
        );

        const srcset =
            $(element).attr('srcset');

        if (srcset) {

            srcset
                .split(',')
                .forEach(item => {

                    const url =
                        item
                            .trim()
                            .split(/\s+/)[0];

                    addUrl(url);

                });

        }

    });

    const regex =
        /https?:\\?\/\\?\/[^"'<>\\\s]+/gi;

    const matches =
        html.match(regex) || [];

    for (
        const match of matches
    ) {

        const url =
            match
                .replace(/\\u002F/g, '/')
                .replace(/\\\//g, '/')
                .replace(/\\u0026/g, '&');

        addUrl(url);

    }

    return [...urls].sort((a, b) => {

        let scoreA = 0;
        let scoreB = 0;

        if (
            /i\.pinimg\.com/i.test(a)
        ) {

            scoreA += 100;

        }

        if (
            /i\.pinimg\.com/i.test(b)
        ) {

            scoreB += 100;

        }

        if (
            /\/originals\//i.test(a)
        ) {

            scoreA += 1000;

        }

        if (
            /\/originals\//i.test(b)
        ) {

            scoreB += 1000;

        }

        return scoreB - scoreA;

    });

}

async function downloadImage(url) {

    try {

        const response =
            await axios.get(
                url,
                {
                    responseType:
                        'arraybuffer',

                    timeout:
                        15000,

                    maxContentLength:
                        30 * 1024 * 1024,

                    maxBodyLength:
                        30 * 1024 * 1024,

                    headers: {

                        'User-Agent':
                            'Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/131.0.0.0 Mobile Safari/537.36',

                        'Accept':
                            'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',

                        'Referer':
                            'https://www.pinterest.com/'

                    }

                }
            );

        if (
            !response.data ||
            response.data.length < 5000
        ) {

            return null;

        }

        return Buffer.from(
            response.data
        );

    } catch {

        return null;

    }

}

async function searchPinterestImages(
    query,
    amount
) {

    try {

        const searchUrl =
            PINTEREST_SEARCH +
            encodeURIComponent(query);

        const response =
            await axios.get(
                searchUrl,
                {
                    timeout:
                        20000,

                    maxContentLength:
                        30 * 1024 * 1024,

                    headers: {

                        'User-Agent':
                            'Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/131.0.0.0 Mobile Safari/537.36',

                        'Accept':
                            'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',

                        'Accept-Language':
                            'en-US,en;q=0.9',

                        'Referer':
                            'https://www.google.com/'

                    }

                }
            );

        const urls =
            extractImageUrls(
                String(response.data)
            );

        if (!urls.length) {

            return [];

        }

        const candidates =
            [];

        for (
            const url of urls
        ) {

            const original =
                getOriginalPinterestUrl(
                    url
                );

            if (
                original &&
                !candidates.includes(original)
            ) {

                candidates.push(
                    original
                );

            }

            if (
                !candidates.includes(url)
            ) {

                candidates.push(url);

            }

        }

        const images =
            [];

        const usedUrls =
            new Set();

        for (
            const url of candidates
        ) {

            if (
                images.length >= amount
            ) {

                break;

            }

            if (
                usedUrls.has(url)
            ) {

                continue;

            }

            usedUrls.add(url);

            const buffer =
                await downloadImage(
                    url
                );

            if (
                buffer &&
                buffer.length > 5000
            ) {

                images.push(
                    buffer
                );

            }

        }

        return images;

    } catch {

        return [];

    }

}

function getAmount(value) {

    if (!value) {

        return 5;

    }

    const number =
        parseInt(
            value,
            10
        );

    if (
        isNaN(number)
    ) {

        return 5;

    }

    return Math.min(
        Math.max(number, 1),
        20
    );

}

module.exports = {

    command: 'افاتار',

    description:
        'جلب مجموعة افتارات من Pinterest وإرسالها كألبوم',

    category: 'tools',

    emoji: '👤',

    searchPinterestImages,
    downloadImage,

    async execute(sock, msg) {

        const chatId =
            msg.key?.remoteJid;

        if (!chatId) {

            return;

        }

        try {

            if (!isGroup(msg)) {

                await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ الأمر يعمل داخل المجموعات فقط.'
                    },
                    {
                        quoted: msg
                    }
                );

                return;

            }

            const text =
                getText(msg).trim();

            const parts =
                text.split(/\s+/);

            const characterName =
                parts[1];

            if (!characterName) {

                await sock.sendMessage(
                    chatId,
                    {
                        text:
`❌ الاستخدام:

.افتار اسم_الشخصية

أو:

.افتار اسم_الشخصية 20

أو:

.افتار اسم_الشخصية 20 @العضو

مثال:

.افتار يوريتشي
.افتار غوجو 10
.افتار يوتا 20 @فلان`
                    },
                    {
                        quoted: msg
                    }
                );

                return;

            }

            let amount =
                5;

            if (
                parts[2] &&
                /^\d+$/.test(parts[2])
            ) {

                amount =
                    getAmount(parts[2]);

            }

            const mentionedJid =
                getMentionedJid(msg);

            const requesterJid =
                mentionedJid ||
                msg.key?.participant ||
                msg.participant ||
                msg.key?.remoteJid;

            const displayNumber =
                getDisplayNumber(
                    requesterJid
                );

            const query =
                `${characterName} anime avatar pfp`;

            const images =
                await searchPinterestImages(
                    query,
                    amount
                );

            if (!images.length) {

                await sock.sendMessage(
                    chatId,
                    {
                        text:
                            `❌ ملقتش صور لـ ${characterName}.`
                    },
                    {
                        quoted: msg
                    }
                );

                return;

            }

            const finalAmount =
                images.length;

            const caption =
`╭━━━〔 🖼️ 𝔇𝔄ℜ𝔎 𝔄𝖁𝔄𝔗𝔄ℜ 〕━━━╮

*✦ طلب افتارات ${characterName}*

*🖼️ العدد : ${finalAmount}*
*👤 صاحب الطلب : @${displayNumber}*

╰━━━━━━━━━━━━━━━━━━━━╯`;

            await sock.sendMessage(
                chatId,
                {
                    image:
                        images[0],

                    caption,

                    mentions:
                        requesterJid
                            ? [requesterJid]
                            : []
                },
                {
                    quoted: msg
                }
            );

            for (
                let i = 1;
                i < images.length;
                i++
            ) {

                await sock.sendMessage(
                    chatId,
                    {
                        image:
                            images[i]
                    }
                );

            }

        } catch (error) {

            console.error(
                '❌ خطأ في أمر افتار:',
                error?.stack || error
            );

            await sock.sendMessage(
                chatId,
                {
                    text:
                        '❌ حصل خطأ أثناء جلب الافتارات.'
                },
                {
                    quoted: msg
                }
            ).catch(() => {});

        }

    }

};