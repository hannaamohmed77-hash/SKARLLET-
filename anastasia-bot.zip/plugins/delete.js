const {
    jidDecode
} = require('@whiskeysockets/baileys');

const {
    isElite
} = require('../haykala/elite.js');

// ==========================================
// توحيد JID
// ==========================================

function normalizeJid(jid) {
    if (!jid) return null;

    try {

        const decoded =
            jidDecode(jid);

        if (decoded?.user) {
            return `${decoded.user}@s.whatsapp.net`;
        }

        const user =
            String(jid)
                .split('@')[0]
                .split(':')[0]
                .trim();

        return user
            ? `${user}@s.whatsapp.net`
            : null;

    } catch {

        const user =
            String(jid)
                .split('@')[0]
                .split(':')[0]
                .trim();

        return user
            ? `${user}@s.whatsapp.net`
            : null;
    }
}

// ==========================================
// الحصول على صاحب الرسالة
// ==========================================

function getSender(msg) {
    return (
        msg.key?.participant ||
        msg.participant ||
        msg.key?.remoteJid ||
        null
    );
}

// ==========================================
// الأمر
// ==========================================

module.exports = {

    command: 'حذف',

    description:
        'حذف رسالة بالرد عليها.',

    usage:
        '.حذف ← بالرد على الرسالة',
    emoji: '🗑️',

    async execute(sock, msg) {

        const chatId =
            msg.key.remoteJid;

        try {

            // ==================================
            // التحقق من المرسل
            // ==================================

            const sender =
                normalizeJid(
                    getSender(msg)
                );

            if (
                !sender ||
                !isElite(sender)
            ) {

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ لا تملك صلاحية استخدام هذا الأمر.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================
            // التأكد من الرد على رسالة
            // ==================================

            const context =
                msg.message?.extendedTextMessage
                    ?.contextInfo;

            if (
                !context?.stanzaId ||
                !context?.participant
            ) {

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ قم بالرد على الرسالة التي تريد حذفها.\n\n' +
                            'مثال:\n' +
                            '↩️ رد على الرسالة ثم اكتب: `.حذف`'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================
            // بيانات الرسالة المراد حذفها
            // ==================================

            const targetId =
                context.stanzaId;

            const targetParticipant =
                context.participant;

            // ==================================
            // هل الرسالة من البوت؟
            // ==================================

            const botJid =
                normalizeJid(
                    sock.user?.id
                );

            const targetJid =
                normalizeJid(
                    targetParticipant
                );

            const targetIsBot =
                botJid &&
                targetJid &&
                botJid === targetJid;

            // ==================================
            // حذف الرسالة
            // ==================================

            await sock.sendMessage(
                chatId,
                {
                    delete: {
                        remoteJid: chatId,

                        fromMe:
                            Boolean(targetIsBot),

                        id:
                            targetId,

                        participant:
                            targetParticipant
                    }
                }
            );

            // ==================================
            // حذف أمر .حذف نفسه
            // ==================================

            await sock.sendMessage(
                chatId,
                {
                    delete: {
                        remoteJid:
                            chatId,

                        fromMe:
                            Boolean(
                                msg.key.fromMe
                            ),

                        id:
                            msg.key.id,

                        participant:
                            msg.key.participant ||
                            chatId
                    }
                }
            );

        } catch (err) {

            console.error(
                '❌ فشل تنفيذ أمر الحذف:',
                err
            );

            try {

                await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ فشل حذف الرسالة.\n\n' +
                            'تأكد أن البوت مشرف في المجموعة وأن الرسالة قابلة للحذف.'
                    },
                    {
                        quoted: msg
                    }
                );

            } catch {}
        }
    }
};