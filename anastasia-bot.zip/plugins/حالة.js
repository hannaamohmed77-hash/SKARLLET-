const fs = require('fs');
const { isOwner, isElite, extractPureNumber } = require('../haykala/elite');
const { measureRealPing } = require('../lib/realPing');

const getSenderJid = (msg) => {
    return (
        msg.key?.participant ||
        msg.participant ||
        msg.key?.remoteJid ||
        ''
    );
};

const getRank = (senderNumber) => {
    if (isOwner(senderNumber)) return 'Owner';
    if (isElite(senderNumber)) return 'Elite';
    return 'Member';
};

const getCommandsCount = () => {
    try {
        const pluginsPath = __dirname;
        const files = fs.readdirSync(pluginsPath);

        return files.filter(file => {
            return (
                file.endsWith('.js') &&
                file !== 'state.js'
            );
        }).length;

    } catch (error) {
        console.error('❌ فشل حساب عدد الأوامر:', error.message);
        return 0;
    }
};

const formatUptime = (seconds) => {
    seconds = Math.floor(seconds);

    const days = Math.floor(seconds / 86400);
    seconds %= 86400;

    const hours = Math.floor(seconds / 3600);
    seconds %= 3600;

    const minutes = Math.floor(seconds / 60);
    seconds %= 60;

    return `${days}d ${hours}h ${minutes}m ${seconds}s`;
};

const getEgyptDateTime = () => {
    const now = new Date();

    const date = new Intl.DateTimeFormat('en-US', {
        timeZone: 'Africa/Cairo',
        weekday: 'long',
        month: 'long',
        day: '2-digit',
        year: 'numeric'
    }).format(now);

    const time = new Intl.DateTimeFormat('en-US', {
        timeZone: 'Africa/Cairo',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
    }).format(now);

    return { date, time };
};

module.exports = {

    command: 'حالة',
    description: 'عرض حالة البوت ومعلومات الجلسة',
    emoji: '📊',
    category: 'tools',

    async execute(sock, msg) {
        try {
            const chatId = msg.key?.remoteJid;
            if (!chatId) return;

            const senderNumber = extractPureNumber(getSenderJid(msg));
            const rank = getRank(senderNumber);

            let ping;
            try {
                ping = await measureRealPing(sock);
            } catch (e) {
                ping = 'غير متاح';
            }

            const commandsCount = getCommandsCount();
            const uptime = formatUptime(process.uptime());
            const { date, time } = getEgyptDateTime();

            const statusMessage =
`🟢 *BOT STATUS*

⚡ *Ping:* ${typeof ping === 'number' ? ping + 'ms' : ping}
💾 *Commands:* ${commandsCount}
👑 *Rank:* ${rank}
⏱️ *Uptime:* ${uptime}
📅 *Date:* ${date}
🕐 *Time:* ${time}`;

            await sock.sendMessage(
                chatId,
                { text: statusMessage },
                { quoted: msg }
            );

        } catch (error) {
            console.error('❌ خطأ في أمر حالة:', error);

            await sock.sendMessage(
                msg.key?.remoteJid,
                { text: '❌ حدث خطأ أثناء جلب حالة البوت.' },
                { quoted: msg }
            ).catch(() => {});
        }
    }
};