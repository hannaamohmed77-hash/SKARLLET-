'use strict';

const fs = require('fs-extra');
const path = require('path');

const {
    isElite,
    isOwner,
    extractPureNumber
} = require('../haykala/elite');

const SETTINGS_FILE = path.join(
    process.cwd(),
    'data',
    'spamProtection.json'
);

// ======================================================
// 📂 قراءة البيانات
// ======================================================

async function loadData() {

    try {

        await fs.ensureDir(
            path.dirname(SETTINGS_FILE)
        );

        if (
            !await fs.pathExists(
                SETTINGS_FILE
            )
        ) {
            return {};
        }

        const data =
            await fs.readJson(
                SETTINGS_FILE
            );

        return (
            data &&
            typeof data === 'object'
        )
            ? data
            : {};

    } catch {

        return {};

    }

}

// ======================================================
// 💾 حفظ البيانات
// ======================================================

async function saveData(data) {

    try {

        await fs.ensureDir(
            path.dirname(SETTINGS_FILE)
        );

        await fs.writeJson(
            SETTINGS_FILE,
            data,
            {
                spaces: 2
            }
        );

        return true;

    } catch (error) {

        console.error(
            'فشل حفظ إعدادات الإسبام:',
            error.message
        );

        return false;

    }

}

// ======================================================
// 👤 استخراج الرقم
// ======================================================

function normalizeNumber(value) {

    if (!value) return '';

    return String(value)
        .split(':')[0]
        .split('@')[0]
        .replace(/\D/g, '');

}

// ======================================================
// 👑 صلاحية المستخدم
// ======================================================

async function hasPermission(
    sock,
    msg
) {

    try {

        const senderNumber =
            msg?.senderNumber ||
            normalizeNumber(
                msg?.key?.participant
            );

        if (!senderNumber) {
            return false;
        }

        // مالك البوت
        if (
            typeof isOwner === 'function' &&
            isOwner(senderNumber)
        ) {
            return true;
        }

        // النخبة
        if (
            typeof isElite === 'function' &&
            isElite(senderNumber)
        ) {
            return true;
        }

        const chatId =
            msg?.key?.remoteJid;

        const metadata =
            await sock.groupMetadata(chatId);

        const participant =
            metadata?.participants?.find(
                p =>
                    normalizeNumber(
                        p.id ||
                        p.jid
                    ) === senderNumber
            );

        return (
            participant?.admin === 'admin' ||
            participant?.admin === 'superadmin'
        );

    } catch {

        return false;

    }

}

// ======================================================
// 📢 رد
// ======================================================

async function reply(
    sock,
    msg,
    text
) {

    const chatId =
        msg?.key?.remoteJid;

    if (!chatId) return;

    await sock.sendMessage(
        chatId,
        { text },
        { quoted: msg }
    );

}

// ======================================================
// 🎯 استخراج الشخص من المنشن
// ======================================================

function getMentionedUser(msg) {

    try {

        const mentions =
            msg?.message
                ?.extendedTextMessage
                ?.contextInfo
                ?.mentionedJid || [];

        if (
            Array.isArray(mentions) &&
            mentions.length
        ) {

            return mentions[0];

        }

        return '';

    } catch {

        return '';

    }

}

// ======================================================
// ⚡ Plugin
// ======================================================

module.exports = {

    command: 'اسبام',

    description:
        'إدارة حماية الإسبام',

    group: true,

    async execute(sock, msg) {

        try {

            const chatId =
                msg?.key?.remoteJid;

            if (
                !chatId ||
                !chatId.endsWith('@g.us')
            ) {

                return await reply(
                    sock,
                    msg,
                    '❌ هذا الأمر يعمل داخل المجموعات فقط.'
                );

            }

            // ==============================================
            // 🛡️ الصلاحيات
            // ==============================================

            const allowed =
                await hasPermission(
                    sock,
                    msg
                );

            if (!allowed) {

                return await reply(
                    sock,
                    msg,
                    '❌ هذا الأمر مخصص لأدمن المجموعة والنخبة ومالك البوت.'
                );

            }

            const action =
                String(
                    msg?.args?.[0] || ''
                )
                    .trim()
                    .toLowerCase();

            const data =
                await loadData();

            // إنشاء إعدادات الجروب
            if (
                !data[chatId] ||
                typeof data[chatId] !== 'object'
            ) {

                data[chatId] = {
                    enabled: false,
                    ignored: []
                };

            }

            if (
                !Array.isArray(
                    data[chatId].ignored
                )
            ) {

                data[chatId].ignored = [];

            }

            // ==============================================
            // 🟢 تشغيل
            // ==============================================

            if (
                action === 'تشغيل' ||
                action === 'on'
            ) {

                data[chatId].enabled = true;

                await saveData(data);

                return await reply(
                    sock,
                    msg,
                    `🛡️ *تم تشغيل حماية الإسبام*

🚨 سيتم مراقبة الرسائل المتتالية والملصقات.

📊 النظام الحالي:
• 6 رسائل خلال 5 ثوانٍ = مخالفة

⚠️ العقوبات:
1️⃣ إنذار أول
2️⃣ تحذير أخير
3️⃣ طرد تلقائي

👑 النخبة والمالك والمستثنون لا يتم احتسابهم.`
                );

            }

            // ==============================================
            // 🔴 إيقاف
            // ==============================================

            if (
                action === 'إيقاف' ||
                action === 'ايقاف' ||
                action === 'off'
            ) {

                data[chatId].enabled = false;

                await saveData(data);

                return await reply(
                    sock,
                    msg,
                    `🔓 *تم إيقاف حماية الإسبام*

لن يتم مراقبة الرسائل المتتالية في هذه المجموعة.`
                );

            }

            // ==============================================
            // 👤 تجاهل شخص
            // ==============================================

            if (
                action === 'تجاهل'
            ) {

                const targetJid =
                    getMentionedUser(msg);

                if (!targetJid) {

                    return await reply(
                        sock,
                        msg,
                        `❌ قم بعمل منشن للشخص.

📌 مثال:
*.اسبام تجاهل @الشخص*`
                    );

                }

                const targetNumber =
                    typeof extractPureNumber === 'function'
                        ? extractPureNumber(targetJid)
                        : normalizeNumber(targetJid);

                if (!targetNumber) {

                    return await reply(
                        sock,
                        msg,
                        '❌ تعذر استخراج رقم الشخص.'
                    );

                }

                const ignored =
                    data[chatId].ignored;

                const index =
                    ignored.indexOf(
                        targetNumber
                    );

                // لو موجود → إزالة التجاهل
                if (index !== -1) {

                    ignored.splice(
                        index,
                        1
                    );

                    await saveData(data);

                    return await reply(
                        sock,
                        msg,
                        `🔓 *تم إزالة الشخص من التجاهل*

@${targetNumber}
سيتم احتساب الإسبام منه الآن.`,
                    );

                }

                // إضافة للتجاهل
                ignored.push(
                    targetNumber
                );

                await saveData(data);

                return await reply(
                    sock,
                    msg,
                    `🛡️ *تم استثناء الشخص من حماية الإسبام*

👤 @${targetNumber}

لن يتم احتساب الرسائل المتتالية منه.`,
                );

            }

            // ==============================================
            // 📊 الحالة والمساعدة
            // ==============================================

            const enabled =
                data[chatId].enabled === true;

            const ignoredCount =
                data[chatId].ignored.length;

            return await reply(
                sock,
                msg,
                `🚨 *نظام حماية الإسبام*

📊 الحالة:
${enabled ? '🟢 مفعلة' : '🔴 متوقفة'}

━━━━━━━━━━━━━━

⚙️ *إعدادات الحماية:*

📨 الحد: 6 رسائل
⏱️ المدة: 5 ثوانٍ
⚠️ الحد الأقصى للإنذارات: 3

👥 المستثنون: ${ignoredCount}

━━━━━━━━━━━━━━

📌 *طريقة الاستخدام:*

🟢 *.اسبام تشغيل*
تشغيل الحماية.

🔴 *.اسبام إيقاف*
إيقاف الحماية.

👤 *.اسبام تجاهل @الشخص*
إضافة أو إزالة شخص من قائمة التجاهل.

━━━━━━━━━━━━━━

⚠️ *نظام العقوبات:*

1️⃣ المخالفة الأولى → إنذار
2️⃣ المخالفة الثانية → تحذير أخير
3️⃣ المخالفة الثالثة → طرد`
            );

        } catch (error) {

            console.error(
                '❌ خطأ في Plugin الإسبام:',
                error.stack || error
            );

            throw error;

        }

    }

};