const { runPinterestEdit } = require('../lib/editSources');

module.exports = {

    command: 'ايديت-بينتر',
    emoji: '🎨',
    description: 'تحميل إيديت من بينتريست (بيتفعّل غالبًا من زرار .ايديت2).',
    usage: '.ايديت-بينتر <اسم أو رابط>',

    async execute(sock, msg) {
        const chatId = msg.key.remoteJid;

        const body =
            msg.message?.extendedTextMessage?.text ||
            msg.message?.conversation ||
            '';

        const input =
            (Array.isArray(msg.args) && msg.args.length
                ? msg.args.join(' ')
                : body.replace(/^[.!؟]?\s*ايديت-بينتر\s*/i, '')
            ).trim();

        if (!input) {
            return await sock.sendMessage(
                chatId,
                { text: '❌ اكتب اسم الفيديو أو الرابط.' },
                { quoted: msg }
            );
        }

        try {
            await runPinterestEdit(sock, msg, chatId, input);
        } catch (error) {
            console.error('ايديت-بينتر error:', error);
            await sock.sendMessage(
                chatId,
                { text: `❌ فشل التحميل: ${error.message}` },
                { quoted: msg }
            );
        }
    }
};
