const axios = require('axios');
const yts = require('yt-search');
const { execFile } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

const AXIOS_OPTS = {
    timeout: 60000,
    headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120'
    }
};

async function tryTimes(fn, attempts = 2) {
    let lastErr;
    for (let i = 0; i < attempts; i++) {
        try {
            return await fn();
        } catch (e) {
            lastErr = e;
            await new Promise(r => setTimeout(r, 800));
        }
    }
    throw lastErr;
}

async function fromEliteProTech(url) {
    const { data } = await tryTimes(() =>
        axios.get(
            `https://eliteprotech-apis.zone.id/ytdown?url=${encodeURIComponent(url)}&format=mp3`,
            AXIOS_OPTS
        )
    );
    if (data?.success && data?.downloadURL) {
        return { download: data.downloadURL, title: data.title };
    }
    throw new Error('EliteProTech: لا يوجد رابط تحميل.');
}

async function fromYupra(url) {
    const { data } = await tryTimes(() =>
        axios.get(
            `https://api.yupra.my.id/api/downloader/ytmp3?url=${encodeURIComponent(url)}`,
            AXIOS_OPTS
        )
    );
    if (data?.success && data?.data?.download_url) {
        return { download: data.data.download_url, title: data.data.title };
    }
    throw new Error('Yupra: لا يوجد رابط تحميل.');
}

async function fromOkatsu(url) {
    const { data } = await tryTimes(() =>
        axios.get(
            `https://okatsu-rolezapiiz.vercel.app/downloader/ytmp3?url=${encodeURIComponent(url)}`,
            AXIOS_OPTS
        )
    );
    if (data?.dl) {
        return { download: data.dl, title: data.title };
    }
    throw new Error('Okatsu: لا يوجد رابط تحميل.');
}

function detectExt(buffer) {
    if (buffer.toString('ascii', 4, 8) === 'ftyp') return 'm4a';
    if (
        buffer.toString('ascii', 0, 3) === 'ID3' ||
        (buffer[0] === 0xff && (buffer[1] & 0xe0) === 0xe0)
    ) return 'mp3';
    if (buffer.toString('ascii', 0, 4) === 'OggS') return 'ogg';
    if (buffer.toString('ascii', 0, 4) === 'RIFF') return 'wav';
    return 'm4a';
}

function runFFmpeg(args) {
    return new Promise((resolve, reject) => {
        execFile('ffmpeg', args, { maxBuffer: 1024 * 1024 * 20 }, (error, stdout, stderr) => {
            if (error) {
                console.error('FFmpeg:', stderr);
                reject(error);
                return;
            }
            resolve();
        });
    });
}

async function convertToMp3(buffer, ext) {
    const id = crypto.randomBytes(6).toString('hex');
    const inputPath = path.join(os.tmpdir(), `song-input-${id}.${ext}`);
    const outputPath = path.join(os.tmpdir(), `song-output-${id}.mp3`);

    try {
        fs.writeFileSync(inputPath, buffer);

        await runFFmpeg([
            '-y',
            '-i', inputPath,
            '-vn',
            '-ar', '44100',
            '-ac', '2',
            '-b:a', '128k',
            outputPath
        ]);

        if (!fs.existsSync(outputPath)) {
            throw new Error('فشل تحويل الصوت لـ mp3');
        }

        return fs.readFileSync(outputPath);
    } finally {
        for (const f of [inputPath, outputPath]) {
            try {
                if (fs.existsSync(f)) fs.unlinkSync(f);
            } catch (e) {}
        }
    }
}

function getErrorMessage(e) {
    return (
        e?.response?.data?.message ||
        e?.message ||
        'حدث خطأ غير معروف.'
    );
}

module.exports = {

    command: 'اغنية',
    emoji: '🎵',
    description: 'تحميل أغنية بمصادر احتياطية متعددة، أضمن من أوامر التشغيل العادية.',
    usage: '.اغنية <اسم الأغنية أو رابط يوتيوب>',

    async execute(sock, msg) {
        const chatId = msg.key.remoteJid;

        const body =
            msg.message?.extendedTextMessage?.text ||
            msg.message?.conversation ||
            '';

        const query =
            (Array.isArray(msg.args) && msg.args.length
                ? msg.args.join(' ')
                : body.replace(/^[.!؟]?\s*اغني[ةه]\s*/i, '')
            ).trim();

        if (!query) {
            return await sock.sendMessage(
                chatId,
                { text: '❌ استخدم الأمر هكذا:\n\n.اغنية <اسم الأغنية أو رابط يوتيوب>' },
                { quoted: msg }
            );
        }

        try {
            let video;

            if (query.includes('youtube.com') || query.includes('youtu.be')) {
                const idMatch = query.match(/(?:v=|youtu\.be\/|shorts\/)([a-zA-Z0-9_-]{11})/);
                const videoId = idMatch ? idMatch[1] : null;

                video = {
                    url: query,
                    title: query,
                    thumbnail: videoId ? `https://img.youtube.com/vi/${videoId}/hqdefault.jpg` : null,
                    timestamp: ''
                };
            } else {
                const search = await yts(query);
                if (!search?.videos?.length) {
                    return await sock.sendMessage(
                        chatId,
                        { text: '❌ مفيش نتائج للبحث ده.' },
                        { quoted: msg }
                    );
                }
                video = search.videos[0];
            }

            if (video.thumbnail) {
                await sock.sendMessage(
                    chatId,
                    {
                        image: { url: video.thumbnail },
                        caption: `🎵 جاري التحميل: *${video.title}*\n⏱ المدة: ${video.timestamp || '؟'}`
                    },
                    { quoted: msg }
                );
            } else {
                await sock.sendMessage(
                    chatId,
                    { text: `⏳ جاري تحميل: ${video.title}` },
                    { quoted: msg }
                );
            }

            const sources = [fromEliteProTech, fromYupra, fromOkatsu];
            let result = null;

            for (const src of sources) {
                try {
                    result = await src(video.url);
                    if (result?.download) break;
                } catch (e) {
                    console.log('[اغنية] مصدر فشل:', e.message);
                }
            }

            if (!result?.download) {
                throw new Error('كل المصادر فشلت، الفيديو ده ممكن يكون غير متاح.');
            }

            const res = await axios.get(result.download, {
                responseType: 'arraybuffer',
                timeout: 90000,
                maxContentLength: Infinity,
                maxBodyLength: Infinity
            });

            let buffer = Buffer.from(res.data);
            if (!buffer.length) {
                throw new Error('الملف اللي اتحمل فاضي.');
            }

            const ext = detectExt(buffer);
            if (ext !== 'mp3') {
                buffer = await convertToMp3(buffer, ext);
            }

            const title = (result.title || video.title || 'song').replace(/[^\w\s-]/g, '');

            await sock.sendMessage(
                chatId,
                {
                    audio: buffer,
                    mimetype: 'audio/mpeg',
                    fileName: `${title}.mp3`,
                    ptt: false
                },
                { quoted: msg }
            );

        } catch (error) {
            console.error('[اغنية] خطأ:', error?.response?.data || error.message);

            await sock.sendMessage(
                chatId,
                { text: `❌ فشل التحميل: ${getErrorMessage(error)}` },
                { quoted: msg }
            );
        }
    }
};
