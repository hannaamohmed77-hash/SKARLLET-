const contactProtection = require('../lib/contactProtection');

module.exports = {
    command: 'جهات',
    category: 'tools',
    emoji: '👥',

    async execute(sock, msg) {
        const chatId = msg.key.remoteJid;

        try {
            const text =
                msg.message?.conversation ||
                msg.message?.extendedTextMessage?.text ||
                '';

            const args = text.trim().split(/\s+/);
            const action = args[1];

            // تشغيل
            if (action === 'تشغيل') {
                contactProtection.enable();

                await sock.sendMessage(chatId, {
                    text: '🟢 تم تشغيل حماية جهات الاتصال على مستوى البوت بالكامل'
                });

                return;
            }

            // إيقاف
            if (action === 'ايقاف') {
                contactProtection.disable();

                await sock.sendMessage(chatId, {
                    text: '🔴 تم إيقاف حماية جهات الاتصال على مستوى البوت بالكامل'
                });

                return;
            }

            // عرض الحالة
            const status = contactProtection.isEnabled();

            await sock.sendMessage(chatId, {
                text:
                    `📱 *حماية جهات الاتصال*\n\n` +
                    `الحالة: ${status ? '🟢 مفعلة' : '🔴 متوقفة'}\n\n` +
                    `لتشغيلها:\n.جهات تشغيل\n\n` +
                    `لإيقافها:\n.جهات ايقاف`
            });

        } catch (error) {
            console.error('❌ خطأ في أمر جهات:', error);

            await sock.sendMessage(chatId, {
                text: '❌ حصل خطأ أثناء تنفيذ أمر جهات.'
            });
        }
    }
};