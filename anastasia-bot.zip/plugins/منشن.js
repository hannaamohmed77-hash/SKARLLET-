// plugins/منشن.js

module.exports = {
    command: 'منشن',

    description: 'منشن جماعي لأعضاء المجموعة',
    emoji: '📢', 

    usage: '.منشن [النص]',

    group: true,

    async execute(sock, msg) {

        const chatId =
            msg.key?.remoteJid;

        if (!chatId?.endsWith('@g.us')) {
            return;
        }

        try {

            // جلب بيانات المجموعة
            const metadata =
                await sock.groupMetadata(chatId);

            const participants =
                metadata?.participants || [];

            if (!participants.length) {
                return;
            }

            // النص بعد الأمر
            const args =
                msg.args || [];

            const text =
                args.length
                    ? args.join(' ')
                    : '*𝔇𝔞𝔯𝔨*';

            // استخراج JID الأعضاء
            const mentions =
                participants
                    .map(p =>
                        p.id ||
                        p.jid
                    )
                    .filter(Boolean);

            if (!mentions.length) {
                return;
            }

            // إرسال المنشن
            await sock.sendMessage(
                chatId,
                {
                    text,
                    mentions
                }
            );

        } catch (error) {

            console.error(
                '❌ خطأ في أمر المنشن:',
                error
            );

            await sock.sendMessage(
                chatId,
                {
                    text:
                        '❌ حصل خطأ أثناء عمل المنشن.'
                }
            ).catch(() => {});

        }

    }
};