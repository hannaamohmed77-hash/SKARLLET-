const { isElite } = require('../haykala/elite.js');
const { jidDecode } = require('@whiskeysockets/baileys');

// ======================================================
// تحويل JID بدون إجبار @lid إلى @s.whatsapp.net
// ======================================================

const normalizeJid = (jid) => {
    if (!jid) return '';

    try {
        const decoded = jidDecode(jid);

        if (decoded?.user && decoded?.server) {
            return `${decoded.user}@${decoded.server}`;
        }

        return jid;
    } catch {
        return jid;
    }
};

// ======================================================
// استخراج الرقم
// ======================================================

const getNumber = (jid) => {
    if (!jid) return '';

    try {
        const decoded = jidDecode(jid);

        if (decoded?.user) {
            return decoded.user;
        }

        return jid.split('@')[0].split(':')[0];
    } catch {
        return jid.split('@')[0].split(':')[0];
    }
};

// ======================================================
// استخراج الهدف من المنشن أو الرد
// ======================================================

const getTargetJid = (msg) => {

    const context =
        msg.message?.extendedTextMessage?.contextInfo;

    // المنشن
    const mentioned =
        context?.mentionedJid?.[0];

    if (mentioned) {
        return normalizeJid(mentioned);
    }

    // الرد
    const replied =
        context?.participant;

    if (replied) {
        return normalizeJid(replied);
    }

    return null;
};

// ======================================================
// اسم العضو
// ======================================================

const getName = async (sock, jid) => {

    try {

        const result =
            await sock.onWhatsApp(jid);

        if (result?.[0]?.notify) {
            return result[0].notify;
        }

    } catch {}

    return getNumber(jid);
};

// ======================================================
// التاريخ والوقت - مصر
// ======================================================

const getEgyptTime = () => {

    const now = new Date();

    const date =
        new Intl.DateTimeFormat('ar-EG', {
            timeZone: 'Africa/Cairo',
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        }).format(now);

    const time =
        new Intl.DateTimeFormat('ar-EG', {
            timeZone: 'Africa/Cairo',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true
        }).format(now);

    return {
        date,
        time
    };
};

// ======================================================
// الأمر
// ======================================================

module.exports = {

    command: 'طرد',

    description:
        'طرد عضو بالرد أو المنشن - للنخبة فقط',

    usage:
        '.طرد بالرد على رسالة العضو أو منشنه',

    category: 'group',
    
    emoji: '🚪',

    async execute(sock, msg) {

        try {

            // ==================================================
            // المجموعة
            // ==================================================

            const chatId =
                msg.key?.remoteJid;

            if (!chatId) return;

            if (!chatId.endsWith('@g.us')) {

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ الأمر يعمل داخل المجموعات فقط.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================================
            // صاحب الأمر
            // ==================================================

            const senderRaw =
                msg.key?.participant;

            if (!senderRaw) {

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ تعذر تحديد صاحب الأمر.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            const sender =
                normalizeJid(senderRaw);

            const senderNumber =
                getNumber(sender);

            console.log(
                '🔎 طرد DEBUG:',
                {
                    senderRaw,
                    sender,
                    senderNumber,
                    elite: isElite(senderNumber)
                }
            );

            // ==================================================
            // النخبة فقط
            // ==================================================

            if (!isElite(senderNumber)) {

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ هذا الأمر مخصص للنخبة فقط.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================================
            // تحديد الهدف
            // ==================================================

            let target =
                getTargetJid(msg);

            if (!target) {

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ لازم تعمل منشن للعضو أو ترد على رسالته.\n\n' +
                            'مثال:\n' +
                            '.طرد @العضو'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================================
            // بيانات المجموعة
            // ==================================================

            const metadata =
                await sock.groupMetadata(chatId);

            // ==================================================
            // البحث عن العضو الحقيقي داخل المجموعة
            // مهم جدًا مع @lid
            // ==================================================

            const targetNumber =
                getNumber(target);

            let targetParticipant =
                metadata.participants.find(
                    p => {

                        const participantNumber =
                            getNumber(p.id);

                        return (
                            participantNumber ===
                            targetNumber
                        );
                    }
                );

            // محاولة ثانية بالمطابقة المباشرة
            if (!targetParticipant) {

                targetParticipant =
                    metadata.participants.find(
                        p =>
                            normalizeJid(p.id) ===
                            normalizeJid(target)
                    );
            }

            if (!targetParticipant) {

                console.log(
                    '❌ لم يتم العثور على العضو:',
                    target
                );

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ العضو غير موجود في المجموعة أو تعذر تحديد معرفه.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================================
            // استخدم الـ JID الحقيقي من بيانات المجموعة
            // ==================================================

            target =
                targetParticipant.id;

            const realTargetNumber =
                getNumber(target);

            console.log(
                '🎯 Target:',
                {
                    target,
                    realTargetNumber,
                    admin: targetParticipant.admin
                }
            );

            // ==================================================
            // حماية البوت من الطرد
            // ==================================================

            const botJid =
                normalizeJid(sock.user?.id);

            const botNumber =
                getNumber(botJid);

            if (
                realTargetNumber ===
                botNumber
            ) {

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ لا يمكنني طرد نفسي.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================================
            // مفيش أي منع للنخبة هنا
            // النخبة تقدر تطرد نخبة عادي
            // ==================================================

            // ==================================================
            // تنفيذ الطرد
            // ==================================================

            try {

                await sock.groupParticipantsUpdate(
                    chatId,
                    [target],
                    'remove'
                );

            } catch (error) {

                console.error(
                    '❌ فشل طرد العضو:',
                    error
                );

                const errorText =
                    error?.message ||
                    'خطأ غير معروف';

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            `❌ فشل تنفيذ الطرد.\n\n` +
                            `📌 السبب:\n${errorText}\n\n` +
                            `تأكد أن البوت مشرف وأن العضو قابل للطرد.`
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================================
            // الوقت والتاريخ
            // ==================================================

            const {
                date,
                time
            } = getEgyptTime();

            // ==================================================
            // استمارة الطرد
            // ==================================================

            const form =

`╭───〔 🚫 𝐊𝐈𝐂𝐊 〕───╮
│
│  ✦ تم طرد العضو بنجاح
│
│  👤 المطرود
│  ↳ @${realTargetNumber}
│
│  👑 بواسطة النخبة
│  ↳ @${senderNumber}
│
│  ⚡ الحالة
│  ↳ تم إخراج العضو من المجموعة
│
│  📅 التاريخ
│  ↳ ${date}
│
│  ⏰ الوقت
│  ↳ ${time}
│
╰──────────────────╯`;

            // ==================================================
            // إرسال الاستمارة
            // ==================================================

            await sock.sendMessage(
                chatId,
                {
                    text: form,

                    mentions: [
                        target,
                        sender
                    ]
                },
                {
                    quoted: msg
                }
            );

        } catch (error) {

            console.error(
                '✗ خطأ في أمر طرد:',
                error
            );

            try {

                await sock.sendMessage(
                    msg.key.remoteJid,
                    {
                        text:
                            `❌ حصل خطأ أثناء تنفيذ الأمر.\n\n${error?.message || ''}`
                    },
                    {
                        quoted: msg
                    }
                );

            } catch {}
        }
    }
};