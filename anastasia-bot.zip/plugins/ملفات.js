const fs = require('fs-extra');
const path = require('path');
const { isElite } = require('../haykala/elite');

// ======================================================
// ⚙️ إعدادات
// ======================================================

const ROOT = path.resolve(__dirname, '..');

const MAX_EDIT_SIZE = 5 * 1024 * 1024;
const MAX_PREVIEW = 14000;

// المسار الحالي لكل شات
const currentPaths = new Map();

// جلسات التعديل القديمة
const editSessions = new Map();


// ======================================================
// 🔐 التحقق من المالك
// ======================================================

function getSenderNumber(message) {

    const remoteJid =
        message.key?.remoteJid || '';

    let sender = '';

    if (remoteJid.endsWith('@g.us')) {

        sender =
            message.key?.participant ||
            message.participant ||
            message.key?.senderPn ||
            '';

    } else {

        sender =
            message.key?.participant ||
            message.participant ||
            remoteJid ||
            '';

    }

    return String(sender)
        .split(':')[0]
        .split('@')[0]
        .replace(/\D/g, '');

}

function isOwner(message) {

    return isElite(
        getSenderNumber(message)
    );

}


// ======================================================
// 🛡️ حماية المسارات
// ======================================================

function safePath(input = '') {

    const target =
        path.resolve(
            ROOT,
            input
        );

    if (
        target !== ROOT &&
        !target.startsWith(ROOT + path.sep)
    ) {

        throw new Error(
            '❌ هذا المسار خارج مجلد البوت.'
        );

    }

    return target;

}


// ======================================================
// 📍 المسار النسبي
// ======================================================

function relativePath(target) {

    const result =
        path.relative(
            ROOT,
            target
        );

    return result || '.';

}


// ======================================================
// 📦 حجم الملف
// ======================================================

function formatSize(size) {

    if (size < 1024) {

        return `${size} B`;

    }

    if (size < 1024 * 1024) {

        return `${(
            size / 1024
        ).toFixed(2)} KB`;

    }

    return `${(
        size / 1024 / 1024
    ).toFixed(2)} MB`;

}


// ======================================================
// 📁 ترتيب الملفات والمجلدات
// ======================================================

function sortEntries(entries) {

    return entries.sort(
        (a, b) => {

            if (
                a.isDirectory() &&
                !b.isDirectory()
            ) {
                return -1;
            }

            if (
                !a.isDirectory() &&
                b.isDirectory()
            ) {
                return 1;
            }

            return a.name.localeCompare(
                b.name,
                'ar'
            );

        }
    );

}


// ======================================================
// 📂 عرض المجلد
// ======================================================

async function listDirectory(target) {

    const stat =
        await fs.stat(target);

    if (!stat.isDirectory()) {

        throw new Error(
            'المسار ليس مجلدًا.'
        );

    }

    let entries =
        await fs.readdir(
            target,
            {
                withFileTypes: true
            }
        );

    entries =
        sortEntries(entries);

    let text =
        `📂 المسار الحالي:\n${relativePath(target)}\n\n`;

    if (!entries.length) {

        text +=
            '📭 المجلد فارغ.\n';

    } else {

        for (
            let i = 0;
            i < entries.length;
            i++
        ) {

            const entry =
                entries[i];

            const fullPath =
                path.join(
                    target,
                    entry.name
                );

            let extra = '';

            if (entry.isFile()) {

                try {

                    const info =
                        await fs.stat(
                            fullPath
                        );

                    extra =
                        ` — ${formatSize(info.size)}`;

                } catch {}

            }

            text +=
                `${i + 1}. ${
                    entry.isDirectory()
                        ? '📁'
                        : '📄'
                } ${entry.name}${extra}\n`;

        }

    }

    text +=
        '\n━━━━━━━━━━━━━━━━━━';

    return text;

}


// ======================================================
// 🔎 الحصول على عنصر برقم
// ======================================================

async function getEntry(
    directory,
    number
) {

    const entries =
        sortEntries(
            await fs.readdir(
                directory,
                {
                    withFileTypes: true
                }
            )
        );

    const index =
        Number(number) - 1;

    if (
        !Number.isInteger(index) ||
        index < 0 ||
        index >= entries.length
    ) {

        throw new Error(
            '❌ رقم الملف أو المجلد غير صحيح.'
        );

    }

    return path.join(
        directory,
        entries[index].name
    );

}


// ======================================================
// 📄 قراءة ملف
// ======================================================

async function readFile(target) {

    const stat =
        await fs.stat(target);

    if (!stat.isFile()) {

        throw new Error(
            '❌ هذا المسار ليس ملفًا.'
        );

    }

    if (
        stat.size > MAX_EDIT_SIZE
    ) {

        throw new Error(
            `❌ حجم الملف أكبر من ${formatSize(MAX_EDIT_SIZE)}.`
        );

    }

    return await fs.readFile(
        target,
        'utf8'
    );

}


// ======================================================
// 👀 عرض محتوى ملف
// ======================================================

async function sendFileContent(
    sock,
    chatId,
    target
) {

    const content =
        await readFile(target);

    let preview =
        content || '(الملف فارغ)';

    if (
        preview.length > MAX_PREVIEW
    ) {

        preview =
            preview.slice(
                0,
                MAX_PREVIEW
            ) +
            '\n\n... تم اختصار العرض ...';

    }

    await sock.sendMessage(
        chatId,
        {
            text:
                `📄 الملف:\n${relativePath(target)}\n\n` +
                `━━━━━━━━━━━━━━━━━━\n` +
                `${preview}\n` +
                `━━━━━━━━━━━━━━━━━━`
        }
    );

}


// ======================================================
// 💾 استخراج نص الرسالة الحالية
// ======================================================

function getText(message) {

    return (
        message.message?.conversation ||

        message.message
            ?.extendedTextMessage
            ?.text ||

        message.message
            ?.imageMessage
            ?.caption ||

        message.message
            ?.videoMessage
            ?.caption ||

        message.message
            ?.documentMessage
            ?.caption ||

        ''
    );

}


// ======================================================
// 💬 استخراج الرسالة التي تم الرد عليها
// ======================================================

function getQuotedMessage(message) {

    return (
        message.message
            ?.extendedTextMessage
            ?.contextInfo
            ?.quotedMessage ||

        message.message
            ?.imageMessage
            ?.contextInfo
            ?.quotedMessage ||

        message.message
            ?.videoMessage
            ?.contextInfo
            ?.quotedMessage ||

        null
    );

}


// ======================================================
// 📝 استخراج محتوى الرسالة المقتبس منها
// ======================================================

function getQuotedText(message) {

    const quoted =
        getQuotedMessage(message);

    if (!quoted) {
        return '';
    }

    return (
        quoted.conversation ||

        quoted.extendedTextMessage
            ?.text ||

        quoted.imageMessage
            ?.caption ||

        quoted.videoMessage
            ?.caption ||

        quoted.documentMessage
            ?.caption ||

        ''
    );

}


// ======================================================
// 🆕 استخراج رسالة Reply بشكل آمن
// ======================================================

function hasQuotedMessage(message) {

    const context =
        message.message
            ?.extendedTextMessage
            ?.contextInfo;

    return Boolean(
        context?.quotedMessage
    );

}


// ======================================================
// ✏️ بدء جلسة تعديل قديمة
// ======================================================

async function startEdit(
    sock,
    message,
    target
) {

    const chatId =
        message.key.remoteJid;

    const content =
        await readFile(target);

    let preview =
        content || '(الملف فارغ)';

    if (
        preview.length > MAX_PREVIEW
    ) {

        preview =
            preview.slice(
                0,
                MAX_PREVIEW
            ) +
            '\n\n... تم اختصار العرض ...';

    }

    const sent =
        await sock.sendMessage(
            chatId,
            {
                text:
                    `✏️ تعديل ملف\n\n` +
                    `📄 ${relativePath(target)}\n\n` +
                    `━━━━━━━━━━━━━━━━━━\n` +
                    `${preview}\n` +
                    `━━━━━━━━━━━━━━━━━━\n\n` +
                    `📌 رد على هذه الرسالة بالمحتوى الجديد بالكامل.\n` +
                    `⏱️ أمامك 10 دقائق للتعديل.`
            }
        );

    if (!sent?.key?.id) {

        throw new Error(
            'تعذر إنشاء جلسة التعديل.'
        );

    }

    const sessionId =
        `${chatId}:${sent.key.id}`;

    editSessions.set(
        sessionId,
        {
            chatId,
            messageId: sent.key.id,
            filePath: target,
            createdAt: Date.now()
        }
    );

    setTimeout(
        () => {

            editSessions.delete(
                sessionId
            );

        },
        10 * 60 * 1000
    );

}


// ======================================================
// 💾 استقبال التعديل القديم بالرد على رسالة البوت
// ======================================================

async function handleEditReply(
    sock,
    message
) {

    const chatId =
        message.key?.remoteJid;

    const context =
        message.message
            ?.extendedTextMessage
            ?.contextInfo;

    const quotedId =
        context?.stanzaId;

    if (
        !chatId ||
        !quotedId
    ) {

        return false;

    }

    let session = null;
    let sessionKey = null;

    for (
        const [key, value]
        of editSessions.entries()
    ) {

        if (
            value.chatId === chatId &&
            value.messageId === quotedId
        ) {

            session = value;
            sessionKey = key;

            break;

        }

    }

    if (!session) {

        return false;

    }

    try {

        const newContent =
            getText(message);

        if (
            newContent === ''
        ) {

            await sock.sendMessage(
                chatId,
                {
                    text:
                        '❌ المحتوى الجديد فارغ.'
                }
            );

            return true;

        }

        if (
            Buffer.byteLength(
                newContent,
                'utf8'
            ) > MAX_EDIT_SIZE
        ) {

            await sock.sendMessage(
                chatId,
                {
                    text:
                        `❌ المحتوى أكبر من الحد المسموح ${formatSize(MAX_EDIT_SIZE)}.`
                }
            );

            return true;

        }

        await fs.writeFile(
            session.filePath,
            newContent,
            'utf8'
        );

        editSessions.delete(
            sessionKey
        );

        await sock.sendMessage(
            chatId,
            {
                text:
                    `✅ تم تعديل الملف وحفظه بنجاح.\n\n` +
                    `📄 ${relativePath(session.filePath)}\n` +
                    `📦 الحجم الجديد: ${formatSize(
                        Buffer.byteLength(
                            newContent,
                            'utf8'
                        )
                    )}`
            }
        );

    } catch (error) {

        await sock.sendMessage(
            chatId,
            {
                text:
                    `❌ فشل تعديل الملف:\n${error.message}`
            }
        );

    }

    return true;

}


// ======================================================
// ⚡ التعديل المباشر من Reply
// ======================================================
//
// الاستخدام:
//
// [المحتوى الجديد]
//
// ↩️ .ملفات تعديل 11
//
// ======================================================

async function handleDirectEdit(
    sock,
    message,
    target
) {

    const chatId =
        message.key?.remoteJid;

    if (
        !hasQuotedMessage(message)
    ) {

        return false;

    }

    try {

        const newContent =
            getQuotedText(message);

        if (
            newContent === ''
        ) {

            await sock.sendMessage(
                chatId,
                {
                    text:
                        '❌ الرسالة التي رددت عليها لا تحتوي على محتوى نصي.'
                }
            );

            return true;

        }

        const size =
            Buffer.byteLength(
                newContent,
                'utf8'
            );

        if (
            size > MAX_EDIT_SIZE
        ) {

            await sock.sendMessage(
                chatId,
                {
                    text:
                        `❌ المحتوى أكبر من الحد المسموح ${formatSize(MAX_EDIT_SIZE)}.`
                }
            );

            return true;

        }

        await fs.writeFile(
            target,
            newContent,
            'utf8'
        );

        await sock.sendMessage(
            chatId,
            {
                text:
                    `✅ تم الحفظ بنجاح.\n\n` +
                    `📄 ${relativePath(target)}\n` +
                    `📦 الحجم الجديد: ${formatSize(size)}`
            }
        );

    } catch (error) {

        await sock.sendMessage(
            chatId,
            {
                text:
                    `❌ فشل حفظ الملف:\n${error.message}`
            }
        );

    }

    return true;

}


// ======================================================
// 🗑️ حذف
// ======================================================

async function deleteTarget(target) {

    if (
        target === ROOT
    ) {

        throw new Error(
            '❌ لا يمكن حذف مجلد البوت الرئيسي.'
        );

    }

    await fs.remove(target);

}


// ======================================================
// 📝 إنشاء ملف
// ======================================================

async function createFile(target) {

    if (
        await fs.pathExists(target)
    ) {

        throw new Error(
            '❌ الملف أو المجلد موجود بالفعل.'
        );

    }

    await fs.ensureFile(target);

}


// ======================================================
// 📁 إنشاء مجلد
// ======================================================

async function createFolder(target) {

    if (
        await fs.pathExists(target)
    ) {

        throw new Error(
            '❌ الملف أو المجلد موجود بالفعل.'
        );

    }

    await fs.ensureDir(target);

}


// ======================================================
// 🚀 الأمر الرئيسي
// ======================================================

async function execute(
    sock,
    message
) {

    const chatId =
        message.key.remoteJid;


    // ==================================================
    // 🔐 المالك فقط
    // ==================================================

    if (
        !isOwner(message)
    ) {

        await sock.sendMessage(
            chatId,
            {
                text:
                    '❌ هذا الأمر مخصص لمالك البوت فقط.'
            }
        );

        return;

    }


    // ==================================================
    // ✏️ التعديل القديم
    // ==================================================

    if (
        await handleEditReply(
            sock,
            message
        )
    ) {

        return;

    }


    const args =
        message.args || [];


    // ==================================================
    // 📍 المسار الحالي
    // ==================================================

    let current =
        currentPaths.get(chatId) ||
        ROOT;


    // ==================================================
    // 🏠 الرئيسية
    // ==================================================

    if (
        !args.length
    ) {

        current = ROOT;

        currentPaths.set(
            chatId,
            current
        );

        const list =
            await listDirectory(
                current
            );

        await sock.sendMessage(
            chatId,
            {
                text:
                    `🗂️ مدير ملفات البوت\n\n` +
                    `${list}\n\n` +
                    `━━━━━━━━━━━━━━━━━━\n` +
                    `📌 الأوامر:\n\n` +
                    `.ملفات رقم ← دخول/فتح\n` +
                    `.ملفات فتح رقم ← فتح ملف\n` +
                    `.ملفات تعديل رقم ← تعديل ملف\n` +
                    `.ملفات حذف رقم ← حذف\n` +
                    `.ملفات رجوع ← مجلد سابق\n` +
                    `.ملفات الرئيسية ← الرئيسية\n` +
                    `.ملفات انشاء فايل الاسم\n` +
                    `.ملفات انشاء فولدر الاسم`
            }
        );

        return;

    }


    // ==================================================
    // 🏠 الرئيسية
    // ==================================================

    if (
        args[0] === 'الرئيسية' ||
        args[0] === 'home'
    ) {

        current = ROOT;

        currentPaths.set(
            chatId,
            current
        );

        await sock.sendMessage(
            chatId,
            {
                text:
                    await listDirectory(
                        current
                    )
            }
        );

        return;

    }


    // ==================================================
    // ⬅️ رجوع
    // ==================================================

    if (
        args[0] === 'رجوع' ||
        args[0] === 'عودة' ||
        args[0] === 'back'
    ) {

        if (
            current === ROOT
        ) {

            await sock.sendMessage(
                chatId,
                {
                    text:
                        '📂 أنت بالفعل في المجلد الرئيسي.'
                }
            );

            return;

        }

        current =
            path.dirname(current);

        if (
            current !== ROOT &&
            !current.startsWith(
                ROOT + path.sep
            )
        ) {

            current = ROOT;

        }

        currentPaths.set(
            chatId,
            current
        );

        await sock.sendMessage(
            chatId,
            {
                text:
                    await listDirectory(
                        current
                    )
            }
        );

        return;

    }


    // ==================================================
    // 🔢 الدخول بالرقم
    // ==================================================

    if (
        /^\d+$/.test(args[0])
    ) {

        const target =
            await getEntry(
                current,
                args[0]
            );

        const stat =
            await fs.stat(target);

        if (
            stat.isDirectory()
        ) {

            current = target;

            currentPaths.set(
                chatId,
                current
            );

            await sock.sendMessage(
                chatId,
                {
                    text:
                        await listDirectory(
                            current
                        )
                }
            );

        } else {

            await sendFileContent(
                sock,
                chatId,
                target
            );

        }

        return;

    }


    // ==================================================
    // 📖 فتح
    // ==================================================

    if (
        args[0] === 'فتح'
    ) {

        if (
            !args[1]
        ) {

            throw new Error(
                'الاستخدام: .ملفات فتح رقم'
            );

        }

        const target =
            await getEntry(
                current,
                args[1]
            );

        const stat =
            await fs.stat(target);

        if (
            stat.isDirectory()
        ) {

            current = target;

            currentPaths.set(
                chatId,
                current
            );

            await sock.sendMessage(
                chatId,
                {
                    text:
                        await listDirectory(
                            current
                        )
                }
            );

        } else {

            await sendFileContent(
                sock,
                chatId,
                target
            );

        }

        return;

    }


    // ==================================================
    // ✏️ تعديل
    // ==================================================

    if (
        args[0] === 'تعديل'
    ) {

        if (
            !args[1]
        ) {

            throw new Error(
                'الاستخدام: .ملفات تعديل رقم'
            );

        }

        const target =
            await getEntry(
                current,
                args[1]
            );

        const stat =
            await fs.stat(target);

        if (
            !stat.isFile()
        ) {

            throw new Error(
                '❌ يمكنك تعديل الملفات فقط.'
            );

        }


        // ==================================================
        // 🆕 لو الأمر Reply على المحتوى
        // ==================================================

        if (
            hasQuotedMessage(message)
        ) {

            await handleDirectEdit(
                sock,
                message,
                target
            );

            return;

        }


        // ==================================================
        // لو مش Reply → الطريقة القديمة
        // ==================================================

        await startEdit(
            sock,
            message,
            target
        );

        return;

    }


    // ==================================================
    // 🗑️ حذف
    // ==================================================

    if (
        args[0] === 'حذف'
    ) {

        if (
            !args[1]
        ) {

            throw new Error(
                'الاستخدام: .ملفات حذف رقم'
            );

        }

        const target =
            await getEntry(
                current,
                args[1]
            );

        const targetName =
            path.basename(target);

        await deleteTarget(
            target
        );

        await sock.sendMessage(
            chatId,
            {
                text:
                    `✅ تم الحذف بنجاح.\n\n🗑️ ${targetName}`
            }
        );

        return;

    }


    // ==================================================
    // 🆕 إنشاء
    // ==================================================

    if (
        args[0] === 'انشاء' ||
        args[0] === 'إنشاء'
    ) {

        const type =
            args[1];

        const name =
            args
                .slice(2)
                .join(' ')
                .trim();

        if (
            !type ||
            !name
        ) {

            throw new Error(
                'الاستخدام:\n\n' +
                '.ملفات انشاء فايل الاسم\n' +
                '.ملفات انشاء فولدر الاسم'
            );

        }

        const normalized =
            type
                .toLowerCase()
                .replace(
                    /أ|إ|آ/g,
                    'ا'
                );


        const target =
            safePath(
                path.join(
                    relativePath(current),
                    name
                )
            );


        // ------------------------------
        // ملف
        // ------------------------------

        if (
            normalized === 'فايل' ||
            normalized === 'file'
        ) {

            await createFile(
                target
            );

            await sock.sendMessage(
                chatId,
                {
                    text:
                        `✅ تم إنشاء الملف.\n\n` +
                        `📄 ${relativePath(target)}\n\n` +
                        `✏️ لتعديله:\n` +
                        `.ملفات تعديل رقم`
                }
            );

            return;

        }


        // ------------------------------
        // مجلد
        // ------------------------------

        if (
            normalized === 'فولدر' ||
            normalized === 'folder' ||
            normalized === 'مجلد'
        ) {

            await createFolder(
                target
            );

            await sock.sendMessage(
                chatId,
                {
                    text:
                        `✅ تم إنشاء المجلد.\n\n` +
                        `📁 ${relativePath(target)}`
                }
            );

            return;

        }


        throw new Error(
            '❌ النوع غير صحيح.\nاستخدم فايل أو فولدر.'
        );

    }


    // ==================================================
    // ❌ غير معروف
    // ==================================================

    await sock.sendMessage(
        chatId,
        {
            text:
                `❌ أمر غير معروف.\n\n` +
                `📌 الاستخدام:\n\n` +
                `.ملفات\n` +
                `.ملفات 1\n` +
                `.ملفات فتح 1\n` +
                `.ملفات تعديل 1\n` +
                `.ملفات حذف 1\n` +
                `.ملفات رجوع\n` +
                `.ملفات الرئيسية\n` +
                `.ملفات انشاء فايل الاسم\n` +
                `.ملفات انشاء فولدر الاسم`
        }
    );

}


// ======================================================
// 📦 التصدير
// ======================================================

module.exports = {

    command: 'ملفات',

    description:
        'مدير ملفات كامل للبوت للمالك فقط.',

    usage:
        '.ملفات',
  
emoji: '📁',
   

    owner: true,

    execute

};