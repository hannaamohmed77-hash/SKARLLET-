const fs = require('fs');
const axios = require('axios');
const cheerio = require('cheerio');

// ======================================================
// ⚡ إعدادات Pinterest
// ======================================================

const PINTEREST_SEARCH =
    'https://www.pinterest.com/search/pins/?q=';

// ======================================================
// 🎭 الشخصيات
// ======================================================

const CHARACTERS = [
    'غوجو ساتورو',
    'توجي فوشيغورو',
    'يوتا أوكوتسو',
    'لايت ياغامي',
    'كيرا ديث نوت',
    'ويليام جيمس مورياتي',
    'كانيكي كين',
    'سوبارو',
    'دازاي أوسامو',
    'انمي عشوائي'
];

// ======================================================
// 🖼️ الصورة الموجودة في الانتظار
// ======================================================

let waitingImage = null;

// ======================================================
// 🔄 هل يتم تحميل صورة حاليًا؟
/*
 * يمنع تحميل أكثر من صورة في نفس الوقت
 */
// ======================================================

let downloading = false;

// ======================================================
// 🧠 آخر شخصية تم استخدامها
// ======================================================

let lastCharacter = null;

// ======================================================
// 🔧 استخراج الصور من Pinterest
// ======================================================

function extractImageUrls(html) {

    const urls = new Set();

    function addUrl(value) {

        if (!value) {
            return;
        }

        let url =
            String(value)
                .replace(/\\u002F/g, '/')
                .replace(/\\\//g, '/')
                .replace(/&amp;/g, '&')
                .trim();

        if (
            !/^https?:\/\//i.test(url)
        ) {
            return;
        }

        if (
            /\/(?:60x60|170x|236x)\//i.test(url)
        ) {
            return;
        }

        if (
            !/(jpg|jpeg|png|webp)/i.test(url)
        ) {
            return;
        }

        urls.add(url);
    }

    const $ =
        cheerio.load(html);

    // ==================================================
    // صور HTML
    // ==================================================

    $('img').each((_, element) => {

        addUrl(
            $(element).attr('src')
        );

        addUrl(
            $(element).attr('data-src')
        );

        addUrl(
            $(element).attr('data-lazy-src')
        );

        const srcset =
            $(element).attr('srcset');

        if (srcset) {

            srcset
                .split(',')
                .forEach(item => {

                    const url =
                        item
                            .trim()
                            .split(/\s+/)[0];

                    addUrl(url);
                });
        }

    });

    // ==================================================
    // JSON داخل الصفحة
    // ==================================================

    const regex =
        /https?:\\?\/\\?\/[^"'<>\\\s]+/gi;

    const matches =
        html.match(regex) || [];

    for (const match of matches) {

        const url =
            match
                .replace(/\\u002F/g, '/')
                .replace(/\\\//g, '/')
                .replace(/\\u0026/g, '&');

        if (
            /(?:jpg|jpeg|png|webp)(?:[?#&]|$)/i.test(
                url
            )
        ) {

            addUrl(url);

        }

    }

    // ==================================================
    // الأفضل أولًا
    // ==================================================

    return [...urls].sort((a, b) => {

        let scoreA = 0;
        let scoreB = 0;

        if (
            /i\.pinimg\.com/i.test(a)
        ) {
            scoreA += 100;
        }

        if (
            /i\.pinimg\.com/i.test(b)
        ) {
            scoreB += 100;
        }

        if (
            /\/originals\//i.test(a)
        ) {
            scoreA += 1000;
        }

        if (
            /\/originals\//i.test(b)
        ) {
            scoreB += 1000;
        }

        return scoreB - scoreA;

    });

}

// ======================================================
// 🔄 تحويل الصورة إلى Originals
// ======================================================

function getOriginalPinterestUrl(url) {

    if (
        typeof url !== 'string'
    ) {
        return url;
    }

    return url
        .replace(/\\u002F/g, '/')
        .replace(/\\\//g, '/')
        .replace(/&amp;/g, '&')
        .replace(
            /\/(?:60x60|170x|236x|474x|564x|736x|1200x)\//i,
            '/originals/'
        );

}

// ======================================================
// 📥 تحميل صورة
// ======================================================

async function downloadImage(url) {

    try {

        const response =
            await axios.get(
                url,
                {
                    responseType:
                        'arraybuffer',

                    timeout:
                        12000,

                    maxContentLength:
                        30 * 1024 * 1024,

                    maxBodyLength:
                        30 * 1024 * 1024,

                    headers: {

                        'User-Agent':
                            'Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/131.0 Mobile Safari/537.36',

                        'Accept':
                            'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',

                        'Referer':
                            'https://www.pinterest.com/'
                    }
                }
            );

        if (
            !response.data ||
            response.data.length < 5000
        ) {
            return null;
        }

        return Buffer.from(
            response.data
        );

    } catch {

        return null;

    }

}

// ======================================================
// 🎲 اختيار شخصية
// ======================================================

function getRandomCharacter() {

    const available =
        CHARACTERS.filter(
            character =>
                character !== lastCharacter
        );

    const list =
        available.length
            ? available
            : CHARACTERS;

    const character =
        list[
            Math.floor(
                Math.random() *
                list.length
            )
        ];

    lastCharacter =
        character;

    return character;

}

// ======================================================
// 🔎 البحث عن صورة Pinterest
// ======================================================

async function searchPinterestImage(
    character
) {

    try {

        const query =
            character === 'انمي عشوائي'
                ? 'anime character aesthetic'
                : `${character} anime`;

        const searchUrl =
            PINTEREST_SEARCH +
            encodeURIComponent(query);

        const response =
            await axios.get(
                searchUrl,
                {
                    timeout:
                        15000,

                    maxContentLength:
                        20 * 1024 * 1024,

                    headers: {

                        'User-Agent':
                            'Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/131.0 Mobile Safari/537.36',

                        'Accept':
                            'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',

                        'Accept-Language':
                            'en-US,en;q=0.9',

                        'Referer':
                            'https://www.google.com/'
                    }
                }
            );

        const urls =
            extractImageUrls(
                String(response.data)
            );

        if (!urls.length) {
            return null;
        }

        const candidates = [];

        for (
            const url of urls.slice(0, 20)
        ) {

            const original =
                getOriginalPinterestUrl(
                    url
                );

            if (
                original &&
                !candidates.includes(original)
            ) {

                candidates.push(
                    original
                );

            }

            if (
                !candidates.includes(url)
            ) {

                candidates.push(url);

            }

        }

        for (
            const url of candidates.slice(0, 25)
        ) {

            const buffer =
                await downloadImage(url);

            if (
                buffer &&
                buffer.length > 5000
            ) {

                return {

                    buffer,

                    character

                };

            }

        }

        return null;

    } catch {

        return null;

    }

}

// ======================================================
// 🚀 تحميل صورة واحدة ووضعها في الانتظار
// ======================================================

async function prepareNextImage() {

    if (downloading) {
        return;
    }

    if (waitingImage) {
        return;
    }

    downloading = true;

    try {

        for (
            let attempt = 0;
            attempt < 5;
            attempt++
        ) {

            const character =
                getRandomCharacter();

            const result =
                await searchPinterestImage(
                    character
                );

            if (
                result &&
                result.buffer
            ) {

                waitingImage =
                    result;

                break;

            }

        }

    } catch {

    } finally {

        downloading = false;

    }

}

// ======================================================
// ⚡ تجهيز أول صورة فور تحميل الملف
// ======================================================

prepareNextImage().catch(() => {});

// ======================================================
// Cache الأوامر
// ======================================================

let commandsCache = [];
let commandsLoaded = false;

// ======================================================
// 📦 تحميل الأوامر من Plugins (مع استثناء الأوامر المخفية)
// ======================================================

function loadCommands() {

    try {

        const PLUGINS_DIR =
            __dirname;

        const files =
            fs.readdirSync(
                PLUGINS_DIR
            )
            .filter(file =>
                file.endsWith('.js') &&
                file !== 'اوامر.js'
            );

        const commands = [];
        const seen = new Set();

        for (
            const file of files
        ) {

            try {

                const plugin =
                    require(
                        require('path').join(
                            PLUGINS_DIR,
                            file
                        )
                    );

                if (
                    !plugin ||
                    typeof plugin.command !== 'string' ||
                    typeof plugin.execute !== 'function'
                ) {
                    continue;
                }

                const command =
                    plugin.command.trim();

                // ⭐ استثناء الأوامر السرية والمخفية من المينيو
                if (
                    plugin.hidden ||
                    plugin.dontShowInCommandList ||
                    command === '𝔇𝔞𝔯𝔨' ||
                    command === '𝔇𝔞𝔯𝔨1'
                ) {
                    continue;
                }

                if (
                    !command ||
                    seen.has(command)
                ) {
                    continue;
                }

                seen.add(command);

                const emoji =
                    typeof plugin.emoji === 'string' &&
                    plugin.emoji.trim()
                        ? plugin.emoji.trim()
                        : '⚡';

                commands.push({
                    command,
                    emoji
                });

            } catch {

            }

        }

        commands.sort(
            (a, b) =>
                a.command.localeCompare(
                    b.command,
                    'ar'
                )
        );

        commandsCache =
            commands;

        commandsLoaded =
            true;

        return commandsCache;

    } catch {

        return commandsCache;

    }

}

// ======================================================
// 📝 بناء المنيو
// ======================================================

function buildMenu(commands) {

    const now =
        new Date();

    const date =
        now.toLocaleDateString(
            'en-GB',
            {
                timeZone:
                    'Africa/Cairo'
            }
        );

    const time =
        now.toLocaleTimeString(
            'en-US',
            {
                timeZone:
                    'Africa/Cairo',

                hour:
                    '2-digit',

                minute:
                    '2-digit',

                hour12:
                    true
            }
        );

    let menu = '';

    menu +=
        `≪ ❪ 🖤 𝔇𝔄ℜ𝔎 𝔅𝔒𝔗 🖤 ❫ ≫\n`;

    menu +=
        `❪ 𝔓ℜ𝔈𝔐𝔦𝔘𝔐 𝔐𝔈𝔑𝔘 ❫\n`;

    menu +=
        `≪ ━ ❪ ⚡ 𝔗ℌ𝔈 𝔘𝔏𝔗ℜ𝔄 ⚡ ❫ ━ ≫\n\n`;

    for (
        const item of commands
    ) {

        menu +=
            `╟「 ${item.emoji} 」↬ .${item.command}\n`;

    }

    menu +=
        `\n╰─── ≪ ❪ 🖤 ⚡ 🖤 ❫ ≫ ───╯\n\n`;

    menu +=
        `◜⏤͟͟͞͞ 𝔇𝔢𝔳 : 𝔇𝔞𝔯𝔨 ˖࣪⃟👑 ◞\n`;

    menu +=
        `◜⏤͟͟͞͞ 𝔠𝔬𝔪𝔪𝔞𝔫𝔡𝔰 : ${commands.length} ˖࣪⃟⚡ ◞\n`;

    menu +=
        `◜⏤͟͟͞͞ 𝔇𝔞𝔱𝔢 : ${date} ˖࣪⃟📅 ◞\n`;

    menu +=
        `◜⏤͟͟͞͞ 𝔗𝔦𝔪𝔢 : ${time} ˖࣪⃟⏰ ◞\n\n`;

    menu +=
        `≪ ❪ ♾️ 𝔇𝔄ℜ𝔎 𝔓ℜ𝔈𝔐𝔦𝔘𝔐 ♾️ ❫ ≫`;

    return menu;

}

// ======================================================
// ⚡ تحميل الأوامر فورًا
// ======================================================

loadCommands();

// ======================================================
// 🎯 Plugin
// ======================================================

module.exports = {

    command: 'اوامر',

    category: 'tools',

    emoji: '📜',

    async execute(sock, msg) {

        const chatId =
            msg.key?.remoteJid;

        if (!chatId) {
            return;
        }

        try {

            const text =
                msg.message?.conversation ||
                msg.message?.extendedTextMessage?.text ||
                '';

            const args =
                text
                    .trim()
                    .split(/\s+/);

            if (
                args[1] === 'تحديث'
            ) {

                loadCommands();

                await sock.sendMessage(
                    chatId,
                    {
                        text:
                            `✅ تم تحديث المنيو\n\n` +
                            `📦 الأوامر: ${commandsCache.length}`
                    },
                    {
                        quoted: msg
                    }
                );

                return;

            }

            if (!commandsLoaded) {
                loadCommands();
            }

            const menu =
                buildMenu(
                    commandsCache
                );

            const imageToSend =
                waitingImage;

            if (
                imageToSend &&
                imageToSend.buffer
            ) {

                waitingImage = null;

                prepareNextImage()
                    .catch(() => {});

                await sock.sendMessage(
                    chatId,
                    {
                        image:
                            imageToSend.buffer,

                        caption:
                            menu
                    },
                    {
                        quoted: msg
                    }
                );

                return;

            }

            await prepareNextImage();

            if (
                waitingImage &&
                waitingImage.buffer
            ) {

                const image =
                    waitingImage;

                waitingImage =
                    null;

                prepareNextImage()
                    .catch(() => {});

                await sock.sendMessage(
                    chatId,
                    {
                        image:
                            image.buffer,

                        caption:
                            menu
                    },
                    {
                        quoted: msg
                    }
                );

                return;

            }

            await sock.sendMessage(
                chatId,
                {
                    text:
                        menu
                },
                {
                    quoted: msg
                }
            );

        } catch {

            try {

                await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ حدث خطأ أثناء تشغيل قائمة الأوامر.'
                    },
                    {
                        quoted: msg
                    }
                );

            } catch {}

        }

    }

};
