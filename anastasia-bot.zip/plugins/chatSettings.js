const {
    isElite
} = require('../haykala/elite.js');

const {
    jidDecode
} = require('@whiskeysockets/baileys');

// ==========================================
// توحيد JID
// ==========================================

function normalizeJid(jid) {
    if (!jid) return null;

    try {

        const decoded =
            jidDecode(jid);

        if (decoded?.user) {
            return `${decoded.user}@s.whatsapp.net`;
        }

        const user =
            String(jid)
                .split('@')[0]
                .split(':')[0]
                .trim();

        return user
            ? `${user}@s.whatsapp.net`
            : null;

    } catch {

        const user =
            String(jid)
                .split('@')[0]
                .split(':')[0]
                .trim();

        return user
            ? `${user}@s.whatsapp.net`
            : null;
    }
}

// ==========================================
// صاحب الرسالة
// ==========================================

function getSender(msg) {
    return (
        msg.key?.participant ||
        msg.participant ||
        msg.key?.remoteJid ||
        null
    );
}

// ==========================================
// قراءة نص الأمر
// ==========================================

function getBody(msg) {
    return (
        msg.message?.conversation ||
        msg.message?.extendedTextMessage?.text ||
        ''
    ).trim();
}

// ==========================================
// الأمر
// ==========================================

module.exports = {

    command: 'شات',

    description:
        'فتح أو قفل إرسال الرسائل في المجموعة.',
emoji: '💬',
    usage:
        '.شات فتح\n.شات قفل',

    async execute(sock, msg) {

        const groupJid =
            msg.key.remoteJid;

        try {

            // ==================================
            // التأكد من المجموعة
            // ==================================

            if (
                !groupJid ||
                !groupJid.endsWith('@g.us')
            ) {

                return await sock.sendMessage(
                    groupJid,
                    {
                        text:
                            '❗ هذا الأمر يعمل داخل المجموعات فقط.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================
            // صلاحية النخبة
            // ==================================

            const sender =
                normalizeJid(
                    getSender(msg)
                );

            if (
                !sender ||
                !isElite(sender)
            ) {

                return await sock.sendMessage(
                    groupJid,
                    {
                        text:
                            '❌ ليس لديك صلاحية لاستخدام هذا الأمر.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================
            // استخراج الأمر
            // ==================================

            const body =
                getBody(msg);

            const args =
                body
                    .split(/\s+/)
                    .filter(Boolean);

            // args[0] = .شات
            // args[1] = فتح / قفل

            const option =
                args[1]?.toLowerCase();

            // ==================================
            // التحقق من الخيار
            // ==================================

            if (
                option !== 'فتح' &&
                option !== 'قفل'
            ) {

                return await sock.sendMessage(
                    groupJid,
                    {
                        text:
                            '❌ استخدم الأمر بالشكل الصحيح:\n\n' +
                            '🔓 `.شات فتح`\n' +
                            '🔒 `.شات قفل`'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================
            // فتح الشات
            // ==================================

            if (
                option === 'فتح'
            ) {

                await sock.groupSettingUpdate(
                    groupJid,
                    'not_announcement'
                );

                return await sock.sendMessage(
                    groupJid,
                    {
                        text:
                            '🔓 *تم فتح الشات*\n\n' +
                            '👥 أصبح بإمكان جميع الأعضاء إرسال الرسائل.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================
            // قفل الشات
            // ==================================

            if (
                option === 'قفل'
            ) {

                await sock.groupSettingUpdate(
                    groupJid,
                    'announcement'
                );

                return await sock.sendMessage(
                    groupJid,
                    {
                        text:
                            '🔒 *تم قفل الشات*\n\n' +
                            '👑 أصبح إرسال الرسائل للمشرفين فقط.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

        } catch (error) {

            console.error(
                '❌ خطأ في أمر الشات:',
                error
            );

            try {

                await sock.sendMessage(
                    groupJid,
                    {
                        text:
                            '❌ تعذر تغيير حالة الشات.\n\n' +
                            'تأكد أن البوت مشرف في المجموعة وأن لديه صلاحية تعديل إعدادات المجموعة.'
                    },
                    {
                        quoted: msg
                    }
                );

            } catch {}
        }
    }
};