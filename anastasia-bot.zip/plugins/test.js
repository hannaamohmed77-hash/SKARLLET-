
const os = require('os');

const startTime = Date.now();


function formatUptime(ms) {

    let seconds = Math.floor(ms / 1000);

    const days = Math.floor(seconds / 86400);
    seconds %= 86400;

    const hours = Math.floor(seconds / 3600);
    seconds %= 3600;

    const minutes = Math.floor(seconds / 60);
    seconds %= 60;

    const result = [];

    if (days) result.push(`${days} يوم`);
    if (hours) result.push(`${hours} ساعة`);
    if (minutes) result.push(`${minutes} دقيقة`);

    if (!result.length || seconds) {
        result.push(`${seconds} ثانية`);
    }

    return result.join(' و ');
}


function getCpuPercent() {
    const cores = os.cpus().length || 1;
    const load = os.loadavg()[0] || 0;
    const percent = (load / cores) * 100;
    return Math.min(100, Math.max(0, Math.round(percent)));
}


function getRamPercent() {
    const total = os.totalmem();
    const free = os.freemem();
    const percent = ((total - free) / total) * 100;
    return Math.round(percent);
}


function getPerformanceLabel(ping) {
    if (ping < 150) return 'ممتاز ⚡';
    if (ping < 400) return 'جيد 👍';
    if (ping < 800) return 'متوسط 🙂';
    return 'بطيء 🐢';
}


function getSystemStatus(cpuPercent, ramPercent) {
    if (cpuPercent < 80 && ramPercent < 85) return 'مستقر ✅';
    return 'تحت ضغط ⚠️';
}



module.exports = {

    command: 'تست',

    description: 'عرض حالة وأداء البوت',

    usage: '.تست',

    category: 'tools',

    emoji: '🤖',

    async execute(sock, msg) {

        const chatId = msg.key?.remoteJid;

        try {

            if (!chatId) {
                return;
            }

           
            const pingStart = Date.now();

            const sent = await sock.sendMessage(
                chatId,
                { text: '⏳ جاري الفحص...' },
                { quoted: msg }
            );

            const ping = Date.now() - pingStart;

            const cpuPercent = getCpuPercent();
            const ramPercent = getRamPercent();
            const uptime = formatUptime(Date.now() - startTime);
            const status = getSystemStatus(cpuPercent, ramPercent);
            const performance = getPerformanceLabel(ping);

            const text =
`𓆩🖤𓆪 𝔇𝔞𝔯𝔨 علي كامل استعداد

⚡ البينج: "${ping} ms"
🧠 المعالج: "${cpuPercent}%"
💾 الذاكرة: "${ramPercent}%"
⏱️ التشغيل: "${uptime}"
⚙️ النظام: "${status}"
🚦 الأداء: "${performance}"
🛡️ الحماية: نشطة
👑 الجاهزية: 100%

*لا ينتظر الاوامر*⚡🖤

*شرف لك استخدامي* 📓`;

            await sock.sendMessage(
                chatId,
                { text, edit: sent.key }
            ).catch(async () => {
                await sock.sendMessage(chatId, { text }, { quoted: msg });
            });

        } catch (error) {

            console.error(
                '❌ خطأ في أمر تست:',
                error
            );

            await sock.sendMessage(
                chatId,
                {
                    text:
`𓆩🖤𓆪 𝔇𝔞𝔯𝔨

❌ تعذر جلب حالة البوت

الخطأ:
${error.message || 'خطأ غير معروف'}`
                },
                {
                    quoted: msg
                }
            );
        }
    }
};
