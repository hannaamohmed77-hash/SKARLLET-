const fs = require('fs-extra');
const path = require('path');

// ======================================================
// 🎯 إعدادات الفعاليات والمسارات (المسار المخصص للاستضافة)
// ======================================================

const DATA_DIR = '/home/container/data';
const DATA_FILE = path.join(DATA_DIR, 'activities.json');
const TITLES_FILE = path.join(DATA_DIR, 'activityTitles.json');

const MAX_ROUNDS = 30;

// ======================================================
// 🗂️ الفعاليات الحالية والألقاب الدائمة
// ======================================================

const activities = new Map();
let globalTitles = {};

// ======================================================
// 📚 البيانات (الكلمات، الأعلام، الإيموجيات)
// ======================================================

const words = [
    'تانجيرو', 'توكيتو', 'كوكوشيبو', 'اينوسكي', 'زينيتسو', 'ايرين', 'ايسن',
    'ناروتو', 'ساسكي', 'غوجو', 'سوكونا', 'ميكاسا', 'ليفاي', 'كاكاشي',
    'مادارا', 'ايتاتشي', 'لوفي', 'زورو', 'سانجي', 'نامي', 'نيزوكو',
    'شينوبو', 'غيّو', 'رينغوكو', 'اكازا', 'موزان', 'اوبيتو', 'غارا', 'جيرايا', 'كيلوا'
];

const flags = [
    { flag: '🇧🇷', answer: 'البرازيل' }, { flag: '🇪🇬', answer: 'مصر' },
    { flag: '🇸🇦', answer: 'السعودية' }, { flag: '🇦🇪', answer: 'الامارات' },
    { flag: '🇯🇵', answer: 'اليابان' }, { flag: '🇰🇷', answer: 'كوريا الجنوبية' },
    { flag: '🇺🇸', answer: 'امريكا' }, { flag: '🇬🇧', answer: 'بريطانيا' },
    { flag: '🇫🇷', answer: 'فرنسا' }, { flag: '🇩🇪', answer: 'المانيا' },
    { flag: '🇮🇹', answer: 'ايطاليا' }, { flag: '🇪🇸', answer: 'اسبانيا' },
    { flag: '🇹🇷', answer: 'تركيا' }, { flag: '🇮🇳', answer: 'الهند' },
    { flag: '🇨🇳', answer: 'الصين' }, { flag: '🇷🇺', answer: 'روسيا' },
    { flag: '🇨🇦', answer: 'كندا' }, { flag: '🇲🇽', answer: 'المكسيك' },
    { flag: '🇦🇷', answer: 'الارجنتين' }, { flag: '🇵🇹', answer: 'البرتغال' }
];

const emojis = [
    { emoji: '🍎', answer: 'تفاح' }, { emoji: '🍌', answer: 'موز' },
    { emoji: '🍉', answer: 'بطيخ' }, { emoji: '🍓', answer: 'فراولة' },
    { emoji: '🍇', answer: 'عنب' }, { emoji: '🐱', answer: 'قطة' },
    { emoji: '🐶', answer: 'كلب' }, { emoji: '🦁', answer: 'اسد' },
    { emoji: '🐯', answer: 'نمر' }, { emoji: '🐼', answer: 'باندا' },
    { emoji: '🌙', answer: 'قمر' }, { emoji: '☀️', answer: 'شمس' },
    { emoji: '⭐', answer: 'نجمة' }, { emoji: '❤️', answer: 'قلب' },
    { emoji: '🔥', answer: 'نار' }
];

// ======================================================
// 🛠️ أدوات التنظيف والاستخراج
// ======================================================

function normalizeJid(jid) {
    return String(jid || '').trim().split(':')[0];
}

function normalizeText(text) {
    return String(text || '')
        .trim()
        .toLowerCase()
        .replace(/[ًٌٍَُِّْـ]/g, '')
        .replace(/[أإآ]/g, 'ا')
        .replace(/ة/g, 'ه')
        .replace(/ى/g, 'ي')
        .replace(/\s+/g, ' ');
}

function getText(msg) {
    return (
        msg.message?.conversation ||
        msg.message?.extendedTextMessage?.text ||
        msg.message?.imageMessage?.caption ||
        msg.message?.videoMessage?.caption ||
        msg.message?.documentMessage?.caption ||
        ''
    ).trim();
}

function getSender(msg) {
    const remote = msg.key?.remoteJid || '';
    let sender = msg.key?.participant || msg.participant || remote;
    return normalizeJid(sender);
}

function isGroup(msg) {
    return String(msg.key?.remoteJid || '').endsWith('@g.us');
}

function mention(jid) {
    const clean = normalizeJid(jid);
    const number = clean.split('@')[0].split(':')[0];
    return `@${number}`;
}

function randomWord() { return words[Math.floor(Math.random() * words.length)]; }
function randomFlag() { return flags[Math.floor(Math.random() * flags.length)]; }
function randomEmoji() { return emojis[Math.floor(Math.random() * emojis.length)]; }
function reverseWord(word) { return [...String(word)].reverse().join(''); }
function splitWord(word) { return [...String(word)].join(' '); }
function firstLetter(word) { return [...String(word)][0] || ''; }
function lastLetter(word) { const chars = [...String(word)]; return chars[chars.length - 1] || ''; }

function getTypeName(type) {
    const names = {
        'نسخ': 'فَـعَـالِـيَـةُ الـنَّـسْـخ 📜',
        'تفكيك': 'فَـعَـالِـيَـةُ الـتَّـفْـكـيـك 📜',
        'اعلام': 'فَـعَـالِـيَـةُ الأَعْـلَام 🏴',
        'عكس': 'فَـعَـالِـيَـةُ الـعَـكْـس 🔄',
        'اول حرف': 'فَـعَـالِـيَـةُ أَوَّل حَـرْف 🔤',
        'اخر حرف': 'فَـعَـالِـيَـةُ آخِـر حَـرْف 🔚',
        'او حرف': 'فَـعَـالِـيَـةُ أَو حَـرْف 🔤',
        'ايموجي': 'فَـعَـالِـيَـةُ الإيـمـوجـي 🎭'
    };
    return names[type] || type;
}

// ======================================================
// 💾 إدارة الألقاب (الحفظ القائم على مستوى البوت)
// ======================================================

function loadGlobalTitles() {
    try {
        fs.ensureDirSync(DATA_DIR);
        if (!fs.existsSync(TITLES_FILE)) {
            fs.writeJsonSync(TITLES_FILE, {}, { spaces: 2 });
            globalTitles = {};
            return;
        }
        globalTitles = fs.readJsonSync(TITLES_FILE);
        if (!globalTitles || typeof globalTitles !== 'object' || Array.isArray(globalTitles)) {
            globalTitles = {};
        }
    } catch (error) {
        console.error('❌ خطأ في تحميل الألقاب:', error.message);
        globalTitles = {};
    }
}

function saveGlobalTitles() {
    try {
        fs.ensureDirSync(DATA_DIR);
        fs.writeJsonSync(TITLES_FILE, globalTitles, { spaces: 2 });
    } catch (error) {
        console.error('❌ خطأ في حفظ الألقاب:', error.message);
    }
}

function setGlobalTitle(jid, title) {
    const cleanJid = normalizeJid(jid);
    if (!cleanJid || !title) return;
    globalTitles[cleanJid] = String(title).trim();
    saveGlobalTitles();
}

function getGlobalTitle(jid) {
    const cleanJid = normalizeJid(jid);
    return globalTitles[cleanJid] || '';
}

// تحميل الألقاب فوراً
loadGlobalTitles();

// ======================================================
// 🎯 المنطق الحسابي للفعالية
// ======================================================

function getAnswer(activity) {
    if (!activity) return '';
    if (activity.type === 'اعلام' || activity.type === 'ايموجي') {
        return normalizeText(activity.answer);
    }
    const word = activity.word || '';
    switch (activity.type) {
        case 'نسخ': return normalizeText(word);
        case 'تفكيك': return normalizeText(splitWord(word)).replace(/\s+/g, '');
        case 'عكس': return normalizeText(reverseWord(word));
        case 'اول حرف':
        case 'او حرف': return normalizeText(firstLetter(word));
        case 'اخر حرف': return normalizeText(lastLetter(word));
        default: return '';
    }
}

function checkAnswer(activity, text) {
    const received = normalizeText(text);
    const expected = getAnswer(activity);
    if (!received || !expected) return false;
    if (activity.type === 'تفكيك') {
        return received.replace(/\s/g, '') === expected.replace(/\s/g, '');
    }
    return received === expected;
}

function ensurePlayer(activity, jid) {
    const cleanJid = normalizeJid(jid);
    if (!activity.players[cleanJid]) {
        activity.players[cleanJid] = { jid: cleanJid, wins: 0 };
    }
    return activity.players[cleanJid];
}

function getRanking(activity) {
    return Object.values(activity.players || {}).sort((a, b) => b.wins - a.wins);
}

function createForm(activity) {
    let emoji = '📜';
    if (activity.type === 'اعلام') emoji = '🏴';
    else if (activity.type === 'عكس') emoji = '🔄';
    else if (activity.type === 'اول حرف' || activity.type === 'او حرف') emoji = '🔤';
    else if (activity.type === 'اخر حرف') emoji = '🔚';
    else if (activity.type === 'ايموجي') emoji = '🎭';

    const title = getTypeName(activity.type);
    let content = '';

    if (activity.type === 'اعلام') {
        content = `*⌗ ╎〘 ${title} 〙*\n\n*⌗ ╎ العــ${emoji}ـلم 〘 ${activity.word} 〙`;
    } else if (activity.type === 'ايموجي') {
        content = `*⌗ ╎〘 ${title} 〙*\n\n*⌗ ╎ الإيـ${emoji}ـموجي 〘 ${activity.word} 〙`;
    } else {
        content = `*⌗ ╎〘 ${title} 〙*\n\n*⌗ ╎ الكــ${emoji}ــلمة 〘 ${activity.word} 〙`;
    }

    return `════════ ❖ 🎼 ❖ ════════\n\n${content}\n\n            ↥ 𝑲.𝑵.𝑯 ╷🎼╵ 𝑴.𝑼.𝑺.𝑰.𝑪`;
}

function saveData() {
    fs.ensureDir(DATA_DIR).then(() => {
        const data = {};
        for (const [groupId, activity] of activities) {
            const { isProcessing, ...rest } = activity;
            data[groupId] = rest;
        }
        return fs.writeJson(DATA_FILE, data, { spaces: 2 });
    }).catch(err => console.error('❌ خطأ في حفظ الفعاليات:', err.message));
}

function prepareRound(activity) {
    if (activity.type === 'اعلام') {
        const selected = randomFlag();
        activity.word = selected.flag;
        activity.answer = selected.answer;
        return;
    }
    if (activity.type === 'ايموجي') {
        const selected = randomEmoji();
        activity.word = selected.emoji;
        activity.answer = selected.answer;
        return;
    }
    const word = randomWord();
    activity.word = word;
    activity.answer = getAnswer(activity);
}

async function sendRound(sock, groupId) {
    const activity = activities.get(groupId);
    if (!activity) return;

    prepareRound(activity);
    activity.isProcessing = false;

    await sock.sendMessage(groupId, { text: createForm(activity) });
}

// ======================================================
// 🏁 إنهاء الفعالية
// ======================================================

async function finishActivity(sock, groupId) {
    const activity = activities.get(groupId);
    if (!activity) return false;

    const ranking = getRanking(activity);
    const top = ranking.slice(0, 4);
    let winners = '';

    if (!top.length) {
        winners = '\n*لا يوجد فائزون حتى الآن*';
    } else {
        top.forEach((player, index) => {
            const title = getGlobalTitle(player.jid);
            const position = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : '🏅';
            const titleText = title ? ` | ${title}` : '';
            winners += `\n${position} *المنشن / اللقب : [${mention(player.jid)}${titleText}]*\n*عدد مرات الفوز【${player.wins}】*\n`;
        });
    }

    const hostTitle = getGlobalTitle(activity.host);
    const hostTitleText = hostTitle ? ` | ${hostTitle}` : '';

    const text = `*❒↵ اسم الفعالية『${activity.type}』*\n\n*❒↵ عدد الفعاليات المقدم/ة『${activity.round}』*\n\n*❒↵ الفائزون ☇*\n${winners}\n\n*المقــــــدم :*【${mention(activity.host)}${hostTitleText}】`;

    const mentions = top.map(player => player.jid);
    mentions.push(activity.host);

    await sock.sendMessage(groupId, { text, mentions });

    activities.delete(groupId);
    saveData();
    return true;
}

async function manualFinish(sock, msg) {
    const groupId = msg.key.remoteJid;
    const activity = activities.get(groupId);

    if (!activity) {
        await sock.sendMessage(groupId, { text: '⚠️ لا توجد فعالية تعمل حاليًا.' });
        return;
    }

    const sender = getSender(msg);
    if (sender !== activity.host) {
        await sock.sendMessage(groupId, { text: '❌ فقط مقدم الفعالية يستطيع إنهاءها.' });
        return;
    }

    await finishActivity(sock, groupId);
}

// ======================================================
// 🏷️ أمر الألقاب الدائم (على مستوي البوت)
// ======================================================

async function handleTitleCommand(sock, msg, args) {
    const groupId = msg.key.remoteJid;

    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];

    if (!mentioned) {
        await sock.sendMessage(groupId, { text: '❌ استخدم:\n.فعالية @الشخص اللقب' });
        return;
    }

    const title = args.filter(arg => !arg.startsWith('@')).join(' ').trim();
    if (!title) {
        await sock.sendMessage(groupId, { text: '❌ اكتب اللقب بعد المنشن.\n\nمثال:\n.فعالية @فلان توجي' });
        return;
    }

    const cleanJid = normalizeJid(mentioned);
    
    setGlobalTitle(cleanJid, title);

    await sock.sendMessage(groupId, { 
        text: `🏷️ تم حفظ ${mention(cleanJid)} كا ${title} بنجاح على مستوى البوت!`, 
        mentions: [cleanJid] 
    });
}

async function startActivity(sock, msg, type) {
    const groupId = msg.key.remoteJid;
    const sender = getSender(msg);

    if (activities.has(groupId)) {
        await sock.sendMessage(groupId, { text: '⚠️ توجد فعالية تعمل بالفعل في هذه المجموعة.' });
        return;
    }

    const activity = {
        type,
        host: sender,
        round: 1,
        maxRounds: MAX_ROUNDS,
        word: '',
        answer: '',
        players: {},
        isProcessing: false,
        startedAt: Date.now()
    };

    activities.set(groupId, activity);
    await sendRound(sock, groupId);
}

// ======================================================
// 🎯 استقبال الإجابات
// ======================================================

async function handleAnswer(sock, msg) {
    const groupId = msg.key?.remoteJid;
    if (!groupId || !groupId.endsWith('@g.us')) return;

    const activity = activities.get(groupId);
    if (!activity) return;

    if (activity.isProcessing) return;

    const text = getText(msg);
    if (!text || text.startsWith('.')) return;

    const sender = getSender(msg);
    if (sender === activity.host) return;

    if (!checkAnswer(activity, text)) return;

    activity.isProcessing = true;

    try {
        const player = ensurePlayer(activity, sender);
        player.wins++;

        await sock.sendMessage(groupId, {
            text: `🏆 ${mention(sender)}\nتست ${player.wins}`,
            mentions: [sender]
        });

        if (activity.round >= activity.maxRounds) {
            await finishActivity(sock, groupId);
            return;
        }

        activity.round++;
        await sendRound(sock, groupId);

    } catch (error) {
        console.error("خطأ أثناء معالجة الإجابة:", error);
        activity.isProcessing = false;
    }
}

// ======================================================
// 🎯 Plugin الرئيسي
// ======================================================

async function execute(sock, msg) {
    if (!isGroup(msg)) {
        await sock.sendMessage(msg.key.remoteJid, { text: '❌ هذا الأمر يعمل داخل المجموعات فقط.' });
        return;
    }

    const text = getText(msg);
    const args = text.trim().split(/\s+/).slice(1);
    const action = normalizeText(args[0] || '');

    if (action === 'انهاء') {
        await manualFinish(sock, msg);
        return;
    }

    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length;
    if (mentioned) {
        await handleTitleCommand(sock, msg, args);
        return;
    }

    const types = ['نسخ', 'تفكيك', 'اعلام', 'عكس', 'اول حرف', 'اخر حرف', 'او حرف', 'ايموجي'];
    const type = args.join(' ').trim();

    if (!types.includes(type)) {
        await sock.sendMessage(msg.key.remoteJid, {
            text: `🎯 *فعالية*\n\nاختار فعالية من الأنواع التالية:\n\n• نسخ\n• تفكيك\n• اعلام\n• عكس\n• اول حرف\n• اخر حرف\n• او حرف\n• ايموجي\n\n🏷️ إضافة لقب:\n.فعالية @فلان توجي\n\n🏁 إنهاء:\n.فعالية انهاء\n\nمثال:\n.فعالية نسخ`
        });
        return;
    }

    await startActivity(sock, msg, type);
}

module.exports = {
    command: 'فعالية',
    category: 'games',
    emoji: '🎯',
    execute,
    handleActivityMessage: handleAnswer,
    activities
};
