const groupMonitor =
    require('../lib/groupMonitor');

module.exports = {

    command: 'المراقب',

    description:
        'التحكم في مراقبة حالات المجموعات',
    
emoji: '👁️',
    
    category: 'group',

    async execute(sock, msg) {

        try {

            const chatId =
                msg.key?.remoteJid;

            if (
                !chatId ||
                !chatId.endsWith('@g.us')
            ) {

                await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ هذا الأمر يعمل داخل المجموعات فقط.'
                    },
                    {
                        quoted: msg
                    }
                );

                return;
            }

            const text =
                msg.message?.conversation ||
                msg.message?.extendedTextMessage?.text ||
                '';

            const args =
                text.trim().split(/\s+/);

            const action =
                args[1]?.toLowerCase();

            // ==================================================
            // تشغيل
            // ==================================================

            if (action === 'تشغيل') {

                await groupMonitor.enable(chatId);

                await sock.sendMessage(
                    chatId,
                    {
                        text:
`🟢 تم تشغيل مراقبة حالات المجموعة

سيتم الآن رصد تغييرات الأعضاء والمشرفين في هذه المجموعة.`
                    },
                    {
                        quoted: msg
                    }
                );

                return;
            }

            // ==================================================
            // إيقاف
            // ==================================================

            if (
                action === 'ايقاف' ||
                action === 'إيقاف'
            ) {

                await groupMonitor.disable(chatId);

                await sock.sendMessage(
                    chatId,
                    {
                        text:
`🔴 تم إيقاف مراقبة حالات المجموعة

لن يتم إرسال تقارير عن أحداث هذه المجموعة.`
                    },
                    {
                        quoted: msg
                    }
                );

                return;
            }

            // ==================================================
            // هنا
            // ==================================================

            if (action === 'هنا') {

                await groupMonitor.setHere(
                    chatId
                );

                await sock.sendMessage(
                    chatId,
                    {
                        text:
`📍 تم ضبط وجهة تقارير المراقب

من الآن ستُرسل أحداث جميع المجموعات المفعّل فيها المراقب إلى هذه المجموعة.

⚙️ الوضع الحالي:
مراقبة مركزية`
                    },
                    {
                        quoted: msg
                    }
                );

                return;
            }

            // ==================================================
            // افتراضي
            // ==================================================

            if (action === 'افتراضي') {

                await groupMonitor.setDefault();

                await sock.sendMessage(
                    chatId,
                    {
                        text:
`🌐 تم إلغاء المراقبة المركزية

سيتم الآن إرسال كل تقرير داخل المجموعة التي حدث فيها التغيير.`
                    },
                    {
                        quoted: msg
                    }
                );

                return;
            }

            // ==================================================
            // المساعدة
            // ==================================================

            await sock.sendMessage(
                chatId,
                {
                    text:
`📋 أوامر المراقب

.المراقب تشغيل
تفعيل رصد أحداث هذه المجموعة

.المراقب ايقاف
إيقاف رصد أحداث هذه المجموعة

.المراقب هنا
جعل هذه المجموعة مركز استقبال تقارير جميع المجموعات المفعّل فيها المراقب

.المراقب افتراضي
إلغاء مركز التقارير وإرسال كل تقرير داخل المجموعة التي حدث فيها`
                },
                {
                    quoted: msg
                }
            );

        } catch (error) {

            console.error(
                '❌ خطأ في أمر المراقب:',
                error
            );

            await sock.sendMessage(
                msg.key?.remoteJid,
                {
                    text:
                        '❌ حدث خطأ أثناء تنفيذ أمر المراقب.'
                },
                {
                    quoted: msg
                }
            ).catch(() => {});
        }
    }
};