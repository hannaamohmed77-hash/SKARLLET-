const fs = require('fs');
const path = require('path');
const { isElite } = require('../haykala/elite.js');
const { jidDecode } = require('@whiskeysockets/baileys');

// ==========================================
// إعدادات الملفات
// ==========================================

const dataDir = path.join(__dirname, '..', 'data');
const muteFilePath = path.join(dataDir, 'muted.json');

if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

if (!fs.existsSync(muteFilePath)) {
  fs.writeFileSync(
    muteFilePath,
    JSON.stringify([], null, 2),
    'utf8'
  );
}

// ==========================================
// تحميل قائمة المكتومين
// ==========================================

function loadMuted() {
  try {
    const data = fs.readFileSync(muteFilePath, 'utf8');
    const parsed = JSON.parse(data);

    if (!Array.isArray(parsed)) {
      return [];
    }

    return [
      ...new Set(
        parsed
          .filter(Boolean)
          .map(normalizeJid)
          .filter(Boolean)
      )
    ];

  } catch (err) {
    console.error('❌ خطأ في تحميل ملف الكتم:', err);
    return [];
  }
}

// ==========================================
// حفظ قائمة المكتومين
// ==========================================

function saveMuted(data) {
  try {
    const unique = [
      ...new Set(
        data
          .filter(Boolean)
          .map(normalizeJid)
          .filter(Boolean)
      )
    ];

    fs.writeFileSync(
      muteFilePath,
      JSON.stringify(unique, null, 2),
      'utf8'
    );

    return true;

  } catch (err) {
    console.error('❌ خطأ في حفظ ملف الكتم:', err);
    return false;
  }
}

// ==========================================
// توحيد JID
// ==========================================

function normalizeJid(jid) {
  if (!jid) return null;

  try {
    const decoded = jidDecode(jid);

    if (decoded?.user) {
      return `${decoded.user}@s.whatsapp.net`;
    }

    const user = String(jid)
      .split('@')[0]
      .split(':')[0]
      .trim();

    if (!user) return null;

    return `${user}@s.whatsapp.net`;

  } catch {
    const user = String(jid)
      .split('@')[0]
      .split(':')[0]
      .trim();

    return user
      ? `${user}@s.whatsapp.net`
      : null;
  }
}

// ==========================================
// الحصول على صاحب الرسالة
// ==========================================

function getSender(msg) {
  return (
    msg?.key?.participant ||
    msg?.participant ||
    msg?.key?.remoteJid ||
    null
  );
}

// ==========================================
// استخراج نص الأمر
// ==========================================

function getBody(msg) {
  return (
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text ||
    ''
  ).trim();
}

// ==========================================
// الحصول على الشخص المستهدف
// يدعم المنشن والرد
// ==========================================

function getTarget(msg) {
  const context =
    msg.message?.extendedTextMessage?.contextInfo;

  const mentioned =
    context?.mentionedJid?.[0];

  const replied =
    context?.participant;

  return mentioned || replied || null;
}

// ==========================================
// مراقبين الاتصالات
// Listener واحد لكل Sock
// ==========================================

const watchers = new WeakMap();

// ==========================================
// تشغيل مراقب الكتم
// ==========================================

function startWatcher(sock) {

  if (watchers.has(sock)) {
    return;
  }

  const listener = async ({ messages }) => {

    try {

      const mutedSet = new Set(loadMuted());

      if (mutedSet.size === 0) {
        return;
      }

      for (const msg of messages) {

        try {

          if (!msg?.key) {
            continue;
          }

          // عدم حذف رسائل البوت
          if (msg.key.fromMe) {
            continue;
          }

          const chatId =
            msg.key.remoteJid;

          if (!chatId) {
            continue;
          }

          // الكتم يعمل داخل الجروبات فقط
          if (!chatId.endsWith('@g.us')) {
            continue;
          }

          const sender =
            getSender(msg);

          if (!sender) {
            continue;
          }

          const normalizedSender =
            normalizeJid(sender);

          if (!normalizedSender) {
            continue;
          }

          // هل الشخص مكتوم؟
          if (!mutedSet.has(normalizedSender)) {
            continue;
          }

          // ======================================
          // حذف الرسالة
          // ======================================

          await sock.sendMessage(
            chatId,
            {
              delete: {
                remoteJid: chatId,
                fromMe: false,
                id: msg.key.id,
                participant: sender
              }
            }
          );

        } catch (err) {

          console.error(
            '⚠️ فشل حذف رسالة المكتوم:',
            err.message
          );
        }
      }

    } catch (err) {

      console.error(
        '❌ خطأ داخل مراقب الكتم:',
        err.message
      );
    }
  };

  sock.ev.on(
    'messages.upsert',
    listener
  );

  watchers.set(sock, listener);
}

// ==========================================
// إيقاف مراقب الكتم
// ==========================================

function stopWatcher(sock) {

  const listener =
    watchers.get(sock);

  if (!listener) {
    return;
  }

  try {

    sock.ev.off(
      'messages.upsert',
      listener
    );

  } catch (err) {

    console.error(
      '❌ فشل إيقاف مراقب الكتم:',
      err.message
    );
  }

  watchers.delete(sock);
}

// ==========================================
// الأمر الرئيسي
// ==========================================

module.exports = {

  command: 'كتم',

  description:
    'كتم عضو ومنع رسائله من الظهور داخل الجروب.',
emoji: '🔇',
  usage:
    '.كتم @منشن\n' +
    '.كتم بالرد على رسالة\n' +
    '.كتم الغاء @منشن\n' +
    '.كتم حالة\n' +
    '.كتم تحرير',

  async execute(sock, m) {

    const chatId =
      m.key.remoteJid;

    try {

      // ======================================
      // الأمر للنخبة فقط
      // ======================================

      const sender =
        getSender(m);

      if (
        !sender ||
        !isElite(sender)
      ) {
        return;
      }

      // ======================================
      // يجب أن يكون داخل جروب
      // ======================================

      if (
        !chatId ||
        !chatId.endsWith('@g.us')
      ) {

        return await sock.sendMessage(
          chatId,
          {
            text:
              '⚠️ أمر الكتم يعمل داخل المجموعات فقط.'
          },
          { quoted: m }
        );
      }

      // ======================================
      // قراءة الأمر
      // ======================================

      const body =
        getBody(m);

      const args =
        body.split(/\s+/).slice(1);

      const action =
        args[0]?.toLowerCase() || '';

      // ======================================
      // تحميل القائمة
      // ======================================

      let mutedUsers =
        loadMuted();

      // ======================================
      // حالة الكتم
      // ======================================

      if (
        action === 'حالة' ||
        action === 'الحالة'
      ) {

        if (
          mutedUsers.length === 0
        ) {

          return await sock.sendMessage(
            chatId,
            {
              text:
                '🔇 لا يوجد أي عضو مكتوم حالياً.'
            },
            { quoted: m }
          );
        }

        const list =
          mutedUsers
            .map(
              (jid, index) =>
                `${index + 1}. @${jid.split('@')[0]}`
            )
            .join('\n');

        return await sock.sendMessage(
          chatId,
          {
            text:
              `🔇 *قائمة المكتومين*\n\n` +
              `${list}\n\n` +
              `👥 العدد: ${mutedUsers.length}`,

            mentions:
              mutedUsers
          },
          { quoted: m }
        );
      }

      // ======================================
      // تحرير جميع المكتومين
      // ======================================

      if (
        action === 'تحرير' ||
        action === 'مسح' ||
        action === 'الكل'
      ) {

        saveMuted([]);

        stopWatcher(sock);

        return await sock.sendMessage(
          chatId,
          {
            text:
              '✅ تم تحرير جميع المكتومين وإيقاف نظام الكتم.'
          },
          { quoted: m }
        );
      }

      // ======================================
      // إلغاء الكتم
      // ======================================

      if (
        action === 'الغاء' ||
        action === 'إلغاء' ||
        action === 'فك'
      ) {

        const target =
          getTarget(m);

        if (!target) {

          return await sock.sendMessage(
            chatId,
            {
              text:
                '❌ قم بمنشن العضو أو الرد على رسالته.\n\n' +
                'مثال:\n' +
                '.كتم الغاء @العضو'
            },
            { quoted: m }
          );
        }

        const normalizedTarget =
          normalizeJid(target);

        if (!normalizedTarget) {

          return await sock.sendMessage(
            chatId,
            {
              text:
                '❌ تعذر تحديد العضو.'
            },
            { quoted: m }
          );
        }

        if (
          !mutedUsers.includes(
            normalizedTarget
          )
        ) {

          return await sock.sendMessage(
            chatId,
            {
              text:
                'ℹ️ هذا العضو غير مكتوم أصلاً.'
            },
            { quoted: m }
          );
        }

        mutedUsers =
          mutedUsers.filter(
            jid =>
              jid !== normalizedTarget
          );

        saveMuted(
          mutedUsers
        );

        if (
          mutedUsers.length === 0
        ) {
          stopWatcher(sock);
        }

        return await sock.sendMessage(
          chatId,
          {
            text:
              '🔊 تم إلغاء كتم العضو بنجاح.'
          },
          { quoted: m }
        );
      }

      // ======================================
      // تحديد العضو المراد كتمه
      // ======================================

      const target =
        getTarget(m);

      if (!target) {

        return await sock.sendMessage(
          chatId,
          {
            text:
              '🔇 *طريقة استخدام أمر الكتم*\n\n' +

              '• `.كتم @منشن`\n' +
              '• `.كتم` ← بالرد على رسالة\n\n' +

              '• `.كتم الغاء @منشن`\n' +
              '• `.كتم حالة`\n' +
              '• `.كتم تحرير`'
          },
          { quoted: m }
        );
      }

      const normalizedTarget =
        normalizeJid(target);

      if (!normalizedTarget) {

        return await sock.sendMessage(
          chatId,
          {
            text:
              '❌ تعذر تحديد العضو.'
          },
          { quoted: m }
        );
      }

      // ======================================
      // منع كتم البوت
      // ======================================

      const botJid =
        normalizeJid(
          sock.user?.id
        );

      if (
        botJid &&
        normalizedTarget === botJid
      ) {

        return await sock.sendMessage(
          chatId,
          {
            text:
              '🤖 لا يمكن كتم البوت.'
          },
          { quoted: m }
        );
      }

      // ======================================
      // لا يوجد استثناء للنخبة
      // النخبة يمكن كتمها عادي
      // ======================================

      // ======================================
      // التحقق من الكتم الحالي
      // ======================================

      if (
        mutedUsers.includes(
          normalizedTarget
        )
      ) {

        return await sock.sendMessage(
          chatId,
          {
            text:
              'ℹ️ العضو مكتوم بالفعل.'
          },
          { quoted: m }
        );
      }

      // ======================================
      // إضافة العضو للقائمة
      // ======================================

      mutedUsers.push(
        normalizedTarget
      );

      if (
        !saveMuted(mutedUsers)
      ) {

        return await sock.sendMessage(
          chatId,
          {
            text:
              '❌ فشل حفظ العضو في قائمة المكتومين.'
          },
          { quoted: m }
        );
      }

      // ======================================
      // تشغيل المراقبة
      // ======================================

      startWatcher(sock);

      // ======================================
      // الرد النهائي
      // ======================================

      await sock.sendMessage(
        chatId,
        {
          text:
            '🔇 *تم كتم العضو بنجاح.*\n\n' +
            '🚫 سيتم حذف رسائله تلقائياً.'
        },
        { quoted: m }
      );

    } catch (err) {

      console.error(
        '❌ خطأ في أمر كتم:',
        err
      );

      try {

        await sock.sendMessage(
          chatId,
          {
            text:
              '❌ حدث خطأ أثناء تنفيذ أمر الكتم.'
          },
          { quoted: m }
        );

      } catch {}
    }
  }
};