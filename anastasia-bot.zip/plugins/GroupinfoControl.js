const { isElite } = require('../haykala/elite.js');
const { jidDecode } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');

// ==========================================
// 📦 مجلد النسخ على مستوى البوت
// ==========================================

const baseDir = path.join(
    process.cwd(),
    'tmp',
    'copy-group'
);

if (!fs.existsSync(baseDir)) {
    fs.mkdirSync(
        baseDir,
        {
            recursive: true
        }
    );
}

// ==========================================
// 🔐 توحيد JID
// ==========================================

function normalizeJid(jid) {

    if (!jid) {
        return null;
    }

    try {

        const decoded =
            jidDecode(jid);

        if (decoded?.user) {

            return `${decoded.user}@s.whatsapp.net`;
        }

        const user =
            String(jid)
                .split('@')[0]
                .split(':')[0]
                .trim();

        return user
            ? `${user}@s.whatsapp.net`
            : null;

    } catch {

        const user =
            String(jid)
                .split('@')[0]
                .split(':')[0]
                .trim();

        return user
            ? `${user}@s.whatsapp.net`
            : null;
    }
}

// ==========================================
// 👤 صاحب الرسالة
// ==========================================

function getSender(msg) {

    return (
        msg.key?.participant ||
        msg.participant ||
        msg.key?.remoteJid
    );
}

// ==========================================
// 💬 قراءة نص الأمر
// ==========================================

function getBody(msg) {

    return (
        msg.message?.conversation ||
        msg.message?.extendedTextMessage?.text ||
        msg.message?.imageMessage?.caption ||
        msg.message?.videoMessage?.caption ||
        ''
    ).trim();
}

// ==========================================
// 🛡️ حماية اسم النسخة
// ==========================================

function safeName(name) {

    if (!name) {
        return null;
    }

    const cleaned =
        String(name)
            .replace(
                /[<>:"/\\|?*\x00-\x1F]/g,
                ''
            )
            .replace(
                /\.\./g,
                ''
            )
            .trim();

    if (!cleaned) {
        return null;
    }

    return cleaned.slice(
        0,
        80
    );
}

// ==========================================
// 📁 مسار النسخة
// على مستوى البوت وليس الجروب
// ==========================================

function getBackupDir(name) {

    return path.join(
        baseDir,
        name
    );
}

// ==========================================
// 📄 مسار البيانات
// ==========================================

function getDataPath(name) {

    return path.join(
        getBackupDir(name),
        'groupData.json'
    );
}

// ==========================================
// 📖 قراءة النسخة
// ==========================================

function readBackup(name) {

    const dataPath =
        getDataPath(name);

    if (
        !fs.existsSync(dataPath)
    ) {
        return null;
    }

    try {

        return JSON.parse(
            fs.readFileSync(
                dataPath,
                'utf8'
            )
        );

    } catch {

        return null;
    }
}

// ==========================================
// 💾 حفظ النسخة
// ==========================================

function saveBackup(
    name,
    data
) {

    const dir =
        getBackupDir(name);

    fs.mkdirSync(
        dir,
        {
            recursive: true
        }
    );

    fs.writeFileSync(
        path.join(
            dir,
            'groupData.json'
        ),
        JSON.stringify(
            data,
            null,
            2
        ),
        'utf8'
    );
}

// ==========================================
// 🖼️ حفظ صورة المجموعة
// ==========================================

async function saveGroupPicture(
    sock,
    groupJid,
    backupDir
) {

    try {

        const pictureUrl =
            await sock.profilePictureUrl(
                groupJid,
                'image'
            );

        if (!pictureUrl) {
            return false;
        }

        const response =
            await fetch(
                pictureUrl
            );

        if (!response.ok) {
            return false;
        }

        const arrayBuffer =
            await response.arrayBuffer();

        const buffer =
            Buffer.from(
                arrayBuffer
            );

        if (!buffer.length) {
            return false;
        }

        fs.writeFileSync(
            path.join(
                backupDir,
                'group.jpg'
            ),
            buffer
        );

        return true;

    } catch {

        return false;
    }
}

// ==========================================
// 📂 الحصول على النسخ
// ==========================================

function getBackups() {

    if (
        !fs.existsSync(baseDir)
    ) {
        return [];
    }

    try {

        return fs.readdirSync(
            baseDir,
            {
                withFileTypes: true
            }
        )
        .filter(item =>
            item.isDirectory()
        )
        .map(item =>
            item.name
        )
        .filter(name =>
            fs.existsSync(
                getDataPath(name)
            )
        );

    } catch {

        return [];
    }
}

// ==========================================
// 🚀 الأمر
// ==========================================

module.exports = {

    command: 'نسخة',

    description:
        'حفظ واسترجاع نسخ المجموعات على مستوى البوت.',

    usage:
        '.نسخة نسخ [اسم]\n' +
        '.نسخة لصق [اسم]\n' +
        '.نسخة حذف [اسم]\n' +
        '.نسخة حافظة',

    category: 'group',

    emoji: '📦',

    async execute(
        sock,
        msg
    ) {

        const groupJid =
            msg.key?.remoteJid;

        try {

            // ==================================
            // 👥 التأكد من المجموعة
            // ==================================

            if (
                !groupJid ||
                !groupJid.endsWith('@g.us')
            ) {

                return await sock.sendMessage(
                    groupJid,
                    {
                        text:
                            '❗ هذا الأمر يعمل داخل المجموعات فقط.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================
            // 👑 صلاحية النخبة
            // ==================================

            const sender =
                normalizeJid(
                    getSender(msg)
                );

            if (
                !sender ||
                !isElite(sender)
            ) {

                return await sock.sendMessage(
                    groupJid,
                    {
                        text:
                            '❌ ليس لديك صلاحية لاستخدام هذا الأمر.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================
            // 📖 قراءة الأمر
            // ==================================

            const body =
                getBody(msg);

            const args =
                body
                    .split(/\s+/)
                    .filter(Boolean);

            const action =
                args[1]?.toLowerCase();

            const rawName =
                args
                    .slice(2)
                    .join(' ')
                    .trim();

            const name =
                safeName(rawName);

            // ==================================
            // 📦 بدون أمر
            // ==================================

            if (!action) {

                return await sock.sendMessage(
                    groupJid,
                    {
                        text:
`📦 *نظام نسخ المجموعات*

📥 .نسخة نسخ [اسم]
📤 .نسخة لصق [اسم]
🗑️ .نسخة حذف [اسم]
📋 .نسخة حافظة

مثال:

.نسخة نسخ مجموعة1

ثم تقدر تستخدم:

.نسخة لصق مجموعة1

من أي مجموعة.`
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================
            // 📥 نسخ المجموعة
            // ==================================

            if (
                action === 'نسخ' ||
                action === 'حفظ'
            ) {

                if (!name) {

                    return await sock.sendMessage(
                        groupJid,
                        {
                            text:
`❗ اكتب اسم النسخة.

مثال:

.نسخة نسخ مجموعة1`
                        },
                        {
                            quoted: msg
                        }
                    );
                }

                // ==================================
                // ⚠️ التحقق من وجود نسخة قديمة
                // ==================================

                const oldBackup =
                    readBackup(name);

                // ==================================
                // 📊 بيانات المجموعة
                // ==================================

                const metadata =
                    await sock.groupMetadata(
                        groupJid
                    );

                const backupDir =
                    getBackupDir(name);

                fs.mkdirSync(
                    backupDir,
                    {
                        recursive: true
                    }
                );

                // ==================================
                // 🖼️ حفظ الصورة
                // ==================================

                const pictureSaved =
                    await saveGroupPicture(
                        sock,
                        groupJid,
                        backupDir
                    );

                // ==================================
                // 💾 بيانات النسخة
                // ==================================

                const groupData = {

                    version: 3,

                    subject:
                        metadata.subject || '',

                    description:
                        metadata.desc || '',

                    settings: {

                        announce:
                            Boolean(
                                metadata.announce
                            ),

                        restrict:
                            Boolean(
                                metadata.restrict
                            )
                    },

                    created:
                        metadata.creation || null,

                    sourceGroup:
                        groupJid,

                    sourceGroupName:
                        metadata.subject || '',

                    savedAt:
                        new Date().toISOString(),

                    hasPicture:
                        pictureSaved
                };

                saveBackup(
                    name,
                    groupData
                );

                // ==================================
                // 📩 الرد
                // ==================================

                return await sock.sendMessage(
                    groupJid,
                    {
                        text:
`✅ *تم حفظ نسخة المجموعة*

📦 الاسم: ${name}

🏷️ اسم المجموعة:
${groupData.subject || 'بدون اسم'}

📝 الوصف:
${groupData.description ? 'موجود' : 'غير موجود'}

⚙️ الإعدادات:
تم حفظها

🖼️ الصورة:
${pictureSaved ? 'تم حفظها' : 'غير موجودة'}

📍 النسخة محفوظة على مستوى البوت.

${oldBackup ? '♻️ تم استبدال النسخة القديمة.' : '🆕 تم إنشاء نسخة جديدة.'}`
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================
            // 📤 لصق النسخة
            // ==================================

            if (
                action === 'لصق' ||
                action === 'استرجاع'
            ) {

                if (!name) {

                    return await sock.sendMessage(
                        groupJid,
                        {
                            text:
`❗ اكتب اسم النسخة.

مثال:

.نسخة لصق مجموعة1`
                        },
                        {
                            quoted: msg
                        }
                    );
                }

                // ==================================
                // 📖 قراءة النسخة
                // ==================================

                const data =
                    readBackup(name);

                if (!data) {

                    return await sock.sendMessage(
                        groupJid,
                        {
                            text:
`❌ النسخة "${name}" غير موجودة عند البوت.

استخدم:

.نسخة حافظة

لعرض النسخ الموجودة.`
                        },
                        {
                            quoted: msg
                        }
                    );
                }

                // ==================================
                // 🏷️ الاسم
                // ==================================

                if (
                    typeof data.subject === 'string'
                ) {

                    try {

                        await sock.groupUpdateSubject(
                            groupJid,
                            data.subject
                        );

                    } catch {}
                }

                // ==================================
                // 📝 الوصف
                // ==================================

                if (
                    typeof data.description === 'string'
                ) {

                    try {

                        await sock.groupUpdateDescription(
                            groupJid,
                            data.description
                        );

                    } catch {}
                }

                // ==================================
                // ⚙️ الإعدادات
                // ==================================

                if (data.settings) {

                    // وضع المجموعة
                    try {

                        await sock.groupSettingUpdate(
                            groupJid,
                            data.settings.announce
                                ? 'announcement'
                                : 'not_announcement'
                        );

                    } catch {}

                    // صلاحية تعديل معلومات المجموعة
                    try {

                        await sock.groupSettingUpdate(
                            groupJid,
                            data.settings.restrict
                                ? 'locked'
                                : 'unlocked'
                        );

                    } catch {}
                }

                // ==================================
                // 🖼️ استرجاع الصورة
                // ==================================

                const imagePath =
                    path.join(
                        getBackupDir(name),
                        'group.jpg'
                    );

                let pictureRestored =
                    false;

                if (
                    fs.existsSync(
                        imagePath
                    )
                ) {

                    try {

                        await sock.updateProfilePicture(
                            groupJid,
                            {
                                url: imagePath
                            }
                        );

                        pictureRestored =
                            true;

                    } catch {}
                }

                // ==================================
                // 📩 الرد النهائي
                // ==================================

                return await sock.sendMessage(
                    groupJid,
                    {
                        text:
`✅ *تم لصق النسخة بنجاح*

📦 النسخة: ${name}

🏷️ الاسم: تم
📝 الوصف: تم
⚙️ الإعدادات: تم
🖼️ الصورة: ${
    pictureRestored
        ? 'تم'
        : 'غير متوفرة'
}

📍 المصدر:
${data.sourceGroupName || 'غير معروف'}`
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================
            // 🗑️ حذف النسخة
            // ==================================

            if (
                action === 'حذف' ||
                action === 'مسح'
            ) {

                if (!name) {

                    return await sock.sendMessage(
                        groupJid,
                        {
                            text:
`❗ اكتب اسم النسخة المراد حذفها.

مثال:

.نسخة حذف مجموعة1`
                        },
                        {
                            quoted: msg
                        }
                    );
                }

                const backupDir =
                    getBackupDir(name);

                if (
                    !fs.existsSync(
                        backupDir
                    )
                ) {

                    return await sock.sendMessage(
                        groupJid,
                        {
                            text:
`❌ النسخة "${name}" غير موجودة.`
                        },
                        {
                            quoted: msg
                        }
                    );
                }

                fs.rmSync(
                    backupDir,
                    {
                        recursive: true,
                        force: true
                    }
                );

                return await sock.sendMessage(
                    groupJid,
                    {
                        text:
`🗑️ *تم حذف النسخة*

📦 ${name}

تم حذفها من حافظة البوت بالكامل.`
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================
            // 📋 حافظة النسخ
            // ==================================

            if (
                action === 'حافظة' ||
                action === 'قائمة' ||
                action === 'عرض'
            ) {

                const folders =
                    getBackups();

                if (
                    !folders.length
                ) {

                    return await sock.sendMessage(
                        groupJid,
                        {
                            text:
`📂 *حافظة النسخ فارغة*

لا توجد أي نسخ محفوظة عند البوت.`
                        },
                        {
                            quoted: msg
                        }
                    );
                }

                let reply =
                    '📦 *حافظة نسخ البوت*\n\n';

                folders.forEach(
                    (folder, index) => {

                        const data =
                            readBackup(
                                folder
                            );

                        let date =
                            'غير معروف';

                        if (
                            data?.savedAt
                        ) {

                            try {

                                date =
                                    new Date(
                                        data.savedAt
                                    ).toLocaleString(
                                        'ar-EG',
                                        {
                                            dateStyle:
                                                'short',

                                            timeStyle:
                                                'short'
                                        }
                                    );

                            } catch {}
                        }

                        reply +=
                            `${index + 1}. 📁 *${folder}*\n` +
                            `   🏷️ ${data?.sourceGroupName || 'غير معروف'}\n` +
                            `   📅 ${date}\n` +
                            `   🖼️ ${data?.hasPicture ? 'موجودة' : 'غير موجودة'}\n\n`;
                    }
                );

                reply +=
                    `📊 إجمالي النسخ: ${folders.length}`;

                return await sock.sendMessage(
                    groupJid,
                    {
                        text: reply
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================
            // ❌ أمر غير معروف
            // ==================================

            return await sock.sendMessage(
                groupJid,
                {
                    text:
`❌ الأمر غير معروف.

📦 *الاستخدام الصحيح:*

📥 .نسخة نسخ [اسم]
📤 .نسخة لصق [اسم]
🗑️ .نسخة حذف [اسم]
📋 .نسخة حافظة`
                },
                {
                    quoted: msg
                }
            );

        } catch (err) {

            console.error(
                '❌ خطأ في أمر النسخة:',
                err
            );

            try {

                await sock.sendMessage(
                    groupJid,
                    {
                        text:
                            '❌ حدث خطأ أثناء تنفيذ أمر النسخة.'
                    },
                    {
                        quoted: msg
                    }
                );

            } catch {}
        }
    }
};