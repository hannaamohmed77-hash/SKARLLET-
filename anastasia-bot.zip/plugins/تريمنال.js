const { exec } = require('child_process');
const { promisify } = require('util');
const { isElite } = require('../haykala/elite');

const execAsync = promisify(exec);

// ======================================================
// ⚙️ إعدادات
// ======================================================

const COMMAND_TIMEOUT = 30000; // مهلة التنفيذ (30 ثانية للأوامر الطويلة)
const MAX_OUTPUT = 4000;       // أقصى حد للرسالة الواحدة لتفادي حظر واتساب

// ======================================================
// 🔐 استخراج رقم المرسل
// ======================================================

function getSenderNumber(message) {
    const remoteJid = message.key?.remoteJid || '';
    let sender = '';

    if (remoteJid.endsWith('@g.us')) {
        sender =
            message.key?.participant ||
            message.participant ||
            message.key?.senderPn ||
            '';
    } else {
        sender =
            message.key?.participant ||
            message.participant ||
            remoteJid ||
            '';
    }

    return String(sender)
        .split(':')[0]
        .split('@')[0]
        .replace(/\D/g, '');
}

// ======================================================
// 🔐 المالك فقط
// ======================================================

function isOwner(message) {
    return isElite(getSenderNumber(message));
}

// ======================================================
// ✂️ اختصار ونظام تنسيق الناتج
// ======================================================

function formatOutput(text) {
    text = String(text || '').trim();

    if (!text) {
        return 'لا يوجد ناتج.';
    }

    if (text.length > MAX_OUTPUT) {
        return (
            text.slice(0, MAX_OUTPUT) +
            '\n\n... تم اختصار الناتج لتجاوزه الحد المسموح.'
        );
    }

    return text;
}

// ======================================================
// 📌 الرسالة التوضيحية
// ======================================================

function helpText() {
    return (
        `🖥️ *Full Terminal Manager*\n\n` +
        `🔐 المالك فقط\n\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `📌 الاستخدام:\n` +
        `أرسل الأمر المباشر بعد الكلمة المفتاحية، مثال:\n\n` +
        `• \`.تيرمنال ls -la\`\n` +
        `• \`.تيرمنال pm2 status\`\n` +
        `• \`.تيرمنال git pull\`\n` +
        `• \`.تيرمنال cat package.json\`\n` +
        `• \`.تيرمنال free -m\`\n` +
        `━━━━━━━━━━━━━━━━━━`
    );
}

// ======================================================
// 🚀 التنفيذ الرئيسي
// ======================================================

async function execute(sock, message) {
    const chatId = message.key?.remoteJid;

    // ==================================================
    // 🔐 المالك فقط
    // ==================================================

    if (!isOwner(message)) {
        await sock.sendMessage(chatId, {
            text: '❌ هذا الأمر مخصص لمالك البوت فقط.'
        }, { quoted: message });
        return;
    }

    // ==================================================
    // 📝 استخراج النص الكامل للأمر
    // ==================================================

    let rawText = '';

    if (message.args && message.args.length > 0) {
        rawText = message.args.join(' ');
    } else {
        const body =
            message.message?.conversation ||
            message.message?.extendedTextMessage?.text ||
            '';
        rawText = body.replace(/^\.تيرمنال\s*/i, '').trim();
    }

    // ==================================================
    // 📖 بدون أمر
    // ==================================================

    if (!rawText) {
        await sock.sendMessage(chatId, {
            text: helpText()
        }, { quoted: message });
        return;
    }

    // ==================================================
    // ⏳ تشغيل الأمر الحرة (Shell Execution)
    // ==================================================

    const waitingMsg = await sock.sendMessage(chatId, {
        text: `⏳ جاري تنفيذ الأمر:\n\`${rawText}\``
    }, { quoted: message });

    try {
        const result = await execAsync(rawText, {
            timeout: COMMAND_TIMEOUT,
            maxBuffer: 1024 * 1024 * 10, // 10MB
            windowsHide: true
        });

        const stdout = formatOutput(result.stdout);
        const stderr = formatOutput(result.stderr);

        let output =
            `🖥️ *Terminal Output*\n\n` +
            `📌 الأمر: \`${rawText}\`\n` +
            `━━━━━━━━━━━━━━━━━━\n`;

        if (result.stdout?.trim()) {
            output +=
                `📤 الناتج:\n` +
                `\`\`\`\n` +
                `${stdout}\n` +
                `\`\`\`\n`;
        }

        if (result.stderr?.trim()) {
            output +=
                `\n⚠️ الأخطاء / الملاحظات:\n` +
                `\`\`\`\n` +
                `${stderr}\n` +
                `\`\`\`\n`;
        }

        if (!result.stdout?.trim() && !result.stderr?.trim()) {
            output += `\n✅ تم تنفيذ الأمر بنجاح بدون مخرجات.\n`;
        }

        await sock.sendMessage(chatId, { text: output }, { quoted: message });

    } catch (error) {
        let errorText = error?.message || 'حدث خطأ غير معروف.';

        if (error?.killed || error?.code === 'ETIMEDOUT') {
            errorText = '⏱️ انتهت مهلة تنفيذ الأمر (تجاوز 30 ثانية).';
        } else if (error?.stderr) {
            errorText = error.stderr.trim();
        }

        await sock.sendMessage(chatId, {
            text:
                `❌ فشل تنفيذ الأمر.\n\n` +
                `📌 الأمر: \`${rawText}\`\n` +
                `━━━━━━━━━━━━━━━━━━\n` +
                `⚠️ الخطأ:\n` +
                `\`\`\`\n` +
                `${formatOutput(errorText)}\n` +
                `\`\`\``
        }, { quoted: message });
    }
}

// ======================================================
// 📦 التصدير
// ======================================================

module.exports = {
    command: 'تيرمنال',
    description: 'تيرمنال كامل للتحكم بالسيرفر للمالك فقط.',
    emoji: '🧑‍💻',
    usage: '.تيرمنال [الأمر كامل مع الخيارات]',
    owner: true,
    execute
};
