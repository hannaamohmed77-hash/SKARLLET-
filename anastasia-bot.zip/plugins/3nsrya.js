const { isElite } = require('../haykala/elite.js');
const { jidDecode } = require('@whiskeysockets/baileys');

const getNumber = (jid) => {
  const decoded = jidDecode(jid);
  return decoded?.user || jid.split('@')[0];
};

// قائمة مفاتيح جميع دول الوطن العربي
const ARAB_COUNTRY_CODES = [
  '20',  // مصر
  '966', // السعودية
  '971', // الإمارات
  '965', // الكويت
  '974', // قطر
  '968', // عمان
  '973', // البحرين
  '962', // الأردن
  '961', // لبنان
  '963', // سوريا
  '964', // العراق
  '970', // فلسطين
  '972', // فلسطين (استخدام أرقام بعض الشبكات)
  '967', // اليمن
  '218', // ليبيا
  '216', // تونس
  '213', // الجزائر
  '212', // المغرب
  '249', // السودان
  '252', // الصومال
  '253', // جيبوتي
  '269', // جزر القمر
  '222'  // موريتانيا
];

module.exports = {
  command: 'عنصرية',
  description: 'طرد أعضاء حسب مفتاح الدولة أو طرد الأرقام الأجنبية من خارج الوطن العربي',
  usage: '.عنصرية +20 | .عنصرية اجنبي | .عنصرية نسبة',
emoji: '🚫',
  async execute(sock, msg) {
    try {
      const jid = msg.key.remoteJid;
      const senderJid = msg.key.participant || msg.key.remoteJid;
      const senderNumber = getNumber(senderJid);

      if (!jid.endsWith('@g.us')) {
        return await sock.sendMessage(jid, { text: '❌ هذا الأمر يعمل فقط في المجموعات.' }, { quoted: msg });
      }

      if (!isElite(senderNumber)) {
        return await sock.sendMessage(jid, { text: '❌ هذا الأمر مخصص للنخبة فقط.' }, { quoted: msg });
      }

      const meta = await sock.groupMetadata(jid);
      const participants = meta.participants;
      const admins = participants.filter(p => p.admin).map(p => p.id);

      const validMembers = participants.filter(p => p.id).map(p => ({
        id: p.id,
        number: getNumber(p.id)
      })).filter(m => /^\d+$/.test(m.number));

      const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
      const lower = body.toLowerCase().trim();

      // 1. عرض نسبة الدول بالمجموعة
      if (lower.includes('نسبة')) {
        const countryCounts = {};

        for (const member of validMembers) {
          // مطابقة أول 1 إلى 3 أرقام
          const matchCode = member.number.match(/^(\d{1,3})/);
          const prefix = matchCode ? matchCode[1] : 'أخرى';
          countryCounts[prefix] = (countryCounts[prefix] || 0) + 1;
        }

        const total = validMembers.length;
        const sorted = Object.entries(countryCounts).sort((a, b) => b[1] - a[1]).slice(0, 10);

        if (sorted.length === 0) {
          return sock.sendMessage(jid, { text: '❌ لا يوجد أعضاء يمكن تحليل أرقامهم حالياً.' }, { quoted: msg });
        }

        let message = '*📊 توزيع رموز الدول في المجموعة:*\n\n';
        for (const [prefix, count] of sorted) {
          const percentage = ((count / total) * 100).toFixed(1);
          message += `• +${prefix} = ${count} عضو (${percentage}%)\n`;
        }

        message += `\nخيارات الأمر:\n• .عنصرية +20 (لطرد مفتاح معين)\n• .عنصرية اجنبي (لطرد كل من هم خارج الوطن العربي)`;
        return sock.sendMessage(jid, { text: message }, { quoted: msg });
      }

      let toKick = [];
      let targetLabel = '';

      // 2. خيار طرد الأرقام الأجنبية (خارج الوطن العربي)
      if (lower.includes('اجنبي') || lower.includes('أجنبي') || lower.includes('خارج')) {
        targetLabel = 'الأرقام الأجنبية (خارج الوطن العربي)';
        toKick = validMembers.filter(p => {
          const isArab = ARAB_COUNTRY_CODES.some(code => p.number.startsWith(code));
          return !isArab &&
            p.number !== senderNumber &&
            !admins.includes(p.id) &&
            !isElite(p.number);
        });
      } 
      // 3. خيار طرد كود دولة محدد (مثل +20 أو 20)
      else {
        const match = lower.match(/\+?(\d{1,4})/);
        if (!match) {
          return sock.sendMessage(jid, {
            text: '❗ يرجى استخدام الأمر بهذا الشكل:\n• .عنصرية +20\n• .عنصرية اجنبي\n• .عنصرية نسبة'
          }, { quoted: msg });
        }

        const code = match[1];
        targetLabel = `+${code}`;
        toKick = validMembers.filter(p =>
          p.number.startsWith(code) &&
          p.number !== senderNumber &&
          !admins.includes(p.id) &&
          !isElite(p.number)
        );
      }

      // تنفيذ عملية الطرد
      if (toKick.length > 0) {
        const ids = toKick.map(p => p.id);
        
        // تنفيذ الطرد على دفعة واحدة
        await sock.groupParticipantsUpdate(jid, ids, 'remove');
        
        return sock.sendMessage(jid, {
          text: `✅ تم طرد ${toKick.length} عضو بنجاح من فئة (${targetLabel}).`
        }, { quoted: msg });
      } else {
        return sock.sendMessage(jid, {
          text: `❌ لم يتم العثور على أعضاء ينطبق عليهم الشرط (${targetLabel}) لطردهم.`
        }, { quoted: msg });
      }

    } catch (error) {
      console.error('❌ خطأ في تنفيذ الأمر:', error);
      await sock.sendMessage(msg.key.remoteJid, {
        text: '❌ حدث خطأ أثناء تنفيذ الأمر.'
      }, { quoted: msg });
    }
  }
};
