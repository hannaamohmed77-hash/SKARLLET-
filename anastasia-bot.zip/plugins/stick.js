const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const { execFile } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

module.exports = {
  command: 'ملصق',
    emoji: '🖼️',

  async execute(sock, m) {
    const chatId = m.key.remoteJid;

    // ==============================
    // ملفات مؤقتة بأسماء عشوائية
    // ==============================

    const id = crypto.randomBytes(6).toString('hex');

    const inputPath = path.join(process.cwd(), `sticker-input-${id}`);
    const outputPath = path.join(process.cwd(), `sticker-output-${id}.webp`);

    try {
      const contextInfo =
        m.message?.extendedTextMessage?.contextInfo;

      if (!contextInfo?.quotedMessage) {
        return await sock.sendMessage(
          chatId,
          {
            text: '⚠️ قم بالرد على صورة أو فيديو باستخدام أمر «ملصق».'
          },
          { quoted: m }
        );
      }

      const quoted = contextInfo.quotedMessage;

      const imageMessage = quoted.imageMessage;
      const videoMessage = quoted.videoMessage;

      // ==============================
      // تحديد نوع الوسائط
      // ==============================

      if (!imageMessage && !videoMessage) {
        return await sock.sendMessage(
          chatId,
          {
            text: '⚠️ يجب الرد على صورة أو فيديو فقط.'
          },
          { quoted: m }
        );
      }

      // ==============================
      // تحميل الصورة
      // ==============================

      if (imageMessage) {
        const stream = await downloadContentFromMessage(
          imageMessage,
          'image'
        );

        const chunks = [];

        for await (const chunk of stream) {
          chunks.push(chunk);
        }

        const buffer = Buffer.concat(chunks);

        if (!buffer.length) {
          throw new Error('فشل تحميل الصورة');
        }

        const input = `${inputPath}.jpg`;

        fs.writeFileSync(input, buffer);

        // ==========================================
        // الصورة:
        // crop من المنتصف بدون أي حواف سوداء
        // ثم 512x512
        // ==========================================

        await runFFmpeg([
          '-y',
          '-i',
          input,

          '-vf',
          'crop=min(iw\\,ih):min(iw\\,ih):(iw-min(iw\\,ih))/2:(ih-min(iw\\,ih))/2,scale=512:512:flags=lanczos',

          '-frames:v',
          '1',

          '-c:v',
          'libwebp',

          '-quality',
          '100',

          '-compression_level',
          '6',

          outputPath
        ]);

        fs.unlinkSync(input);
      }

      // ==============================
      // تحميل الفيديو
      // ==============================

      else if (videoMessage) {
        const stream = await downloadContentFromMessage(
          videoMessage,
          'video'
        );

        const chunks = [];

        for await (const chunk of stream) {
          chunks.push(chunk);
        }

        const buffer = Buffer.concat(chunks);

        if (!buffer.length) {
          throw new Error('فشل تحميل الفيديو');
        }

        const input = `${inputPath}.mp4`;

        fs.writeFileSync(input, buffer);

        // ==========================================
        // الفيديو:
        // - أول 10 ثواني فقط
        // - crop مربع من المنتصف
        // - 512x512
        // - WebP متحرك
        // ==========================================

        await runFFmpeg([
          '-y',

          '-i',
          input,

          '-t',
          '10',

          '-vf',
          'crop=min(iw\\,ih):min(iw\\,ih):(iw-min(iw\\,ih))/2:(ih-min(iw\\,ih))/2,scale=512:512:flags=lanczos,fps=15',

          '-an',

          '-c:v',
          'libwebp',

          '-lossless',
          '0',

          '-quality',
          '80',

          '-compression_level',
          '4',

          '-loop',
          '0',

          outputPath
        ]);

        fs.unlinkSync(input);
      }

      // ==============================
      // التأكد من وجود الناتج
      // ==============================

      if (!fs.existsSync(outputPath)) {
        throw new Error('لم يتم إنشاء الملصق');
      }

      const webpBuffer = fs.readFileSync(outputPath);

      if (!webpBuffer.length) {
        throw new Error('الملصق الناتج فارغ');
      }

      // ==============================
      // إرسال الملصق
      // ==============================

      await sock.sendMessage(
        chatId,
        {
          sticker: webpBuffer
        },
        { quoted: m }
      );

    } catch (error) {
      console.error('❌ خطأ في أمر الملصق:', error);

      await sock.sendMessage(
        chatId,
        {
          text:
            '❌ حدث خطأ أثناء تحويل الوسائط إلى ملصق.\n\n' +
            'تأكد أن FFmpeg مثبت على السيرفر.'
        },
        { quoted: m }
      );

    } finally {

      

      const possibleFiles = [
        inputPath,
        `${inputPath}.jpg`,
        `${inputPath}.mp4`,
        outputPath
      ];

      for (const file of possibleFiles) {
        try {
          if (fs.existsSync(file)) {
            fs.unlinkSync(file);
          }
        } catch (e) {
          console.error('Cleanup error:', e.message);
        }
      }
    }
  }
};


// ==========================================
// تشغيل FFmpeg بأمان
// ==========================================

function runFFmpeg(args) {
  return new Promise((resolve, reject) => {

    execFile(
      'ffmpeg',
      args,
      {
        maxBuffer: 1024 * 1024 * 10
      },
      (error, stdout, stderr) => {

        if (error) {
          console.error('FFmpeg:', stderr);
          reject(error);
          return;
        }

        resolve();
      }
    );
  });
}