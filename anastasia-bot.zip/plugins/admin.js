const {
    isElite
} = require('../haykala/elite');

const {
    areJidsSameUser
} = require('@whiskeysockets/baileys');

// ==========================================
// الحصول على صاحب الرسالة
// ==========================================

function getSender(msg) {

    return (
        msg.key?.participant ||
        msg.participant ||
        msg.key?.remoteJid ||
        null
    );
}

// ==========================================
// مقارنة JID بشكل آمن
// يدعم @s.whatsapp.net و @lid
// ==========================================

function sameUser(jid1, jid2) {

    if (!jid1 || !jid2) {
        return false;
    }

    try {

        if (jid1 === jid2) {
            return true;
        }

        return areJidsSameUser(
            jid1,
            jid2
        );

    } catch {

        return false;
    }
}

// ==========================================
// استخراج الهدف
// ==========================================

function getTarget(
    msg,
    args,
    sender
) {

    const context =
        msg.message?.extendedTextMessage
            ?.contextInfo;

    // ======================================
    // المنشن
    // ======================================

    const mentioned =
        context?.mentionedJid?.[0];

    if (mentioned) {
        return mentioned;
    }

    // ======================================
    // الرد على شخص
    // ======================================

    const replied =
        context?.participant;

    if (replied) {
        return replied;
    }

    // ======================================
    // رقم مكتوب
    // ======================================

    if (args?.[0]) {

        const number =
            String(args[0])
                .replace(/\D/g, '');

        if (number) {

            return (
                number +
                '@s.whatsapp.net'
            );
        }
    }

    // ======================================
    // بدون هدف = المرسل
    // ======================================

    return sender;
}

// ==========================================
// الأمر
// ==========================================

module.exports = {

    command: 'ادمن',

    category: 'admin',

    emoji: '👑',
    
    description:
        'ترقية عضو إلى مشرف في المجموعة — للنخبة فقط.',

    usage:
        '.ادمن\n' +
        '.ادمن @منشن\n' +
        'بالرد: .ادمن\n' +
        '.ادمن 201xxxxxxxxx',

    async execute(
        sock,
        msg,
        args = []
    ) {

        const chatId =
            msg.key.remoteJid;

        try {

            // ==================================
            // التأكد من المجموعة
            // ==================================

            if (
                !chatId ||
                !chatId.endsWith('@g.us')
            ) {

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ هذا الأمر يعمل داخل المجموعات فقط.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================
            // صاحب الأمر
            // ==================================

            const sender =
                getSender(msg);

            if (!sender) {

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ تعذر تحديد صاحب الأمر.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================
            // النخبة
            // ==================================

            if (
                !isElite(sender)
            ) {

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ هذا الأمر متاح للنخبة فقط.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================
            // بيانات المجموعة
            // ==================================

            const metadata =
                await sock.groupMetadata(
                    chatId
                );

            const participants =
                metadata.participants || [];

            // ==================================
            // هويات البوت
            //
            // في الإصدارات الحديثة ممكن يكون
            // البوت عنده id عادي + lid
            // ==================================

            const botIds = [];

            if (sock.user?.id) {
                botIds.push(
                    sock.user.id
                );
            }

            if (sock.user?.lid) {
                botIds.push(
                    sock.user.lid
                );
            }

            // ==================================
            // البحث عن البوت داخل المجموعة
            // ==================================

            const botParticipant =
                participants.find(
                    participant => {

                        if (!participant?.id) {
                            return false;
                        }

                        return botIds.some(
                            botId =>
                                sameUser(
                                    participant.id,
                                    botId
                                )
                        );
                    }
                );

            // ==================================
            // فحص إضافي بالـ LID
            // ==================================

            let botIsAdmin =
                botParticipant?.admin === 'admin' ||
                botParticipant?.admin === 'superadmin';

            // ==================================
            // لو لم يجد البوت، نحاول مقارنة
            // الـ id مباشرة
            // ==================================

            if (!botIsAdmin) {

                const directBot =
                    participants.find(
                        p =>
                            botIds.includes(
                                p.id
                            )
                    );

                if (directBot) {

                    botIsAdmin =
                        directBot.admin === 'admin' ||
                        directBot.admin === 'superadmin';
                }
            }

            // ==================================
            // البوت مشرف؟
            // ==================================

            if (!botIsAdmin) {

                console.log(
                    '⚠️ تعذر تحديد صلاحية البوت.'
                );

                console.log(
                    '🤖 sock.user.id:',
                    sock.user?.id
                );

                console.log(
                    '🤖 sock.user.lid:',
                    sock.user?.lid
                );

                console.log(
                    '👥 أعضاء المجموعة:',
                    participants.map(
                        p => ({
                            id: p.id,
                            admin: p.admin
                        })
                    )
                );

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ لم أتمكن من التحقق من أني مشرف في المجموعة.\n\n' +
                            'تأكد أن البوت مشرف ثم جرّب الأمر مرة أخرى.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================
            // تحديد العضو المستهدف
            // ==================================

            const target =
                getTarget(
                    msg,
                    args,
                    sender
                );

            if (!target) {

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ لم أتمكن من تحديد العضو.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================
            // البحث عن العضو
            // ==================================

            let targetParticipant =
                participants.find(
                    p =>
                        p.id === target
                );

            // ==================================
            // محاولة مقارنة JID
            // ==================================

            if (!targetParticipant) {

                targetParticipant =
                    participants.find(
                        p =>
                            sameUser(
                                p.id,
                                target
                            )
                    );
            }

            // ==================================
            // العضو غير موجود
            // ==================================

            if (!targetParticipant) {

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ العضو غير موجود في المجموعة.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            const targetJid =
                targetParticipant.id;

            // ==================================
            // منع ترقية البوت نفسه
            // ==================================

            const isBot =
                botIds.some(
                    botId =>
                        sameUser(
                            targetJid,
                            botId
                        )
                );

            if (isBot) {

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '🤖 أنا مشرف بالفعل، لا يمكن ترقيتي مرة أخرى.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================
            // هل العضو مشرف بالفعل؟
            // ==================================

            const alreadyAdmin =
                targetParticipant.admin === 'admin' ||
                targetParticipant.admin === 'superadmin';

            if (alreadyAdmin) {

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            `ℹ️ @${targetJid.split('@')[0]} مشرف بالفعل.`,
                        mentions: [
                            targetJid
                        ]
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==================================
            // تنفيذ الترقية
            // ==================================

            await sock.groupParticipantsUpdate(
                chatId,
                [targetJid],
                'promote'
            );

            // ==================================
            // رسالة النجاح
            // ==================================

            return await sock.sendMessage(
                chatId,
                {
                    text:
                        `👑 تم ترقية @${targetJid.split('@')[0]} إلى مشرف بنجاح.`,
                    mentions: [
                        targetJid
                    ]
                },
                {
                    quoted: msg
                }
            );

        } catch (error) {

            console.error(
                '❌ خطأ في أمر ادمن:',
                error
            );

            let errorMessage =
                '❌ فشل تنفيذ أمر الترقية.';

            const reason =
                String(
                    error?.message || ''
                ).toLowerCase();

            if (
                reason.includes('forbidden') ||
                reason.includes('not-authorized') ||
                reason.includes('not authorized') ||
                reason.includes('unauthorized')
            ) {

                errorMessage =
                    '❌ واتساب رفض عملية الترقية.\n' +
                    'تأكد أن البوت مشرف ولديه صلاحية إدارة المجموعة.';

            } else if (
                reason.includes('not in group')
            ) {

                errorMessage =
                    '❌ العضو لم يعد موجودًا في المجموعة.';

            } else if (
                error?.message
            ) {

                errorMessage +=
                    `\n\n📌 ${error.message}`;
            }

            try {

                await sock.sendMessage(
                    chatId,
                    {
                        text:
                            errorMessage
                    },
                    {
                        quoted: msg
                    }
                );

            } catch {}
        }
    }
};