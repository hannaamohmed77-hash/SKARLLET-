const contactProtection =
    require('../lib/contactProtection');

const groupMonitor =
    require('../lib/groupMonitor');

module.exports = {

    command: 'دارك',
    category: 'tools',
    emoji: '🛡️',

    async execute(sock, msg) {

        const chatId =
            msg?.key?.remoteJid;

        try {

            // ==================================================
            // لازم يكون الأمر داخل مجموعة
            // ==================================================

            if (
                !chatId ||
                !chatId.endsWith('@g.us')
            ) {

                await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ أمر دارك يعمل داخل المجموعات فقط.'
                    }
                );

                return;
            }

            // ==================================================
            // 🛡️ تفعيل حماية جهات الاتصال
            // ==================================================

            contactProtection.enable();

            // ==================================================
            // 👁️ تفعيل المراقب للمجموعة الحالية
            // ==================================================

            await groupMonitor.enable(
                chatId
            );

            // ==================================================
            // ✅ رسالة التفعيل
            // ==================================================

            await sock.sendMessage(
                chatId,
                {
                    text:
                        '🛡️ تم تفعيل الحماية\n\n' +
                        '📱 حماية جهات الاتصال: 🟢\n' +
                        '👁️ مراقبة تغييرات الأعضاء: 🟢'
                }
            );

        } catch (error) {

            console.error(
                '❌ خطأ في أمر دارك:',
                error
            );

            await sock.sendMessage(
                chatId,
                {
                    text:
                        '❌ حصل خطأ أثناء تفعيل الحماية.'
                }
            );

        }

    }

};