const axios = require('axios');
const cheerio = require('cheerio');

// ======================================================
// 🥳 أمر الترحيب
// بدون sharp - مناسب لتيرمكس / Android
// ======================================================

const PINTEREST_SEARCH =
    'https://www.pinterest.com/search/pins/?q=';

// ======================================================
// استخراج نص الرسالة
// ======================================================

function getText(msg) {
    return (
        msg.message?.conversation ||
        msg.message?.extendedTextMessage?.text ||
        msg.message?.imageMessage?.caption ||
        msg.message?.videoMessage?.caption ||
        msg.message?.documentMessage?.caption ||
        ''
    );
}

// ======================================================
// التحقق من المجموعة
// ======================================================

function isGroup(msg) {
    return Boolean(
        msg.key?.remoteJid?.endsWith('@g.us')
    );
}

// ======================================================
// استخراج المنشن الحقيقي
// ======================================================

function getMentionedJid(msg) {

    const context =
        msg.message
            ?.extendedTextMessage
            ?.contextInfo;

    const mentioned =
        context?.mentionedJid;

    if (
        Array.isArray(mentioned) &&
        mentioned.length
    ) {
        return mentioned[0];
    }

    return null;
}

// ======================================================
// استخراج رقم للعرض فقط
// لا نستخدمه في mentions
// ======================================================

function getDisplayNumber(jid) {

    if (!jid) {
        return '';
    }

    const value =
        String(jid)
            .split('@')[0]
            .split(':')[0]
            .replace(/\D/g, '');

    return value;
}

// ======================================================
// تحويل رابط Pinterest المصغر إلى Originals
// ======================================================

function getOriginalPinterestUrl(url) {

    if (
        typeof url !== 'string'
    ) {
        return url;
    }

    let original =
        url
            .replace(/\\u002F/g, '/')
            .replace(/\\\//g, '/')
            .replace(/&amp;/g, '&');

    if (
        original.includes('i.pinimg.com')
    ) {

        original =
            original.replace(
                /\/(?:60x60|170x|236x|474x|564x|736x|1200x)\//i,
                '/originals/'
            );

    }

    return original;
}

// ======================================================
// استخراج روابط الصور
// ======================================================

function extractImageUrls(html) {

    const urls = new Set();

    function addUrl(value) {

        if (!value) {
            return;
        }

        let url =
            String(value)
                .replace(/\\u002F/g, '/')
                .replace(/\\\//g, '/')
                .replace(/&amp;/g, '&')
                .trim();

        if (
            !/^https?:\/\//i.test(url)
        ) {
            return;
        }

        if (
            /\/(?:60x60|170x|236x)\//i.test(url)
        ) {
            return;
        }

        urls.add(url);
    }

    const $ =
        cheerio.load(html);

    // ==================================================
    // صور HTML
    // ==================================================

    $('img').each((_, element) => {

        addUrl(
            $(element).attr('src')
        );

        addUrl(
            $(element).attr('data-src')
        );

        addUrl(
            $(element).attr('data-lazy-src')
        );

        const srcset =
            $(element).attr('srcset');

        if (srcset) {

            srcset
                .split(',')
                .forEach(item => {

                    const url =
                        item
                            .trim()
                            .split(/\s+/)[0];

                    addUrl(url);
                });
        }

    });

    // ==================================================
    // JSON / HTML
    // ==================================================

    const regex =
        /https?:\\?\/\\?\/[^"'<>\\\s]+/gi;

    const matches =
        html.match(regex) || [];

    for (const match of matches) {

        const url =
            match
                .replace(/\\u002F/g, '/')
                .replace(/\\\//g, '/')
                .replace(/\\u0026/g, '&');

        if (
            /(?:jpg|jpeg|png|webp)(?:[?#&]|$)/i.test(
                url
            )
        ) {
            addUrl(url);
        }
    }

    // ==================================================
    // ترتيب الصور
    // ==================================================

    return [...urls].sort((a, b) => {

        let scoreA = 0;
        let scoreB = 0;

        if (
            /i\.pinimg\.com/i.test(a)
        ) {
            scoreA += 100;
        }

        if (
            /i\.pinimg\.com/i.test(b)
        ) {
            scoreB += 100;
        }

        if (
            /\/originals\//i.test(a)
        ) {
            scoreA += 1000;
        }

        if (
            /\/originals\//i.test(b)
        ) {
            scoreB += 1000;
        }

        return scoreB - scoreA;
    });
}

// ======================================================
// تحميل الصورة
// ======================================================

async function downloadImage(url) {

    try {

        const response =
            await axios.get(
                url,
                {
                    responseType:
                        'arraybuffer',

                    timeout:
                        15000,

                    maxContentLength:
                        30 * 1024 * 1024,

                    maxBodyLength:
                        30 * 1024 * 1024,

                    headers: {

                        'User-Agent':
                            'Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/131.0 Mobile Safari/537.36',

                        'Accept':
                            'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',

                        'Referer':
                            'https://www.pinterest.com/'
                    }
                }
            );

        if (
            !response.data ||
            response.data.length < 5000
        ) {
            return null;
        }

        return Buffer.from(
            response.data
        );

    } catch (error) {

        return null;
    }
}

// ======================================================
// البحث عن صورة Pinterest
// ======================================================

async function searchPinterestImage(query) {

    try {

        console.log(
            `🔎 Pinterest Search: ${query}`
        );

        const searchUrl =
            PINTEREST_SEARCH +
            encodeURIComponent(query);

        const response =
            await axios.get(
                searchUrl,
                {
                    timeout:
                        20000,

                    maxContentLength:
                        20 * 1024 * 1024,

                    headers: {

                        'User-Agent':
                            'Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/131.0 Mobile Safari/537.36',

                        'Accept':
                            'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',

                        'Accept-Language':
                            'en-US,en;q=0.9',

                        'Referer':
                            'https://www.google.com/'
                    }
                }
            );

        const urls =
            extractImageUrls(
                String(response.data)
            );

        console.log(
            `📸 تم العثور على ${urls.length} رابط صورة`
        );

        if (!urls.length) {
            return null;
        }

        const candidates = [];

        for (
            const url of urls.slice(0, 15)
        ) {

            const original =
                getOriginalPinterestUrl(
                    url
                );

            if (
                original &&
                !candidates.includes(original)
            ) {
                candidates.push(original);
            }

            if (
                !candidates.includes(url)
            ) {
                candidates.push(url);
            }
        }

        for (
            const url of candidates.slice(0, 20)
        ) {

            const buffer =
                await downloadImage(url);

            if (
                buffer &&
                buffer.length > 5000
            ) {

                console.log(
                    `✅ تم تحميل الصورة بحجم ${
                        Math.round(
                            buffer.length / 1024
                        )
                    } KB`
                );

                return buffer;
            }
        }

        return null;

    } catch (error) {

        console.log(
            `⚠️ Pinterest Search فشل: ${
                error?.message || error
            }`
        );

        return null;
    }
}

// ======================================================
// 🎯 Plugin الرئيسي
// ======================================================

module.exports = {

    command: 'ترحيب',

    description:
        'إرسال استمارة ترحيب بصورة عالية الجودة من Pinterest',

    category: 'group',

    emoji: '👋🏻',

    async execute(sock, msg) {

        const chatId =
            msg.key?.remoteJid;

        if (!chatId) {
            return;
        }

        try {

            // ==================================================
            // المجموعة
            // ==================================================

            if (!isGroup(msg)) {

                await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ هذا الأمر يعمل داخل المجموعات فقط.'
                    },
                    {
                        quoted: msg
                    }
                );

                return;
            }

            // ==================================================
            // قراءة الرسالة
            // ==================================================

            const text =
                getText(msg).trim();

            const parts =
                text.split(/\s+/);

            if (
                parts.length < 2
            ) {

                await sock.sendMessage(
                    chatId,
                    {
                        text:
`❌ الاستخدام الصحيح:

.ترحيب اسم_الشخصية @العضو

مثال:

.ترحيب توجي @فلان
.ترحيب غوجو @فلان
.ترحيب نيزكو @فلان`
                    },
                    {
                        quoted: msg
                    }
                );

                return;
            }

            // ==================================================
            // اسم الشخصية
            // ==================================================

            const characterName =
                parts[1];

            // ==================================================
            // المنشن الحقيقي
            // ==================================================

            const mentionedJid =
                getMentionedJid(msg);

            if (!mentionedJid) {

                await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ لازم تعمل منشن للشخص.'
                    },
                    {
                        quoted: msg
                    }
                );

                return;
            }

            // ==================================================
            // مهم جدًا:
            // لا نعدل الـJID
            // نرسله كما أعاده واتساب
            // ==================================================

            const mentionJid =
                String(
                    mentionedJid
                );

            const displayNumber =
                getDisplayNumber(
                    mentionJid
                );

            // ==================================================
            // البحث عن الصورة
            // ==================================================

            const imageBuffer =
                await searchPinterestImage(
                    characterName
                );

            // ==================================================
            // نص الترحيب - فاين 🎹
            // ==================================================

            const welcomeText =
`*❈║══─╵🎹╷─══║❈*

*نورتنا ✨*

*اهلا بك نتمنى ان تستمتع بوقتك و ان تقضي افضل ايامك و نتشرف بمعرفتك في فاين 🎹*

*❈║══─╵🎹╷─══║❈*

*↵⭐┊اللقب ❰ ${characterName} ❱*
*↵📧┊المنشن ❰ @${displayNumber} ❱*

*❈║══─╵🎹╷─══║❈*

*نرجو منك دخول رابط الإعلانات📍*

*〄الإعـلانـات🔊⬃*
*『 https://chat.whatsapp.com/D0uut2ei5ez7iaAWR5G646 』*

*❈║══─╷🎹╷─══║❈*

*⸙ تـوقـ🖊️ـيـع⤦*
*『𝑲.𝑵.𝑯⊰🎹⊱𝑽𝑰𝑨𝑵』🝳_*`;

            // ==================================================
            // إرسال الصورة والمنشن
            // ==================================================

            if (imageBuffer) {

                await sock.sendMessage(
                    chatId,
                    {
                        image:
                            imageBuffer,

                        caption:
                            welcomeText,

                        // ⭐ الـJID الأصلي بدون تعديل
                        mentions: [
                            mentionJid
                        ]
                    },
                    {
                        quoted: msg
                    }
                );

            } else {

                await sock.sendMessage(
                    chatId,
                    {
                        text:
                            welcomeText,

                        // ⭐ الـJID الأصلي بدون تعديل
                        mentions: [
                            mentionJid
                        ]
                    },
                    {
                        quoted: msg
                    }
                );
            }

            console.log(
                `✓ تم تنفيذ الترحيب للعضو: ${mentionJid}`
            );

        } catch (error) {

            console.error(
                '❌ خطأ في أمر ترحيب:',
                error?.stack || error
            );

            await sock.sendMessage(
                chatId,
                {
                    text:
                        '❌ حصل خطأ أثناء إنشاء استمارة الترحيب.'
                },
                {
                    quoted: msg
                }
            ).catch(() => {});
        }
    }
};