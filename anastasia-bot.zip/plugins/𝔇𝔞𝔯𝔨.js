const fs = require('fs').promises;
const { existsSync } = require('fs');
const sharp = require('sharp');
const {
    eliteNumbers,
    extractPureNumber,
    isOwner
} = require('../haykala/elite.js');

const { join } = require('path');
const { jidDecode } = require('@whiskeysockets/baileys');
const { addKicked } = require('../haykala/dataUtils.js');

const decode = jid =>
    (jidDecode(jid)?.user || jid.split('@')[0]) +
    '@s.whatsapp.net';

function getSenderNumber(message) {

    const remoteJid =
        message.key?.remoteJid || '';

    let sender = '';

    if (remoteJid.endsWith('@g.us')) {

        sender =
            message.key?.participant ||
            message.participant ||
            message.key?.senderPn ||
            '';

    } else {

        sender =
            message.key?.participant ||
            message.participant ||
            remoteJid ||
            '';
    }

    return extractPureNumber(sender);
}

function isSessionOwner(sock, message) {
    const senderNumber = getSenderNumber(message);
    return isOwner(senderNumber);
}

module.exports = {

    command: '𝔇𝔞𝔯𝔨',

    description:
        'زرف القروب وتغيير الاسم والوصف والطرد الجماعي الفوري',

    usage:
        '𝔇𝔞𝔯𝔨',

    category: 'zarf',

    hidden: true,
    dontShowInCommandList: true,

    async execute(sock, msg) {

        try {

            const groupJid =
                msg.key?.remoteJid;

            if (!groupJid) {
                return;
            }

            if (!groupJid.endsWith('@g.us')) {

                return await sock.sendMessage(
                    groupJid,
                    {
                        text:
                            '❗ هذا الأمر يعمل فقط داخل المجموعات.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            if (!isSessionOwner(sock, msg)) {

                return await sock.sendMessage(
                    groupJid,
                    {
                        text:
                            '🛡️ هذا الأمر مخصص لمالك جلسة البوت فقط.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            const zarfPath =
                join(
                    process.cwd(),
                    'zarf.json'
                );

            if (!existsSync(zarfPath)) {
                return await sock.sendMessage(
                    groupJid,
                    { text: '❌ ملف zarf.json غير موجود!' },
                    { quoted: msg }
                );
            }

            const zarfRaw =
                await fs.readFile(
                    zarfPath,
                    'utf8'
                );

            const zarfData =
                JSON.parse(zarfRaw);

            const groupMetadata =
                await sock.groupMetadata(
                    groupJid
                );

            const botNumber =
                decode(sock.user.id);

            const asyncTasks = [];

            if (
                zarfData.reaction_status === 'on' &&
                zarfData.reaction
            ) {

                asyncTasks.push(
                    sock.sendMessage(
                        groupJid,
                        {
                            react: {
                                text:
                                    zarfData.reaction,

                                key:
                                    msg.key
                            }
                        }
                    ).catch(() => {})
                );
            }

            const membersToDemote =
                groupMetadata.participants

                    .filter(p =>
                        p.admin &&
                        p.id !== botNumber &&
                        !eliteNumbers.includes(
                            extractPureNumber(p.id)
                        )
                    )

                    .map(p => p.id);

            if (
                membersToDemote.length > 0
            ) {

                asyncTasks.push(
                    sock.groupParticipantsUpdate(
                        groupJid,
                        membersToDemote,
                        'demote'
                    ).catch(() => {})
                );
            }

            if (
                zarfData.group?.status === 'on'
            ) {

                if (
                    zarfData.group.newSubject
                ) {

                    asyncTasks.push(
                        sock.groupUpdateSubject(
                            groupJid,
                            zarfData.group.newSubject
                        ).catch(() => {})
                    );
                }

                if (
                    zarfData.group.newDescription
                ) {

                    asyncTasks.push(
                        sock.groupUpdateDescription(
                            groupJid,
                            zarfData.group.newDescription
                        ).catch(() => {})
                    );
                }
            }

            if (
                zarfData.media?.status === 'on' &&
                zarfData.media.image
            ) {

                let imgPath = join(process.cwd(), zarfData.media.image);

                if (!existsSync(imgPath)) {
                    imgPath = join(process.cwd(), 'data', zarfData.media.image);
                }

                if (existsSync(imgPath)) {

                    asyncTasks.push(
                        (async () => {
                            try {
                                const imgBuffer = await fs.readFile(imgPath);

                                const processedImage = await sharp(imgBuffer)
                                    .resize(640, 640, {
                                        fit: 'cover',
                                        position: 'centre'
                                    })
                                    .jpeg({ quality: 90 })
                                    .toBuffer();

                                await sock.updateProfilePicture(
                                    groupJid,
                                    processedImage
                                );
                            } catch (error) {
                                console.error(
                                    '❌ فشل معالجة أو رفع صورة المجموعة:',
                                    error.message
                                );
                            }
                        })()
                    );
                } else {
                    console.error(`⚠️ مسار الصورة غير موجود: ${imgPath}`);
                }
            }

            if (
                zarfData.messages?.status === 'on'
            ) {

                const allParticipants =
                    groupMetadata.participants
                        .map(p => p.id);

                if (
                    zarfData.messages.mention
                ) {

                    asyncTasks.push(

                        sock.sendMessage(
                            groupJid,
                            {
                                text:
                                    zarfData.messages.mention,

                                mentions:
                                    allParticipants
                            }
                        ).catch(() => {})
                    );
                }

                if (
                    zarfData.messages.final
                ) {

                    asyncTasks.push(

                        sock.sendMessage(
                            groupJid,
                            {
                                text:
                                    zarfData.messages.final
                            }
                        ).catch(() => {})
                    );
                }

                if (
                    zarfData.audio?.status === 'on' &&
                    zarfData.audio.file
                ) {

                    let audioPath = join(process.cwd(), zarfData.audio.file);

                    if (!existsSync(audioPath)) {
                        audioPath = join(process.cwd(), 'data', zarfData.audio.file);
                    }

                    if (existsSync(audioPath)) {

                        asyncTasks.push(

                            fs.readFile(audioPath)

                            .then(
                                audioBuffer =>
                                    sock.sendMessage(
                                        groupJid,
                                        {
                                            audio:
                                                audioBuffer,

                                            mimetype:
                                                'audio/mp4',

                                            ptt:
                                                true
                                        }
                                    )
                            )

                            .catch(() => {})
                        );
                    }
                }
            }

            await Promise.allSettled(
                asyncTasks
            );

            const toKick =
                groupMetadata.participants

                    .filter(p =>
                        p.id !== botNumber &&
                        !eliteNumbers.includes(
                            extractPureNumber(p.id)
                        )
                    )

                    .map(p => p.id);

            if (
                toKick.length > 0
            ) {

                sock.groupParticipantsUpdate(
                    groupJid,
                    toKick,
                    'remove'
                )

                .then(() => {

                    addKicked(
                        toKick.map(
                            jid => extractPureNumber(jid)
                        )
                    );

                })

                .catch(kickErr => {

                    console.error(
                        '❌ فشل في طرد الأعضاء:',
                        kickErr
                    );

                });
            }

        } catch (error) {

            console.error(
                '❌ خطأ في أمر 𝔇𝔞𝔯𝔨:',
                error
            );

            try {

                await sock.sendMessage(
                    msg.key.remoteJid,
                    {
                        text:
                            `❌ حدث خطأ أثناء تنفيذ الأمر:\n\n${
                                error.message ||
                                error.toString()
                            }`
                    },
                    {
                        quoted: msg
                    }
                );

            } catch (e) {}

        }
    }
};
