const fs = require('fs');
const path = require('path');
const { cleanupStaleTempFiles } = require('../lib/tempCleanup');

module.exports = {
    command: 'تنظيف',
    emoji: '🧹',
    description: 'تنظيف الملفات المؤقتة في مجلد الجلسة وملفات التمب مع الحفاظ على جلسة الاتصال.',
    usage: '.تنظيف',

    async execute(sock, msg) {
        const chatId = msg.key.remoteJid;

        try {
            const sessionFolder = path.join(process.cwd(), 'ملف_الاتصال');

            const protectedFiles = new Set([
                'creds.json',
                'app-state-sync-key.json',
                'session.json'
            ]);

            const temporaryExtensions = new Set(['.tmp', '.temp', '.cache', '.bak']);

            let sessionDeleted = 0;
            let sessionDeletedSize = 0;

            if (fs.existsSync(sessionFolder)) {
                const entries = fs.readdirSync(sessionFolder, { withFileTypes: true });
                const removable = [];

                for (const entry of entries) {
                    if (!entry.isFile()) continue;

                    const fileName = entry.name;
                    if (protectedFiles.has(fileName)) continue;

                    const filePath = path.join(sessionFolder, fileName);
                    let stat;
                    try {
                        stat = fs.statSync(filePath);
                    } catch {
                        continue;
                    }

                    const extension = path.extname(fileName).toLowerCase();
                    const lowerName = fileName.toLowerCase();

                    const isTemp =
                        temporaryExtensions.has(extension) ||
                        lowerName.includes('.tmp.') ||
                        lowerName.startsWith('tmp_') ||
                        lowerName.startsWith('temp_') ||
                        lowerName.endsWith('.backup');

                    if (isTemp) {
                        removable.push({ path: filePath, name: fileName, size: stat.size });
                    }
                }

                for (const file of removable) {
                    try {
                        if (fs.existsSync(file.path)) {
                            fs.unlinkSync(file.path);
                            sessionDeleted++;
                            sessionDeletedSize += file.size;
                        }
                    } catch (error) {}
                }
            }

            let tempDeleted = 0;
            try {
                tempDeleted = cleanupStaleTempFiles();
            } catch (error) {}

            function formatSize(bytes) {
                if (bytes < 1024) return `${bytes} B`;
                if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`;
                if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
                return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
            }

            const totalDeleted = sessionDeleted + tempDeleted;

            if (totalDeleted === 0) {
                return await sock.sendMessage(chatId, {
                    text: '✅ *الجلسة والتمب نظيفين*\n\nمفيش ملفات مؤقتة آمنة للحذف حاليًا.\n🔒 ملفات الاتصال الأساسية متلمسناهاش.'
                }, { quoted: msg });
            }

            await sock.sendMessage(chatId, {
                text:
                    '🧹 *تم تنظيف الجلسة والتمب بنجاح*\n\n' +
                    `📁 ملفات الجلسة المحذوفة: ${sessionDeleted} (${formatSize(sessionDeletedSize)})\n` +
                    `🗑️ ملفات التمب المحذوفة: ${tempDeleted}\n\n` +
                    '🔒 ملفات اعتماد الاتصال لم يتم حذفها.\n' +
                    '📡 الجلسة لسه متصلة زي ما هي.'
            }, { quoted: msg });
        } catch (error) {
            try {
                await sock.sendMessage(chatId, {
                    text: '❌ حدث خطأ أثناء تنظيف الجلسة والتمب.\n\n🔒 لم يتم حذف ملفات الاتصال الأساسية.'
                }, { quoted: msg });
            } catch {}
        }
    }
};
