const {
    eliteNumbers,
    isElite,
    isOwner,
    addEliteNumber,
    removeEliteNumber,
    extractPureNumber,
    getProtectedEliteNumber,
    isProtectedNumber
} = require('../haykala/elite');

const {
    jidDecode
} = require('@whiskeysockets/baileys');

function getPureJidNumber(jid) {

    if (!jid) {
        return '';
    }

    try {

        const decoded =
            jidDecode(jid);

        if (decoded?.user) {
            return extractPureNumber(
                decoded.user
            );
        }

    } catch (error) {}

    return extractPureNumber(jid);
}

function getSenderNumber(message) {

    const remoteJid =
        message.key?.remoteJid || '';

    let sender = '';

    if (remoteJid.endsWith('@g.us')) {

        sender =
            message.key?.participant ||
            message.participant ||
            message.key?.senderPn ||
            '';

    } else {

        sender =
            message.key?.participant ||
            message.participant ||
            remoteJid ||
            '';
    }

    return String(sender)
        .split(':')[0]
        .split('@')[0]
        .replace(/\D/g, '');
}

function isSessionOwner(sock, message) {
    const senderNumber = getSenderNumber(message);
    return isOwner(senderNumber);
}

module.exports = {

    command: 'نخبة',

    description:
        'إدارة أعضاء النخبة بواسطة مالك الجلسة فقط.',

    usage:
        '.نخبة اضف/ازل/عرض + منشن أو رد أو رقم',

    category: 'zarf',

    async execute(sock, msg) {

        try {

            const chatId =
                msg.key?.remoteJid;

            if (!chatId) {
                return;
            }

            if (!isSessionOwner(sock, msg)) {

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '🛡️ هذا الأمر مخصص لمالك جلسة البوت فقط.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            const text =
                msg.message?.conversation ||
                msg.message?.extendedTextMessage?.text ||
                msg.message?.imageMessage?.caption ||
                '';

            const parts =
                text.trim().split(/\s+/);

            const action =
                parts[1];

            if (
                !action ||
                ![
                    'اضف',
                    'ازل',
                    'عرض'
                ].includes(action)
            ) {

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ *طريقة الاستخدام*\n\n' +
                            '👑 .نخبة اضف + منشن/رد/رقم\n' +
                            '🗑️ .نخبة ازل + منشن/رد/رقم\n' +
                            '📋 .نخبة عرض'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            if (action === 'عرض') {

                const list =
                    eliteNumbers
                        .map(
                            (number, index) => {

                                const protectedMark =
                                    isProtectedNumber(
                                        number
                                    )
                                        ? ' 🛡️'
                                        : '';

                                return (
                                    `${index + 1}. ` +
                                    `@${number}` +
                                    protectedMark
                                );
                            }
                        )
                        .join('\n');

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '👑 *قائمة النخبة*\n\n' +
                            (
                                list ||
                                'لا يوجد أعضاء.'
                            ) +
                            '\n\n' +
                            '🛡️ = مالك محمي',

                        mentions:
                            eliteNumbers.map(
                                number =>
                                    `${number}@s.whatsapp.net`
                            )
                    },
                    {
                        quoted: msg
                    }
                );
            }

            let targetNumber = '';

            if (
                parts[2] &&
                /^\d{5,}$/.test(
                    parts[2]
                )
            ) {

                targetNumber =
                    extractPureNumber(
                        parts[2]
                    );
            }

            if (!targetNumber) {

                const contextInfo =
                    msg.message
                        ?.extendedTextMessage
                        ?.contextInfo;

                const mentionedJid =
                    contextInfo
                        ?.mentionedJid?.[0];

                const repliedJid =
                    contextInfo
                        ?.participant;

                const targetJid =
                    mentionedJid ||
                    repliedJid;

                if (!targetJid) {

                    return await sock.sendMessage(
                        chatId,
                        {
                            text:
                                '❌ يجب منشن العضو أو الرد على رسالته أو كتابة رقم صحيح.'
                        },
                        {
                            quoted: msg
                        }
                    );
                }

                targetNumber =
                    getPureJidNumber(
                        targetJid
                    );
            }

            if (!targetNumber) {

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ لم أستطع تحديد رقم العضو.'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            const ownerNumber =
                extractPureNumber(sock.user?.id) || getProtectedEliteNumber();

            if (
                ownerNumber &&
                targetNumber === ownerNumber
            ) {

                if (
                    !eliteNumbers.includes(
                        targetNumber
                    )
                ) {

                    addEliteNumber(
                        targetNumber
                    );
                }

                if (action === 'ازل') {

                    return await sock.sendMessage(
                        chatId,
                        {
                            text:
                                '🛡️ *عملية مرفوضة*\n\n' +
                                `👑 @${targetNumber}\n\n` +
                                'هذا هو مالك جلسة البوت.\n' +
                                '❌ لا يمكن إزالته من النخبة.',

                            mentions: [
                                `${targetNumber}@s.whatsapp.net`
                            ]
                        },
                        {
                            quoted: msg
                        }
                    );
                }

                if (action === 'اضف') {

                    return await sock.sendMessage(
                        chatId,
                        {
                            text:
                                '🛡️ *العضو محمي بالفعل*\n\n' +
                                `👑 @${targetNumber}\n\n` +
                                'مالك جلسة البوت موجود بالفعل في النخبة.',

                            mentions: [
                                `${targetNumber}@s.whatsapp.net`
                            ]
                        },
                        {
                            quoted: msg
                        }
                    );
                }
            }

            if (action === 'اضف') {

                if (
                    eliteNumbers.includes(
                        targetNumber
                    )
                ) {

                    return await sock.sendMessage(
                        chatId,
                        {
                            text:
                                `⚠️ @${targetNumber} موجود بالفعل في قائمة النخبة.`,

                            mentions: [
                                `${targetNumber}@s.whatsapp.net`
                            ]
                        },
                        {
                            quoted: msg
                        }
                    );
                }

                const added =
                    addEliteNumber(
                        targetNumber
                    );

                if (!added) {

                    return await sock.sendMessage(
                        chatId,
                        {
                            text:
                                '❌ تعذر إضافة الرقم إلى النخبة.'
                        },
                        {
                            quoted: msg
                        }
                    );
                }

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '✅ *تمت إضافة العضو إلى النخبة*\n\n' +
                            `👑 @${targetNumber}`,

                        mentions: [
                            `${targetNumber}@s.whatsapp.net`
                        ]
                    },
                    {
                        quoted: msg
                    }
                );
            }

            if (action === 'ازل') {

                if (
                    isProtectedNumber(
                        targetNumber
                    )
                ) {

                    return await sock.sendMessage(
                        chatId,
                        {
                            text:
                                '🛡️ *عملية مرفوضة*\n\n' +
                                `👑 @${targetNumber}\n\n` +
                                'هذا الرقم محمي ولا يمكن إزالته من النخبة.',

                            mentions: [
                                `${targetNumber}@s.whatsapp.net`
                            ]
                        },
                        {
                            quoted: msg
                        }
                    );
                }

                if (
                    !eliteNumbers.includes(
                        targetNumber
                    )
                ) {

                    return await sock.sendMessage(
                        chatId,
                        {
                            text:
                                `⚠️ @${targetNumber} غير موجود في قائمة النخبة.`,

                            mentions: [
                                `${targetNumber}@s.whatsapp.net`
                            ]
                        },
                        {
                            quoted: msg
                        }
                    );
                }

                const removed =
                    removeEliteNumber(
                        targetNumber
                    );

                if (!removed) {

                    return await sock.sendMessage(
                        chatId,
                        {
                            text:
                                `🛡️ تعذر إزالة @${targetNumber} لأن الرقم محمي.`,

                            mentions: [
                                `${targetNumber}@s.whatsapp.net`
                            ]
                        },
                        {
                            quoted: msg
                        }
                    );
                }

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '🗑️ *تمت إزالة العضو من النخبة*\n\n' +
                            `👤 @${targetNumber}`,

                        mentions: [
                            `${targetNumber}@s.whatsapp.net`
                        ]
                    },
                    {
                        quoted: msg
                    }
                );
            }

        } catch (error) {

            console.error(
                '❌ خطأ في أمر النخبة:',
                error
            );

            try {

                await sock.sendMessage(
                    msg.key.remoteJid,
                    {
                        text:
                            '❌ حدث خطأ أثناء تنفيذ أمر النخبة.'
                    },
                    {
                        quoted: msg
                    }
                );

            } catch (e) {}
        }
    }
};
