const {
    addedOwners,
    isRealOwner,
    addAddedOwner,
    removeAddedOwner,
    isAddedOwner,
    extractPureNumber
} = require('../haykala/elite');

const {
    jidDecode
} = require('@whiskeysockets/baileys');

function getPureJidNumber(jid) {
    if (!jid) return '';
    try {
        const decoded = jidDecode(jid);
        if (decoded?.user) return extractPureNumber(decoded.user);
    } catch (error) {}
    return extractPureNumber(jid);
}

function getSenderNumber(message) {
    const remoteJid = message.key?.remoteJid || '';
    let sender = '';

    if (remoteJid.endsWith('@g.us')) {
        sender =
            message.key?.participant ||
            message.participant ||
            message.key?.senderPn ||
            '';
    } else {
        sender =
            message.key?.participant ||
            message.participant ||
            remoteJid ||
            '';
    }

    return extractPureNumber(sender);
}

module.exports = {

    command: 'مالك',

    description:
        'إضافة/إزالة صلاحية مالك لشخص آخر (يقدر يستخدم كل الأوامر ما عدا أمر المالك نفسه). للمالك الحقيقي فقط.',

    usage:
        '.مالك اضف/ازل/عرض + منشن أو رد أو رقم',

    category: 'zarf',

    async execute(sock, msg) {

        try {

            const chatId = msg.key?.remoteJid;
            if (!chatId) return;

            const senderNumber = getSenderNumber(msg);

            if (!isRealOwner(senderNumber)) {
                return await sock.sendMessage(
                    chatId,
                    { text: '🛡️ هذا الأمر مخصص للمالك الحقيقي للبوت فقط.' },
                    { quoted: msg }
                );
            }

            const text =
                msg.message?.conversation ||
                msg.message?.extendedTextMessage?.text ||
                msg.message?.imageMessage?.caption ||
                '';

            const parts = text.trim().split(/\s+/);
            const action = parts[1];

            if (!action || !['اضف', 'ازل', 'عرض'].includes(action)) {
                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ *طريقة الاستخدام*\n\n' +
                            '👑 .مالك اضف + منشن/رد/رقم\n' +
                            '🗑️ .مالك ازل + منشن/رد/رقم\n' +
                            '📋 .مالك عرض'
                    },
                    { quoted: msg }
                );
            }

            if (action === 'عرض') {
                const list = addedOwners
                    .map((number, index) => `${index + 1}. @${number}`)
                    .join('\n');

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '👑 *قائمة المالكين المُضافين*\n\n' +
                            (list || 'لا يوجد أحد.') +
                            '\n\n' +
                            'هؤلاء يقدروا يستخدموا كل أوامر البوت، ما عدا أمر .مالك نفسه.',
                        mentions: addedOwners.map(n => `${n}@s.whatsapp.net`)
                    },
                    { quoted: msg }
                );
            }

            let targetNumber = '';

            if (parts[2] && /^\d{5,}$/.test(parts[2])) {
                targetNumber = extractPureNumber(parts[2]);
            }

            if (!targetNumber) {
                const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
                const mentionedJid = contextInfo?.mentionedJid?.[0];
                const repliedJid = contextInfo?.participant;
                const targetJid = mentionedJid || repliedJid;

                if (!targetJid) {
                    return await sock.sendMessage(
                        chatId,
                        { text: '❌ يجب منشن العضو أو الرد على رسالته أو كتابة رقم صحيح.' },
                        { quoted: msg }
                    );
                }

                targetNumber = getPureJidNumber(targetJid);
            }

            if (!targetNumber) {
                return await sock.sendMessage(
                    chatId,
                    { text: '❌ لم أستطع تحديد رقم العضو.' },
                    { quoted: msg }
                );
            }

            if (isRealOwner(targetNumber)) {
                return await sock.sendMessage(
                    chatId,
                    {
                        text: `👑 @${targetNumber} هو المالك الحقيقي للبوت أصلًا، مش محتاج إضافة.`,
                        mentions: [`${targetNumber}@s.whatsapp.net`]
                    },
                    { quoted: msg }
                );
            }

            if (action === 'اضف') {
                if (isAddedOwner(targetNumber)) {
                    return await sock.sendMessage(
                        chatId,
                        {
                            text: `⚠️ @${targetNumber} عنده صلاحية المالك بالفعل.`,
                            mentions: [`${targetNumber}@s.whatsapp.net`]
                        },
                        { quoted: msg }
                    );
                }

                addAddedOwner(targetNumber);

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '✅ *تمت إضافة صلاحية المالك*\n\n' +
                            `👤 @${targetNumber}\n\n` +
                            'يقدر يستخدم كل أوامر البوت، ما عدا أمر .مالك نفسه.',
                        mentions: [`${targetNumber}@s.whatsapp.net`]
                    },
                    { quoted: msg }
                );
            }

            if (action === 'ازل') {
                if (!isAddedOwner(targetNumber)) {
                    return await sock.sendMessage(
                        chatId,
                        {
                            text: `⚠️ @${targetNumber} مش موجود في قائمة المالكين المُضافين.`,
                            mentions: [`${targetNumber}@s.whatsapp.net`]
                        },
                        { quoted: msg }
                    );
                }

                removeAddedOwner(targetNumber);

                return await sock.sendMessage(
                    chatId,
                    {
                        text: `🗑️ تم إزالة صلاحية المالك من @${targetNumber}.`,
                        mentions: [`${targetNumber}@s.whatsapp.net`]
                    },
                    { quoted: msg }
                );
            }

        } catch (error) {
            console.error('❌ خطأ في أمر المالك:', error);
            try {
                await sock.sendMessage(
                    msg.key.remoteJid,
                    { text: '❌ حدث خطأ أثناء تنفيذ أمر المالك.' },
                    { quoted: msg }
                );
            } catch (e) {}
        }
    }
};
