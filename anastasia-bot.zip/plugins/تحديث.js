const { isElite } = require('../haykala/elite');
const updateManager = require('../lib/updateManager');

module.exports = {

    command: 'تحديث',

    description:
        'إعادة تحميل الإضافات وفحص الملفات بدون إيقاف البوت.',

    usage:
        '.تحديث',
    
    emoji: '🔄', 

    async execute(sock, msg) {

        const chatId =
            msg.key?.remoteJid;

        try {

            // ==================================================
            // 👑 التحقق من النخبة
            // ==================================================

            const sender =
                msg.key?.participant ||
                msg.participant ||
                msg.senderNumber ||
                '';

            const senderNumber =
                String(sender)
                    .split(':')[0]
                    .split('@')[0]
                    .replace(/\D/g, '');

            if (
                !isElite(senderNumber)
            ) {

                await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ هذا الأمر مخصص للنخبة فقط.'
                    }
                );

                return;
            }


            // ==================================================
            // 🔄 رسالة البداية
            // ==================================================

            const statusMessage =
                await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '🔄 *جاري تحديث البوت...*\n\n' +
                            '📦 جاري فحص الملفات\n' +
                            '🔎 جاري إعادة تحميل الـ Plugins\n' +
                            '⚙️ جاري تحديث Handler\n\n' +
                            '⏳ انتظر لحظات...'
                    }
                );


            // ==================================================
            // 🚀 تنفيذ التحديث
            // ==================================================

            const result =
                await updateManager.startUpdate(
                    chatId
                );


            // ==================================================
            // 📊 إرسال التقرير
            // ==================================================

            if (
                result?.report
            ) {

                await sock.sendMessage(
                    chatId,
                    {
                        text:
                            result.report
                    }
                );

            } else {

                await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '⚠️ انتهى التحديث ولكن لم يتم إنشاء تقرير.'
                    }
                );

            }

        } catch (error) {

            console.error(
                '❌ خطأ في أمر تحديث:',
                error
            );

            try {

                await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ حدث خطأ أثناء تحديث البوت.\n\n' +
                            `🔴 الخطأ: ${
                                error?.message ||
                                String(error)
                            }`
                    }
                );

            } catch {}

        }

    }

};