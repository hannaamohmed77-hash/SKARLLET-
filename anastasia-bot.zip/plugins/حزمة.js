const axios = require('axios');
const {
    isWebP,
    isAnimatedWebP,
    imageToWebp,
    sendCustomStickerPack,
    searchPins
} = require('../lib/stickerPack');

module.exports = {

    command: 'حزمة',
    emoji: '📦',
    description: 'يجيب صور من بينتريست حسب كلمة بحث ويبعتها كحزمة ملصقات (sticker pack) واحدة.',
    usage: '.حزمة <كلمة بحث> [العدد] [@صاحب_الطلب]',

    async execute(sock, msg) {
        const chatId = msg.key.remoteJid;

        const body =
            msg.message?.extendedTextMessage?.text ||
            msg.message?.conversation ||
            '';

        let text =
            (Array.isArray(msg.args) && msg.args.length
                ? msg.args.join(' ')
                : body.replace(/^[.!؟]?\s*حزمة\s*/i, '')
            ).trim();

        if (!text) {
            return await sock.sendMessage(
                chatId,
                {
                    text:
                        '📦 *حزمة ملصقات من Pinterest*\n\n' +
                        '📌 *الاستخدام:*\n' +
                        '.حزمة قطط\n' +
                        '.حزمة انمي 10\n' +
                        '.حزمة نيزكو 15 @فلان'
                },
                { quoted: msg }
            );
        }

        // --- 1. استخراج صاحب الطلب (المنشن) ---
        let requester = msg.key.participant || msg.key.remoteJid;
        const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
        
        if (contextInfo?.mentionedJid && contextInfo.mentionedJid.length > 0) {
            requester = contextInfo.mentionedJid[0];
        }

        // إزالة المنشن من كلمة البحث
        text = text.replace(/@\d+/g, '').trim();

        // --- 2. استخراج العدد المحدد أو التلقائي ---
        let count = 30; // العدد الافتراضي
        const countMatch = text.match(/\b\d+\b/);
        
        if (countMatch) {
            count = parseInt(countMatch[0], 10);
            if (count > 30) count = 30; // الحد الأقصى 30
            if (count < 1) count = 5;
            text = text.replace(/\b\d+\b/, '').trim();
        }

        if (!text) {
            return await sock.sendMessage(
                chatId,
                { text: '❌ يرجى تحديد اسم أو كلمة البحث الخاصة بالحزمة.' },
                { quoted: msg }
            );
        }

        await sock.sendMessage(chatId, { react: { text: '📦', key: msg.key } });

        try {
            const results = await searchPins(text);

            if (!results || !results.length) {
                await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
                return await sock.sendMessage(chatId, { text: `❌ ما لقيت نتائج لـ *${text}*` }, { quoted: msg });
            }

            const urls = [...new Set(results.map(v => v.image).filter(Boolean))];

            if (urls.length < 5) {
                await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
                return await sock.sendMessage(chatId, { text: '❌ النتائج قليلة جداً، جرب كلمة بحث أخرى' }, { quoted: msg });
            }

            const chosen = urls.sort(() => Math.random() - 0.5).slice(0, count);
            const pack = [];

            const packName = `${text.toUpperCase()} ⃟↥𝑽𝒊𝒂𝒏🎹⃟⃤𝑺𝒕𝒊𝒄𝒌𝒆𝒓↥❀`;
            const packPublisher = '⃟↥𝑽𝒊𝒂𝒏🎹⃟⃤𝑺𝒕𝒊𝒄𝒌𝒆𝒓↥❀';

            for (const url of chosen) {
                try {
                    const imgRes = await axios.get(url, {
                        responseType: 'arraybuffer',
                        timeout: 30000,
                        headers: { 'User-Agent': 'Mozilla/5.0' }
                    });

                    let buffer = Buffer.from(imgRes.data);

                    // إجبار إعادة تحويل حتى لو كانت webp لتضمين Exif الخاص بالحقوق داخل كل صورة
                    buffer = await imageToWebp(buffer, {
                        packname: packName,
                        author: packPublisher
                    });

                    if (buffer && buffer.length > 0) {
                        pack.push({
                            buffer,
                            ext: 'webp',
                            mimetype: 'image/webp',
                            isAnimated: isAnimatedWebP(buffer),
                            isLottie: false,
                            packname: packName,
                            author: packPublisher,
                            packName: packName,
                            packPublish: packPublisher
                        });
                    }
                } catch (e) {
                    console.error('Image download/convert failed:', e?.message || e);
                }
            }

            if (pack.length < 1) {
                await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
                return await sock.sendMessage(chatId, { text: '❌ ما قدرت أجمع صور كفاية للحزمة' }, { quoted: msg });
            }

            // --- 3. إرسال معلومات الحزمة وصاحب الطلب قبل الحزمة ---
            const infoText = `📦 *تفاصيل الحزمة المطلوبة:*\n\n` +
                             `🏷️ *اسم الحزمة:* ${text}\n` +
                             `📊 *عدد استيكرات الحزمة:* ${pack.length}\n` +
                             `👤 *صاحب الطلب:* @${requester.split('@')[0]}`;

            await sock.sendMessage(chatId, {
                text: infoText,
                mentions: [requester]
            }, { quoted: msg });

            // إرسال الحزمة
            await sendCustomStickerPack(sock, chatId, msg, pack, {
                name: packName,
                publisher: packPublisher,
                packname: packName,
                author: packPublisher,
                description: 'حزمة ملصقات مولّدة تلقائيًا'
            });

            await sock.sendMessage(chatId, { react: { text: '✅', key: msg.key } });

        } catch (error) {
            console.error('حزمة error:', error);
            await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
            await sock.sendMessage(chatId, { text: `⚠️ حدث خطأ: ${error.message}` }, { quoted: msg });
        }
    }
};
