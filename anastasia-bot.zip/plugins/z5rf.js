module.exports = {
  command: "زخرف",
  description: "يزخرف النصوص الإنجليزية والعربية بأشكال مختلفة.",
    emoji: '🔤',
  usage: ".زخرف [النص]",

  async execute(sock, msg) {
    try {
      const chatId = msg.key.remoteJid;

      const body =
        msg.message?.extendedTextMessage?.text ||
        msg.message?.conversation ||
        "";

      // استخراج النص بعد الأمر
      const text = body
        .replace(/^[.!؟]?\s*زخرف\s*/i, "")
        .trim();

      if (!text) {
        return await sock.sendMessage(
          chatId,
          {
            text:
              "❌ استخدم الأمر هكذا:\n\n" +
              "زخرف [النص]\n\n" +
              "مثال:\n" +
              "زخرف Mohamed\n" +
              "زخرف hello world\n" +
              "زخرف محمد"
          },
          { quoted: msg }
        );
      }

      // =========================
      // زخارف الحروف الإنجليزية
      // =========================

      const styles = [

        // 1 - Script
        {
          a: "𝒶", b: "𝒷", c: "𝒸", d: "𝒹", e: "𝑒", f: "𝒻",
          g: "𝒼", h: "𝒽", i: "𝒾", j: "𝒿", k: "𝓀", l: "𝓁",
          m: "𝓂", n: "𝓃", o: "𝑜", p: "𝓅", q: "𝓆", r: "𝓇",
          s: "𝓈", t: "𝓉", u: "𝓊", v: "𝓋", w: "𝓌", x: "𝓍",
          y: "𝓎", z: "𝓏"
        },

        // 2 - Italic
        {
          a: "𝘢", b: "𝘣", c: "𝘤", d: "𝘥", e: "𝘦", f: "𝘧",
          g: "𝘨", h: "𝘩", i: "𝘪", j: "𝘫", k: "𝘬", l: "𝘭",
          m: "𝘮", n: "𝘯", o: "𝘰", p: "𝘱", q: "𝘲", r: "𝘳",
          s: "𝘴", t: "𝘵", u: "𝘶", v: "𝘷", w: "𝘸", x: "𝘹",
          y: "𝘺", z: "𝘻"
        },

        // 3 - Double
        {
          a: "𝕒", b: "𝕓", c: "𝕔", d: "𝕕", e: "𝕖", f: "𝕗",
          g: "𝕘", h: "𝕙", i: "𝕚", j: "𝕛", k: "𝕜", l: "𝕝",
          m: "𝕞", n: "𝕟", o: "𝕠", p: "𝕡", q: "𝕢", r: "𝕣",
          s: "𝕤", t: "𝕥", u: "𝕦", v: "𝕧", w: "𝕨", x: "𝕩",
          y: "𝕪", z: "𝕫"
        },

        // 4 - Gothic
        {
          a: "𝖆", b: "𝖇", c: "𝖈", d: "𝖉", e: "𝖊", f: "𝖋",
          g: "𝖌", h: "𝖍", i: "𝖎", j: "𝖏", k: "𝖐", l: "𝖑",
          m: "𝖒", n: "𝖓", o: "𝖔", p: "𝖕", q: "𝖖", r: "𝖗",
          s: "𝖘", t: "𝖙", u: "𝖚", v: "𝖛", w: "𝖜", x: "𝖝",
          y: "𝖞", z: "𝖟"
        },

        // 5 - Bold
        {
          a: "𝙖", b: "𝙗", c: "𝙘", d: "𝙙", e: "𝙚", f: "𝙛",
          g: "𝙜", h: "𝙝", i: "𝙞", j: "𝙟", k: "𝙠", l: "𝙡",
          m: "𝙢", n: "𝙣", o: "𝙤", p: "𝙥", q: "𝙦", r: "𝙧",
          s: "𝙨", t: "𝙩", u: "𝙪", v: "𝙫", w: "𝙬", x: "𝙭",
          y: "𝙮", z: "𝙯"
        },

        // 6 - Bold Capital
        {
          a: "𝐀", b: "𝐁", c: "𝐂", d: "𝐃", e: "𝐄", f: "𝐅",
          g: "𝐆", h: "𝐇", i: "𝐈", j: "𝐉", k: "𝐊", l: "𝐋",
          m: "𝐌", n: "𝐍", o: "𝐎", p: "𝐏", q: "𝐐", r: "𝐑",
          s: "𝐒", t: "𝐓", u: "𝐔", v: "𝐕", w: "𝐖", x: "𝐗",
          y: "𝐘", z: "𝐙"
        },

        // 7 - Mathematical Italic
        {
          a: "𝑨", b: "𝑩", c: "𝑪", d: "𝑫", e: "𝑬", f: "𝑭",
          g: "𝑮", h: "𝑯", i: "𝑰", j: "𝑱", k: "𝑲", l: "𝑳",
          m: "𝑴", n: "𝑵", o: "𝑶", p: "𝑷", q: "𝑸", r: "𝑹",
          s: "𝑺", t: "𝑻", u: "𝑼", v: "𝑽", w: "𝑾", x: "𝑿",
          y: "𝒀", z: "𝒁"
        },

        // 8 - Monospace
        {
          a: "𝚊", b: "𝚋", c: "𝚌", d: "𝚍", e: "𝚎", f: "𝚏",
          g: "𝚐", h: "𝚑", i: "𝚒", j: "𝚓", k: "𝚔", l: "𝚕",
          m: "𝚖", n: "𝚗", o: "𝚘", p: "𝚙", q: "𝚚", r: "𝚛",
          s: "𝚜", t: "𝚝", u: "𝚞", v: "𝚟", w: "𝚠", x: "𝚡",
          y: "𝚢", z: "𝚣"
        },

        // 9 - Fullwidth
        {
          a: "ａ", b: "ｂ", c: "ｃ", d: "ｄ", e: "ｅ", f: "ｆ",
          g: "ｇ", h: "ｈ", i: "ｉ", j: "ｊ", k: "ｋ", l: "ｌ",
          m: "ｍ", n: "ｎ", o: "ｏ", p: "ｐ", q: "ｑ", r: "ｒ",
          s: "ｓ", t: "ｔ", u: "ｕ", v: "ｖ", w: "ｗ", x: "ｘ",
          y: "ｙ", z: "ｚ"
        }
      ];

      // =========================
      // زخارف عربية
      // =========================

      const arabicStyles = [

        // تطويل
        text => text.split("").join("ـ"),

        // تشكيل خفيف
        text =>
          text
            .replace(/ا/g, "آ")
            .replace(/ه/g, "ہ")
            .replace(/ي/g, "ی")
            .replace(/ك/g, "ک"),

        // حروف عربية بديلة
        text =>
          text
            .replace(/ا/g, "ٱ")
            .replace(/ب/g, "ٻ")
            .replace(/ت/g, "ٹ")
            .replace(/ج/g, "چ")
            .replace(/ح/g, "ح")
            .replace(/خ/g, "خ")
            .replace(/د/g, "ڈ")
            .replace(/ر/g, "ڑ")
            .replace(/س/g, "س")
            .replace(/ش/g, "ش")
            .replace(/ص/g, "ص")
            .replace(/ض/g, "ض")
            .replace(/ط/g, "ط")
            .replace(/ظ/g, "ظ")
            .replace(/ع/g, "ع")
            .replace(/غ/g, "غ")
            .replace(/ف/g, "ف")
            .replace(/ق/g, "ق")
            .replace(/ك/g, "ک")
            .replace(/ل/g, "ل")
            .replace(/م/g, "م")
            .replace(/ن/g, "ن")
            .replace(/ه/g, "ہ")
            .replace(/و/g, "و")
            .replace(/ي/g, "ی"),

        // تطويل عربي أنظف
        text => text.split("").join("ـ"),

        // تغيير بعض الحروف فقط
        text =>
          text
            .replace(/ا/g, "ٱ")
            .replace(/ك/g, "ڪ")
            .replace(/ي/g, "ى")
            .replace(/ه/g, "ھ")
      ];

      // =========================
      // تحويل النص للإنجليزي
      // =========================

      const lowerText = text.toLowerCase();

      const englishResults = styles.map(style =>
        lowerText
          .split("")
          .map(char => style[char] || char)
          .join("")
      );

      // =========================
      // أرقام مزخرفة
      // =========================

      const numberStyles = [
        {
          0: "𝟎", 1: "𝟏", 2: "𝟐", 3: "𝟑", 4: "𝟒",
          5: "𝟓", 6: "𝟔", 7: "𝟕", 8: "𝟖", 9: "𝟗"
        },
        {
          0: "０", 1: "１", 2: "２", 3: "３", 4: "４",
          5: "５", 6: "６", 7: "７", 8: "８", 9: "９"
        }
      ];

      const numberResults = numberStyles.map(style =>
        text
          .split("")
          .map(char => style[char] || char)
          .join("")
      );

      // =========================
      // النتيجة النهائية
      // =========================

      const results = [
        ...englishResults,
        ...arabicStyles.map(fn => fn(text)),
        ...numberResults
      ];

      // إزالة النتائج المكررة
      const uniqueResults = [...new Set(results)];

      await sock.sendMessage(
        chatId,
        {
          text:
            "✨ *زخرفة النص* ✨\n\n" +
            uniqueResults.join("\n")
        },
        { quoted: msg }
      );

    } catch (error) {
      console.error("✗ خطأ في أمر الزخرفة:", error);

      await sock.sendMessage(
        msg.key.remoteJid,
        {
          text:
            "❌ حدث خطأ أثناء تنفيذ أمر الزخرفة:\n\n" +
            (error.message || error.toString())
        },
        { quoted: msg }
      );
    }
  }
};