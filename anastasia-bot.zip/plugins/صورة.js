const {
    downloadContentFromMessage
} = require('@whiskeysockets/baileys');

const sharp = require('sharp');
const fs = require('fs-extra');
const path = require('path');

module.exports = {
    command: 'صورة',
emoji: '🖨️',
    description: 'تحويل الملصق إلى صورة',

    usage: '.صورة',

    async execute(sock, msg) {

        const chatId = msg.key.remoteJid;

        try {

            // ==========================================
            // 🔎 البحث عن الملصق
            // ==========================================

            let stickerMessage = null;

            // لو الأمر مكتوب ردًا على ملصق
            const quoted =
                msg.message?.extendedTextMessage
                    ?.contextInfo?.quotedMessage;

            if (quoted?.stickerMessage) {
                stickerMessage =
                    quoted.stickerMessage;
            }

            // لو الرسالة نفسها ملصق
            if (
                msg.message?.stickerMessage
            ) {
                stickerMessage =
                    msg.message.stickerMessage;
            }

            // ==========================================
            // ❌ لا يوجد ملصق
            // ==========================================

            if (!stickerMessage) {

                return await sock.sendMessage(
                    chatId,
                    {
                        text:
                            '❌ ابعت الأمر بالرد على ملصق.\n\n' +
                            'مثال:\n' +
                            '↩️ رد على الملصق واكتب .صورة'
                    },
                    {
                        quoted: msg
                    }
                );
            }

            // ==========================================
            // 📥 تحميل الملصق
            // ==========================================

            const stream =
                await downloadContentFromMessage(
                    stickerMessage,
                    'sticker'
                );

            const chunks = [];

            for await (const chunk of stream) {
                chunks.push(chunk);
            }

            const inputBuffer =
                Buffer.concat(chunks);

            if (!inputBuffer.length) {

                throw new Error(
                    'تعذر تحميل الملصق'
                );
            }

            // ==========================================
            // 🖼️ تحويل WebP إلى PNG
            // ==========================================

            const outputBuffer =
                await sharp(inputBuffer)
                    .png()
                    .toBuffer();

            // ==========================================
            // 📤 إرسال الصورة
            // ==========================================

            await sock.sendMessage(
                chatId,
                {
                    image: outputBuffer,
                    caption:
                        '🖼️ تم تحويل الملصق إلى صورة.'
                },
                {
                    quoted: msg
                }
            );

        } catch (error) {

            console.error(
                '❌ خطأ في تحويل الملصق:',
                error
            );

            await sock.sendMessage(
                chatId,
                {
                    text:
                        '❌ حصل خطأ أثناء تحويل الملصق إلى صورة.'
                },
                {
                    quoted: msg
                }
            ).catch(() => {});
        }
    }
};